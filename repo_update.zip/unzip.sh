cd /Share/github/kodil/temp
find .  -maxdepth 1 -name "*.zip" |xargs -n1 unzip
