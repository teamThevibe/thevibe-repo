import sys,urllib,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os
from addon.common.addon import Addon
from metahandler import metahandlers
import requests


#Imperial Streams Add-on Created By Mucky Duck (5/2016)


User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.mdimperialstreams'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
metaset = selfAddon.getSetting('enable_meta')
metaget = metahandlers.MetaData()
baseurl = 'http://imoviemax.se'
baseurl2 = 'http://tvshows.imoviemax.se'




def CAT():
        addDir('[B][COLOR white]TV SHOWS[/COLOR][/B]','url',2,art+'TV_SHOWS.png',fanart,'')
        addDir('[B][COLOR white]MOVIES[/COLOR][/B]','url',1,art+'MOVIES.png',fanart,'')




def MOV():
        addDir('[B][COLOR white]New Release Movies[/COLOR][/B]',baseurl+'/movies/',3,art+'NEW_RELEASE_MOVIES.png',art+'1.jpg','')
        addDir('[B][COLOR white]Featured Movies[/COLOR][/B]',baseurl+'/category/featured/',3,art+'FEATURED_MOVIES.png',art+'1.jpg','')
        addDir('[B][COLOR white]Search Movies[/COLOR][/B]','url',9,art+'SEARCH_MOVIES.png',art+'1.jpg','')
        addDir('[B][COLOR white]Box Office[/COLOR][/B]',baseurl+'/category/box-office/',3,art+'BOX_OFFICE.png',art+'1.jpg','')
        addDir('[B][COLOR white]Hollywood[/COLOR][/B]',baseurl+'/category/hollywood-movies/',3,art+'HOLLYWOOD.png',art+'1.jpg','')
        addDir('[B][COLOR white]Bollywood[/COLOR][/B]',baseurl+'/category/bollywood-movies/',3,art+'BOLLYWOOD.png',art+'1.jpg','')
        addDir('[B][COLOR white]Asian[/COLOR][/B]',baseurl+'/category/asian-movies/',3,art+'ASIAN.png',art+'1.jpg','')
        addDir('[B][COLOR white]Genre[/COLOR][/B]',baseurl,7,art+'GENRE.png',art+'1.jpg','')




def TV():
        addDir('[B][COLOR white]Featured TV Shows[/COLOR][/B]',baseurl2+'/tvshows/category/featured/',4,art+'FEATURED_TV.png',art+'1.jpg','')
        addDir('[B][COLOR white]Latest Episodes[/COLOR][/B]',baseurl2+'/episode/',4,art+'LATEST_EPISODES.png',art+'1.jpg','')
        addDir('[B][COLOR white]New TV Shows[/COLOR][/B]',baseurl2+'/tvshows/',4,art+'New_Tv_Shows.png',art+'1.jpg','')
        addDir('[B][COLOR white]Search[/COLOR][/B]','url',10,art+'SEARCH.png',art+'1.jpg','')
        addDir('[B][COLOR white]Genre[/COLOR][/B]',baseurl2,8,art+'GENRE.png',art+'1.jpg','')




def MINDEX(url):
        link = OPEN_URL(url)
        all_videos = regex_get_all(link, '"movie"', '<span class="year">.*?</span>.*?</div>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '<h2>', '</')
                name = addon.unescape(name)
                name = name.encode('ascii', 'ignore').decode('ascii')
                url = regex_from_to(a, 'href="', '"')
                thumb = regex_from_to(a, 'src="', '"')
                if metaset=='true':
                        addDir2('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,thumb,items)
                else:
                        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,thumb,fanart,'')
        try:
                np = re.compile('<div class="siguiente"><a href="(.*?)" >Next').findall(link)[0]
                addDir('[I][B][COLOR gold]Go To Next Page>>>[/COLOR][/B][/I]',np,3,art+'next.png',fanart,'')
        except:pass
        setView('movies', 'movie-view')




def TINDEX(url):
        link = OPEN_URL(url)
        all_videos = regex_get_all(link, '"movie"', '</h2>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '<h2.*?>', '</')
                name = addon.unescape(name)
                name = name.encode('ascii', 'ignore').decode('ascii')
                url = regex_from_to(a, 'href="', '"')
                thumb = regex_from_to(a, 'src="', '"')
                if metaset=='true':
                        if '/episode/' in url:
                                addDir3('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,thumb,items,'',name)
                        else:
                                addDir3('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,thumb,items,'',name)
                else:
                        if '/episode/' in url:
                                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,thumb,fanart,'')
                        else:
                                addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,thumb,fanart,'')
        try:
                np = re.compile('<div class="siguiente"><a href="(.*?)" >Next').findall(link)[0]
                addDir('[I][B][COLOR gold]Go To Next Page>>>[/COLOR][/B][/I]',np,4,art+'next.png',fanart,'')
        except:pass
        setView('tvshows', 'show-view')




def SEA(name,url,iconimage):
        show_title = name
        link = OPEN_URL(url)
        match=re.compile("<li class='has-sub'><a href='\#'><span><b class=\"icon-bars\"></b>(.*?)</span></a>").findall(link) 
        items = len(match)
        for name in match:
                name = name.strip()
                if metaset=='true':
                        addDir3('[B][COLOR white]%s[/COLOR][/B]' %name,url,6,icon,items,'',show_title)
                else:
                        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,6,icon,fanart,'')




def EP(name,url,iconimage,show_title):
        if iconimage == None:
                iconimage = icon
        link = OPEN_URL(url)
        name = name.replace('[B][COLOR white]','').replace('[/COLOR][/B]','')
        all_links = regex_get_all(link, '<span><b class="icon-bars"></b> %s' %name, '</ul>')
        all_videos = regex_get_all(str(all_links), '<li', '/li>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '</b>', '</sp').replace('\\n','').replace('\\t','')
                name = addon.unescape(name)
                name = name.encode('ascii', 'ignore').decode('ascii')
                url = regex_from_to(a, 'href="', '"')
                if metaset=='true':
                        addDir3('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,iconimage,items,'',show_title)
                else:
                        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,iconimage,fanart,'')
        setView('tvshows', 'show-view')




def RESOLVE(name,url,iconimage):
        link = OPEN_URL(url)
        try:
                #RequestURL = re.findall(r'<div style="float:left;width:100%;">.*? href="(.*?)">', str(link), re.I|re.DOTALL)[0]
                RequestURL = re.findall(r'<div id="play-1" class="player-content"><iframe class="playerframe" src="(.*?)" .*?>', str(link), re.I|re.DOTALL)[0]
                print '##########################RequestURL='+str(RequestURL)
                headers = {'referer': url, 'user-agent': User_Agent}
                link2 = requests.get(RequestURL, headers=headers).text
                RequestURL2 = re.findall(r'<iframe.*?src="(.*?)" .*?>', str(link2), re.I|re.DOTALL)[0]
                print '##########################RequestURL2='+str(RequestURL2)
                headers = {'referer': RequestURL, 'user-agent': User_Agent}
                link3 = requests.get(RequestURL2, headers=headers).text
                #url = re.findall(r'src="(.*?)" type="video/mp4">', str(link), re.I|re.DOTALL)[0]
                url = re.findall(r'<source src="(.*?)" type="video/mp4"/>', str(link3), re.I|re.DOTALL)[0]
                print '##########################URL='+str(url)
        except:
                #RequestURL = re.findall(r'<div style="float:left;width:100%;">.*? href="(.*?)">', str(link), re.I|re.DOTALL)[0]
                RequestURL = re.findall(r'<div id="play-1" class="player-content"><iframe class="playerframe" src="(.*?)" .*?>', str(link), re.I|re.DOTALL)[0]
                headers = {'referer': url, 'user-agent': User_Agent}
                link2 = requests.get(RequestURL, headers=headers).text
                RequestURL2 = re.findall(r'<iframe.*?src="(.*?)" .*?>', str(link2), re.I|re.DOTALL)[1]
                headers = {'referer': RequestURL, 'user-agent': User_Agent}
                link3 = requests.get(RequestURL2, headers=headers).text
                #url = re.findall(r'src="(.*?)" type="video/mp4">', str(link), re.I|re.DOTALL)[0]
                url = re.findall(r'<source src="(.*?)" type="video/mp4"/>', str(link3), re.I|re.DOTALL)[0]
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={'Title':description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)




def SEARCHM():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = baseurl+'/?s='+search
                MINDEX(url)




def SEARCHT():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = baseurl2+'/?s='+search
                TINDEX(url)




def MGENRE(url):
        link = OPEN_URL(url)
        match=re.compile('<a href="(.*?)">(.*?)</a>').findall(link) 
        for url,name in match:
                if '/genre/' in url:
                        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,3,icon,fanart,'')




def TGENRE(url):
        link = OPEN_URL(url)
        match=re.compile('<a href="(.*?)">(.*?)</a>').findall(link) 
        for url,name in match:
                if '/genre/' in url:
                        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,4,icon,fanart,'')




def regex_from_to(text, from_string, to_string, excluding=True):
        if excluding:
                try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
                except: r = ''
        else:
                try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
                except: r = ''
        return r




def regex_get_all(text, start_with, end_with):
        r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
        return r




def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def addDir(name,url,mode,iconimage,fanart,description):
        name = name.replace('()','')
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title":name,"Plot":description})
        liz.setProperty('fanart_image', fanart)
        if mode==100:
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok




def PT(url):
        addon.log('Play Trailer %s' % url)
        notification( addon.get_name(), 'fetching trailer', addon.get_icon())
        xbmc.executebuiltin("PlayMedia(%s)"%url)




def notification(title, message, icon):
        addon.show_small_popup( addon.get_name(), message.title(), 5000, icon)
        return




def addDir2(name,url,mode,iconimage,itemcount):
        name = name.replace('[B][COLOR white]','').replace('[/COLOR][/B]','')
        splitName=name.partition('(')
        simplename=""
        simpleyear=""
        if len(splitName)>0:
            simplename=splitName[0]
            simpleyear=splitName[2].partition(')')
        if len(simpleyear)>0:
            simpleyear=simpleyear[0]
        meta = metaget.get_meta('movie',simplename,simpleyear)
        if meta['cover_url']=='':
            try:
                meta['cover_url']=iconimage
            except:
                meta['cover_url']=icon
        name = '[B][COLOR white]' + name + '[/COLOR][/B]'
        meta['title'] = name
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=meta['cover_url'], thumbnailImage=meta['cover_url'])
        liz.setInfo( type="Video", infoLabels= meta )
        contextMenuItems = []
        contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
        if meta['trailer']:
                contextMenuItems.append(('Play Trailer', 'XBMC.RunPlugin(%s)' % addon.build_plugin_url({'mode': 11, 'url':meta['trailer']})))
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        if not meta['backdrop_url'] == '':
                liz.setProperty('fanart_image', meta['backdrop_url'])
        else: liz.setProperty('fanart_image', fanart)
        if mode==100:
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
        else:
             ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
        return ok




def addDir3(name,url,mode,iconimage,itemcount,description,show_title):
        show_title = show_title.replace('[B][COLOR white]','').replace('[/COLOR][/B]','')
        try:
                show_title = re.split(r"\(", str(show_title), re.I)[0]
        except: pass
        try:
                show_title = re.split(r" Season ", str(show_title), re.I)[0]
        except: pass
        try:
                show_title = re.split(r"[I]", str(show_title), re.I)[0]
        except: pass
        meta = metaget.get_meta('tvshow',show_title)
        if meta['cover_url']=='':
            try:
                meta['cover_url']=iconimage
            except:
                meta['cover_url']=icon
        meta['title'] = name
        contextMenuItems = []
        contextMenuItems.append(('TV Show Info', 'XBMC.Action(Info)'))
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&show_title="+urllib.quote_plus(show_title)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=meta['cover_url'], thumbnailImage=meta['cover_url'])
        liz.setInfo( type="Video", infoLabels= meta )
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        if not meta['backdrop_url'] == '':
                liz.setProperty('fanart_image', meta['backdrop_url'])
        else:
                liz.setProperty('fanart_image', fanart)
        if mode==100:
                liz.setProperty("IsPlayable","true")
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
        else:
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
        return ok
        



def addLink(name,url,mode,iconimage,fanart,description=''):
        #u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
        #ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok




def OPEN_URL(url):
        headers = {}
        headers['User-Agent'] = User_Agent
        link = requests.get(url, headers=headers, allow_redirects=False).text
        link = link.encode('ascii', 'ignore').decode('ascii')
        return link





def setView(content, viewType):
    ''' Why recode whats allready written and works well,
    Thanks go to Eldrado for it '''
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':

        print addon.get_setting(viewType)
        if addon.get_setting(viewType) == 'Info':
            VT = '504'
        elif addon.get_setting(viewType) == 'Info2':
            VT = '503'
        elif addon.get_setting(viewType) == 'Info3':
            VT = '515'
        elif addon.get_setting(viewType) == 'Fanart':
            VT = '508'
        elif addon.get_setting(viewType) == 'Poster Wrap':
            VT = '501'
        elif addon.get_setting(viewType) == 'Big List':
            VT = '51'
        elif addon.get_setting(viewType) == 'Low List':
            VT = '724'
        elif addon.get_setting(viewType) == 'Default View':
            VT = addon.get_setting('default-view')

        print viewType
        print VT
        
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )




params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None
show_title=None




try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:
        description=urllib.unquote_plus(params["description"])
except:
        pass

try:
        show_title=urllib.unquote_plus(params["show_title"])
except:
        pass




if mode==None or url==None or len(url)<1:
        CAT()

elif mode==1:
        MOV()

elif mode==2:
        TV()

elif mode==3:
        MINDEX(url)

elif mode==4:
        TINDEX(url)

elif mode==5:
        SEA(name,url,iconimage)

elif mode==6:
        EP(name,url,iconimage,show_title)

elif mode==7:
        MGENRE(url)

elif mode==8:
        TGENRE(url)

elif mode==9:
        SEARCHM()

elif mode==10:
        SEARCHT()

elif mode==11:
        PT(url)

elif mode==100:
        RESOLVE(name,url,iconimage)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
