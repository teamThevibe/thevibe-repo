# -*- coding: utf-8 -*-		
		
import xbmc		
		
if __name__ == '__main__':		
        xbmc.executebuiltin('xbmc.activatewindow(subtitlesearch)')









