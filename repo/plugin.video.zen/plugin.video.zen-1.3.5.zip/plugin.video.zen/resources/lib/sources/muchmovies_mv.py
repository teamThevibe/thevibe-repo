# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from requests import get
import re,urllib,urlparse,random,json
from resources.lib.modules import cleantitle
from resources.lib.modules import client


class source:
    def __init__(self):
        self.domains = ['apollogroup.tv']
        self.base_link = 'http://free.apollogroup.tv'
        self.search_link = '/results?q=%s'
        self.key = '?uuid=8831ebba191eefbc'

    def movie(self, imdb, title, year):
        try:
			movie = '/movie/%s' % imdb
			query = self.base_link + movie + self.key
			response = get(query)
			data = json.loads(response.text)
			url = data.replace(" ","%20")
			url = client.replaceHTMLCodes(url)
			url = url.encode('utf-8')
			return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url == None: return sources

            if "720" in url: quality = "HD"
            elif "1080" in url : quality = "1080p"
            else: quality = "SD"

            sources.append({'source': 'gvideo', 'quality': quality, 'provider': 'Muchmovies', 'url': url, 'direct': True, 'debridonly': False})

            return sources
        except:
            return sources


    def resolve(self, url):
        try:
            url = client.request(url, output='geturl')
            if 'requiressl=yes' in url: url = url.replace('http://', 'https://')
            else: url = url.replace('https://', 'http://')
            return url
        except:
            return


