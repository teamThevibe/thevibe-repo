# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import re,urllib,urlparse,hashlib,random,string,json,base64
from resources.lib.modules import control
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import directstream
class source:
    def __init__(self):
        self.domains = ['cafemovie.me']
        self.base_link = 'http://cafemovie.me'
        self.search_link = '/search?q=%s'
        self.api_link = '/api/get_episode/%s/%s'

    def movie(self, imdb, title, year):
        try:
			self.url = []
			cleanmovie = cleantitle.get(title)
			query = self.search_link % (title.replace(' ', '%20'))
			query = urlparse.urljoin(self.base_link, query)
			link = client.request(query)
			r = client.parseDOM(link, 'div', attrs = {'class': 'movie-item-title'})
			for links in r:
				title = client.parseDOM(links, 'a')[0]
				href = client.parseDOM(links, 'a', ret='href')[0]
				title = title.encode('utf-8')
				href = href.encode('utf-8')
				if year in title:
					title = cleantitle.get(title)
					# print ("CAFEMOVIES MOVIES", title, href)
					if title == cleanmovie: 
						href = urlparse.urljoin(self.base_link, href)
						href = href + "/watch"
						linkep = client.request(href)
						r = client.parseDOM(linkep, 'div', attrs = {'class': '"mw-episode-list'})
						for items in r:
							match = re.compile('<a role="button" class="(.*?)" data-target-i="(.*?)" title=".*?" data-target-e="(.*?)">(.*?)</a>').findall(items)
							for title,data_i,data_e,epnumber in match:
								title = title.encode('utf-8')
								data_i = data_i.encode('utf-8')
								data_e = data_e.encode('utf-8')
								epnumber = epnumber.encode('utf-8')				
								if "site-YT" in title:
										api_link = self.api_link % (data_i,data_e)
										url = urlparse.urljoin(self.base_link, api_link)
										# print ("CAFEMOVIES TITLE",data_i,data_e, url)
										self.url.append(url)
			# print ("CAFEMOVIES MOVIES", self.url)
			return self.url
        except:
            return self.url	
			
			
    def tvshow(self, imdb, tvdb, tvshowtitle, year):
        try:
            url = {'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return			

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
			headers = {}
			data = urlparse.parse_qs(url)
			data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			year = data['year'] 
			cleanmovie = cleantitle.get(title)
			data['season'], data['episode'] = season, episode
			seasoncheck = "season%s" % season
			checktitle = cleanmovie + seasoncheck
			self.url = []
			showlist = []
			query = self.search_link % (title.replace(' ', '%20'))
			query = urlparse.urljoin(self.base_link, query)
			link = client.request(query)
			r = client.parseDOM(link, 'div', attrs = {'class': 'movie-item-title'})
			for links in r:
				title = client.parseDOM(links, 'a')[0]
				href = client.parseDOM(links, 'a', ret='href')[0]
				title = cleantitle.get_simple(title)
				title = title.encode('utf-8')
				href = href.encode('utf-8')
				if title == checktitle: 
					href = urlparse.urljoin(self.base_link, href)
					href = href + "/watch"
					linkep = client.request(href)
					r = client.parseDOM(linkep, 'div', attrs = {'class': '"mw-episode-list'})
					for items in r:
						match = re.compile('<a role="button" class="(.*?)" data-target-i="(.*?)" title=".*?" data-target-e="(.*?)">(.*?)</a>').findall(items)
						for title,data_i,data_e,epnumber in match:
							title = title.encode('utf-8')
							data_i = data_i.encode('utf-8')
							data_e = data_e.encode('utf-8')
							epnumber = epnumber.encode('utf-8')				
							if "site-YT" in title:
								if epnumber == episode:
									api_link = self.api_link % (data_i,data_e)
									url = urlparse.urljoin(self.base_link, api_link)
									# print ("CAFEMOVIES TITLE",data_i,data_e,epnumber, url)
									self.url.append(url)


			return self.url
        except:
            return self.url			
			
			
    def sources(self, url, hostDict, hostprDict):
        try:
			sources = []
			for item in self.url:

				result = client.request(item)
				match = re.compile('"sources"(.+?)}', re.DOTALL).findall(result)
				for items in match:
					match2 = re.compile('"(.*?)":\s+"http(.*?)"').findall(items)
					# print ("CAFEMOVIES URLS",match)
					for quality,url in match2:
						
						if "google" in url:
							# print ("CAFEMOVIES URLS PASSED",url)
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							if not "http" in url: url = "http" + url
							if "1080" in quality: quality = "1080p"
							elif "720" in quality: quality = "HD"
							else: quality = "SD"
							# print ("CAFEMOVIES URLS", quality, url)
							sources.append({'source': 'gvideo', 'quality': quality, 'provider': 'Cfmovie', 'url': url, 'direct': True, 'debridonly': False})
			return sources
        except:
            return sources


    def resolve(self, url):
        if 'requiressl=yes' in url: url = url.replace('http://', 'https://')
        else: url = url.replace('https://', 'http://')
        return url
