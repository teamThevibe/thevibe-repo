# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import re,urllib,urlparse,hashlib,random,string,json,base64
from resources.lib.modules import control
from resources.lib.modules import cleantitle
from resources.lib.modules import client
import requests
class source:
    def __init__(self):
        self.domains = ['solarmovie.sc']
        self.base_link = 'http://solarmovie.sc'
        self.info_link = 'http://solarmovie.sc/'
        self.key = base64.b64decode('eHdoMzhpZjM5dWN4')
        self.key2 = base64.b64decode('OHFoZm05b3lxMXV4')
        self.key3 = base64.b64decode('Y3RpdzR6bHJuMDl0YXU3a3F2YzE1M3Vv')
		
    def movie(self, imdb, title, year):
        try:
			self.url = []
			title = cleantitle.getsearch(title)
			cleanmovie = cleantitle.get(title)
			query = "/search/%s.html" % (urllib.quote_plus(title))
			query = urlparse.urljoin(self.base_link, query)
			link = client.request(query)
			r = client.parseDOM(link, 'div', attrs = {'class': 'ml-item'})
			for links in r:
				url = client.parseDOM(links, 'a', ret='data-url')[0]
				title = client.parseDOM(links, 'a', ret='title')[0]
				url = urlparse.urljoin(self.info_link, url)
				infolink = client.request(url)
				match_year = re.search('class="jt-info">(\d{4})<', infolink)
				match_year = match_year.group(1)
				if year in match_year:
					result = client.parseDOM(infolink, 'div', attrs = {'class': 'jtip-bottom'})
					for items in result:
						playurl = client.parseDOM(items, 'a', ret='href')[0]
						referer = "%s" % playurl
						mylink = client.request(referer)
						i_d = re.findall(r'id: "(.*?)"', mylink, re.I|re.DOTALL)[0]
						server = re.findall(r'server: "(.*?)"', mylink, re.I|re.DOTALL)[0]
						type = re.findall(r'type: "(.*?)"', mylink, re.I|re.DOTALL)[0]
						episode_id = re.findall(r'episode_id: "(.*?)"', mylink, re.I|re.DOTALL)[0]
						key_gen = ''.join(random.choice(string.ascii_lowercase + string.digits) for x in range(6))
						cookies = '%s%s%s=%s' % (self.key, episode_id, self.key2, key_gen)
						hash_id = hashlib.md5(episode_id + key_gen + self.key3).hexdigest()
						request_url = self.base_link + '/ajax/get_sources/' + episode_id + '/' + hash_id + '.html'
						self.url.append([request_url,cookies])
			return self.url
        except:
            return self.url
			
			
    def tvshow(self, imdb, tvdb, tvshowtitle, year):
        try:
            url = {'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return			

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
			headers = {}
			data = urlparse.parse_qs(url)
			data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			year = data['year'] 
			title = cleantitle.getsearch(title)
			cleanmovie = cleantitle.get(title)
			data['season'], data['episode'] = season, episode
			seasoncheck = "season%s" % season
			checktitle = cleanmovie + seasoncheck
			self.url = []
			showlist = []
			query = "/search/%s.html" % (urllib.quote_plus(title))
			query = urlparse.urljoin(self.base_link, query)
			link = client.request(query)
			r = client.parseDOM(link, 'div', attrs = {'class': 'ml-item'})
			for links in r:
				season_url = client.parseDOM(links, 'a', ret='href')[0]
				title = client.parseDOM(links, 'a', ret='title')[0]
				title = cleantitle.get(title)
				# print "SOLARMOVIES check URLS %s %s %s %s" % (seasoncheck, season_url, cleanmovie, title)
				if checktitle in title:
						# print "SOLARMOVIES PASSED %s" % (season_url) 
						showlist.append(season_url)
								
			for seasonlist in showlist:			
				mylink = client.request(seasonlist)
				referer = re.findall(r'<a class="mod-btn mod-btn-watch" href="(.*?)" title="Watch movie">', mylink, re.I|re.DOTALL)[0]
				epurl = client.request(referer)
				i_d = re.findall(r'id: "(.*?)"', epurl, re.I|re.DOTALL)[0]
				server = re.findall(r'server: "(.*?)"', epurl, re.I|re.DOTALL)[0]
				type = re.findall(r'type: "(.*?)"', epurl, re.I|re.DOTALL)[0]
				episode_id = re.findall(r'episode_id: "(.*?)"', epurl, re.I|re.DOTALL)[0]
				request_url = self.base_link + '/ajax/v3_movie_get_episodes/' + i_d + '/' + server + '/' + episode_id + '/' + type + '.html'
				headers = {'Accept-Encoding':'gzip, deflate, sdch', 'Referer': referer,
							   'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36',
							   'X-Requested-With':'XMLHttpRequest'}
				s = requests.session()
				episodelink = s.get(request_url, headers=headers).text
				pattern = 'episodes-server-%s"(.+?)/ul>' % server
				match = re.findall(pattern, episodelink, re.DOTALL)[0]
				# print "SOLARMOVIES EPISODELINK %s" % match
				blocks = re.compile('<li(.+?)/li>',re.DOTALL).findall(match)
				for fragment in blocks:
					epnumber = re.findall('title="Episode\s+(\d+):', fragment)[0]
					episode = "%02d" % (int(episode))
					epnumber = "%02d" % (int(epnumber))
					# print "EPISODE NUMBER %s %s" % (epnumber, episode)
					if epnumber == episode:
						epid = re.findall('id="episode-(\d+)"', fragment)[0]
						episode_id = epid
						# print "EPISODE NNUMBER Passed %s %s" % (epnumber, episode)
						key_gen = ''.join(random.choice(string.ascii_lowercase + string.digits) for x in range(6))
						cookies = '%s%s%s=%s' % (self.key, episode_id, self.key2, key_gen)
						hash_id = hashlib.md5(episode_id + key_gen + self.key3).hexdigest()
						request_url = self.base_link + '/ajax/get_sources/' + episode_id + '/' + hash_id + '.html'
												
						self.url.append([request_url,cookies])


			return self.url
        except:
            return self.url			
			
			
    def sources(self, url, hostDict, hostprDict):
        try:
			sources = []
			for movielink,cookies in self.url:
				referer = movielink
				headers = {'Accept-Encoding':'gzip, deflate, sdch', 'Cookie': cookies, 'Referer': referer,
							   'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36',
							   'X-Requested-With':'XMLHttpRequest'}
				s = requests.session()			   
				result = s.get(referer, headers=headers).json()
				links = result['playlist'][0]['sources']
				for item in links:
					videoq = item['label']
					url = item['file']
					if "1080" in videoq: quality = "1080p" 
					elif "720" in videoq: quality = "HD"
					else: quality = "SD"
					url = client.replaceHTMLCodes(url)
					url = url.encode('utf-8')
					sources.append({'source': 'gvideo', 'quality': quality, 'provider': 'Solar', 'url': url, 'direct': True, 'debridonly': False})
			return sources
        except:
            return sources


    def resolve(self, url):
        if 'requiressl=yes' in url: url = url.replace('http://', 'https://')
        else: url = url.replace('https://', 'http://')
        return url
