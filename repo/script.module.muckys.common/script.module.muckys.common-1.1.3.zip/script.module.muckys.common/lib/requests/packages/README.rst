If you are planning to submit a pull request to requests with any changes in
this library do not go any further. These are independent libraries which we
vendor into requests. Any changes necessary to these libraries must be made in
them and submitted as separate pull requests to those libraries.

urllib3 pull requests go here: https://github.com/shazow/urllib3

chardet pull requests go here: https://github.com/chardet/chardet

idna pull requests go here: https://github.com/kjd/idna

See https://github.com/kennethreitz/requests/pull/1812#issuecomment-30854316
for the reasoning behind this.
