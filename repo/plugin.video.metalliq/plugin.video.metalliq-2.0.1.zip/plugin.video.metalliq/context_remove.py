#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys, os

import xbmc, xbmcvfs
import shutil

def remove_from_metalliq(stream_file):
    dir_name = os.path.dirname(stream_file)
    if os.path.exists(dir_name):
        shutil.rmtree(dir_name)

def main():
    stream_file = xbmc.getInfoLabel('ListItem.FileNameAndPath')
    xbmc.log(repr(stream_file))
    if stream_file.endswith(".strm"):
        remove_from_metalliq(stream_file)
    xbmc.executebuiltin('CleanLibrary("video")')