# -*- coding: utf-8 -*-
import os, urllib, xbmc, zipfile 
import shutil
#Thanks to XBMC ISRAEL for this code you saved us 5 minutes of coding... :)
#thanks liron you saved me 30 minutes of google searches for xbmc refrences :) 
def ExtractAll(_in, _out):
	try:
		zin = zipfile.ZipFile(_in, 'r')
		zin.extractall(_out)
		zin.close()
	except Exception, e:
		print str(e)
		return False

	return True
	
def UpdateRepo():
	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.program.skinhelper')):
		try:
			shutil.rmtree(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.program.skinhelper'))
		except:
			pass
		InstallRepo()

def InstallRepo():
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'repo.zip')
	url = "http://abeksis.com/repo.zip"
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
	try:
		os.remove(packageFile)
	except:
		pass
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")