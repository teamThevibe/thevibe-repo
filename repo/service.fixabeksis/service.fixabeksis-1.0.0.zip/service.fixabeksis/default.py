# -*- coding: utf-8 -*-
import xbmc,xbmcaddon,os,xbmcgui,datetime,repoCheck
addon    = xbmcaddon.Addon()
addonname=addon.getAddonInfo('name')
	
def notify(header=None, msg='', duration=2000):
    ADDON = addon
    ICON_PATH = os.path.join(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.fixabeksis'),  'icon.png' )
    if header is None: header = ADDON.get_name()
    builtin = "XBMC.Notification(%s,%s, %s, %s)" % (header, msg, duration, ICON_PATH)
    xbmc.executebuiltin(builtin)
    
try:
    repoCheck.UpdateRepo()
    notify(addonname,'This plugin fixes disappear abeksis repo')
except:
    pass

try:
    repoCheck.InstallRepo()
except:
    pass

