#!/usr/bin/python

import os, sys, urllib, json, re, shutil, glob
import xbmcaddon, xbmcgui, xbmc, time
import json

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'resources'))
from pyga.ga import track_event, track_page
		
def slugify(text):
    return re.sub(r'\W+', '-', text.lower())

def GetMovieSearchQuery():
	q = "year_s="+Addon.getSetting("year_s")+"&year_e="+Addon.getSetting("year_e")
	q = q+"&rating="+Addon.getSetting("rating")
	if Addon.getSetting("subs") == "true":
		q = q+"&subs=1"

	if Addon.getSetting("limitMovies") > 0:
		q = q+"&limit="+Addon.getSetting("limitMovies")
	
	if Addon.getSetting("genre_0") == "true":
		q = q+"&genre=all"
	else:
		genre_q = ""
		genres = [12,14,16,18,27,28,35,36,37,53,80,99,878,9648,10402,10749,10751,10752,10769,10770]
		for genre in genres:
			if Addon.getSetting("genre_%d"%(genre)) == "true":
				genre_q = genre_q+"%d,"%(genre)
		q = q+"&genre="+genre_q
	return q

def UpdateMovies(libraryFolderMovies):
	q = GetMovieSearchQuery()
	url = "http://wall.thewiz.info/movie.php?"+q
	try:
		response = urllib.urlopen(url)
		data = json.loads(response.read())
		print "*** {0}: Wall.Sync: Movie API {1}".format(AddonName,q.decode("utf-8"))
	except:
		data = ""
		print "*** {0}: Wall.Sync: FAIL Movie API {1}".format(AddonName,q.decode("utf-8"))
		pass

	folders = []
	# Add new Movies
	for movie in data:
		movie_name = movie['title']+" ("+movie['year']+")"
		folders.append(movie_name)
		MovieFolder = xbmc.translatePath(os.path.join(libraryFolderMovies, movie_name)).decode("utf-8")
		if not os.path.exists(MovieFolder):
			os.makedirs(MovieFolder)
			NFOFile = xbmc.translatePath(os.path.join(MovieFolder, movie_name+".nfo")).decode("utf-8")
			f = open(NFOFile, 'w')
			f.write("http://www.imdb.com/title/"+movie['imdb']+"/")
			f.close()
			
			StrFile = xbmc.translatePath(os.path.join(MovieFolder, movie_name+".strm")).decode("utf-8")
			Str = {'imdb':movie['imdb'],'trakt':movie['trakt'],'year':movie['year'],'name':movie_name,'title':movie['title'].decode("utf-8"),'slug':slugify(movie['title'])+"+"+movie['year'],'url':"http://www.imdb.com/title/"+movie['imdb']+"/"}
			f = open(StrFile, 'w')
			f.write("plugin://plugin.video.thewiz.wall/?wall=movies&"+urllib.urlencode(Str))
			f.close()
			
			#MovieDate = int(movie['date'])
			#os.utime(MovieFolder,(MovieDate,MovieDate))
			#os.utime(StrFile,(MovieDate,MovieDate))
			#os.utime(NFOFile,(MovieDate,MovieDate))
	
	# Add remove Movies by filter
	if Addon.getSetting("RemoveFiles") == "true":
		CleanDBnFiles(folders,libraryFolderMovies,2)

def GetTVSearchQuery():
	q = "year_s="+Addon.getSetting("year_s_tv")+"&year_e="+Addon.getSetting("year_e_tv")
	q = q+"&rating="+Addon.getSetting("rating_tv")
	
	if Addon.getSetting("limitTv") > 0:
		q = q+"&limit="+Addon.getSetting("limitTv")

	if Addon.getSetting("genre_0_tv") == "true":
		q = q+"&genre=all"
	else:
		genre_q = ""
		for genre in range(1, 28):
			if Addon.getSetting("genre_%d_tv"%(genre)) == "true":
				genre_q = genre_q+"%d,"%(genre)
		q = q+"&genre="+genre_q
	return q

def UpdateTV(libraryFolderTV):
	# Get TV Info
	q = GetTVSearchQuery()
	url = "http://wall.thewiz.info/tv.php?"+q
	try:
		response = urllib.urlopen(url)
		data = json.loads(response.read())
		print "*** {0}: Wall.Sync: TV API {1}".format(AddonName,q.decode("utf-8"))
	except:
		data = ""
		print "*** {0}: Wall.Sync: FAIL TV API {1}".format(AddonName,q.decode("utf-8"))
		pass

	folders = []
	# Add new TV Shows
	for tv in data:
		if tv['year'] in tv['title']:
			tv_name = tv['title']
			slug = slugify(tv_name)
		else:
			tv_name = tv['title']+" ("+tv['year']+")"
			slug = slugify(tv['title'])+" ("+tv['year']+")"
		folders.append(tv_name)
		TVFolder = xbmc.translatePath(os.path.join(libraryFolderTV, tv_name)).decode("utf-8")
		if not os.path.exists(TVFolder):
			os.makedirs(TVFolder)
			NFOFile = xbmc.translatePath(os.path.join(TVFolder, "tvshow.nfo")).decode("utf-8")
			f = open(NFOFile, 'w')
			f.write("http://thetvdb.com/index.php?tab=series&id="+tv['tvdb'])
			f.close()
		try:
			season = tv['season']
			for i in season.keys():
				if season[i]>0:
					SeasonFolder = xbmc.translatePath(os.path.join(libraryFolderTV, tv_name,'Season %02d'%int(i))).decode("utf-8")
					if not os.path.exists(SeasonFolder):
						os.makedirs(SeasonFolder)
					for x in range(1,(int(season[i])+1)):
						StrFile = xbmc.translatePath(os.path.join(libraryFolderTV, tv_name,'Season %02d'%int(i), tv['title']+' S%02d'%int(i)+'E%02d'%int(x)+".strm")).decode("utf-8")
						if not os.path.exists(StrFile):
							Str = {'tmdb':tv['tmdb'],'imdb':tv['imdb'],'trakt':tv['trakt'],'year':tv['year'],'title':tv['title'],'slug':slug,'url':"http://www.imdb.com/title/"+tv['imdb']+"/",'episode':x,"season":i,"show":tv_name,"name":tv['title']+' S%02d'%int(i)+'E%02d'%int(x),"tvdb":tv['tvdb']}
							f = open(StrFile, 'w')
							f.write("plugin://plugin.video.thewiz.wall/?wall=tv&"+urllib.urlencode(Str))
							f.close()
		except:
			pass
	
	# Add remove Movies by filter
	if Addon.getSetting("RemoveFiles") == "true":
		CleanDBnFiles(folders,libraryFolderTV,1)		
	
def CheckRepo():
	repo = 'repository.TheWiz'
	folder = xbmc.translatePath(os.path.join('special://home','addons',repo))
	if not os.path.isdir(folder):
		os.makedirs(folder)
		xml_file = xbmc.translatePath(os.path.join('special://home','addons',repo,'addon.xml'))
		urllib.urlretrieve ("http://repo.thewiz.info/"+repo+"/addon.xml", xml_file)

def json_query(query):

	xbmc_request = json.dumps(query)
	raw = xbmc.executeJSONRPC(xbmc_request)
	clean = unicode(raw, 'utf-8', errors='ignore')
	response = json.loads(clean)
	result = response.get('result', response)

	return result

def CleanDBnFiles(FoldersRemove,libraryFolder,type):

	# Check type movie or TV
	if type==1:
		method = "VideoLibrary.GetTVShows"
		array = 'tvshows'
		key = 'tvshowid'
		methodRemove = "VideoLibrary.RemoveTVShow"
	else:
		method = "VideoLibrary.GetMovies"
		array = 'movies'
		key = 'movieid'
		methodRemove = "VideoLibrary.RemoveMovie"
	
	# Remove from DB
	remove_data = json_query({"jsonrpc": "2.0","id": 1, "method": method,  "params": { "properties" : ['title', 'imdbnumber','file'] }})

	if array in remove_data and remove_data[array]:
		remove2_data = remove_data[array]
		for show in remove2_data:
			ff = os.path.basename(os.path.normpath(show['file']))
			ff2 = os.path.splitext(ff)[0]
			if not ff2 in FoldersRemove:
				if "plugin.video.thewiz.wall" in show['file']:
					result = json_query({"jsonrpc": "2.0","id": 1, "method": methodRemove,  "params": { key : show[key] }})
				#print "****** Remove {0} {1} {2} {3} {4} {5}".format(key,show['title'].encode('utf-8'),show['imdbnumber'].encode('utf-8'),(", ").join(result),show['file'].encode('utf-8'),ff.encode('utf-8'),ff2.encode('utf-8'))
	
	# Remove folders
	filelist = glob.glob(xbmc.translatePath(os.path.join(libraryFolder,"*")))
	if filelist != []:
		for f in filelist:
			ff = os.path.basename(os.path.normpath(f))
			if not ff in FoldersRemove:
				try:
					shutil.rmtree(f)
				except:
					pass
	
def main():
	addonID = "plugin.video.thewiz.wall"
	Addon = xbmcaddon.Addon(addonID)
	global AddonName,baseUrl,Addon
	AddonName = Addon.getAddonInfo("name")
	AddonPath = Addon.getAddonInfo("path")
	CheckRepo()
	
	libraryFolder = "special://userdata/addon_data/plugin.video.thewiz.wall/library/"
	libraryFolderMovies = "special://userdata/addon_data/plugin.video.thewiz.wall/library/movies/"
	libraryFolderTV = "special://userdata/addon_data/plugin.video.thewiz.wall/library/tv/"

	if Addon.getSetting("useStreamMovies") == "true":
		UpdateMovies(libraryFolderMovies)

	if Addon.getSetting("useStreamTV") == "true":
		UpdateTV(libraryFolderTV)

	xbmc.executebuiltin('Notification({0}, TheWiz.Wall Updated, {1}, {2})'.format(AddonName, 5000,os.path.join( AddonPath ,"icon.png" )))
	if Addon.getSetting("UpdateVideo") == "true":
		time.sleep(5)
		while xbmc.getCondVisibility('Library.IsScanning') or xbmc.getCondVisibility('Window.IsActive(10101)'):
			time.sleep(5)
		xbmc.executebuiltin('UpdateLibrary({0})'.format('video'))

	sys.exit(1)