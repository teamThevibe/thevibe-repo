# -*- coding: utf-8 -*-
# thanks to TheWiz Addon Installer....
# Thanks to Blazetamer, Eleazar Coding, Showgun, TheHighway, ....
import requests,shutil, json, sys, os, xbmcgui, time, xbmc, urllib, urllib2, re, zipfile ,xbmcaddon
from xml.dom import minidom

dialog       =  xbmcgui.Dialog()

Config = xbmcaddon.Addon('plugin.program.repotools')

def AddonInstaller(id):
	global repo_addons
	if id in repo_addons:
		url = repo_addons[id]
		local_filename = url.split('/')[-1]
	else:
		print "*** {0}: ERROR: {1} don't exist in Repo".format(AddonName,id)
		return 0
	addonsfolder = xbmc.translatePath(os.path.join('special://','home','addons'))
	if os.path.isdir(os.path.join(addonsfolder,id)):
		print "*** {0}: Exist {1} in Kodi".format(AddonName,id)
		return 0
	packfolder = xbmc.translatePath(os.path.join('special://','home','addons','packages'))
	dp = xbmcgui.DialogProgress(); 
	dp.create("Senyor Tools"," מוריד "+id,'','נא להמתין')
	addon_zip = os.path.join(packfolder,local_filename)
	try: os.remove(addon_zip)
	except: pass
	print "*** {0}: Downloading {1}".format(AddonName,id)
	download_try=0
	while True:
		AddonDownload(url,addon_zip,dp)
		try:
			test_zip_file = zipfile.ZipFile(addon_zip)
			ret = test_zip_file.testzip()
			if ret is None:
				break
		except:pass
		download_try += 1
		xbmc.sleep(4000)
		if download_try>4:
			OKmsg("תקלה בהורדה",'לא ניתן להוריד את ההרחבה','לתמיכה חפשו אותנו בפייסבוק','Kodi Senyor')
			print "*** {0}: Error Downloading {1}".format(AddonName,id)
			return 1
	time.sleep(2)
	print "*** {0}: Extracting {1}".format(AddonName,local_filename)
	dp.update(0,"Extracting Zip {0}".format(id),"",'פורס קבצים')
	AddonExtract(addon_zip,addonsfolder,dp)
	try:
		depends = xbmc.translatePath(os.path.join(addonsfolder,id,'addon.xml')); 
		source = open(depends,mode='r'); line=source.read(); source.close();
		regex =ur'import addon="(.+?)"'
		addon_requires = re.findall(regex, line)
		for addon_require in addon_requires:
			if not 'xbmc.' in addon_require:
				dependspath = xbmc.translatePath(os.path.join('special://home/addons',addon_require))
				if not os.path.exists(dependspath): 
					AddonInstaller(addon_require)
	except:pass

def OKmsg(title, line1, line2="", line3=""):
	xbmcgui.Dialog().ok(title, line1, line2, line3)	
	
def AddonDownload(source, target,dp = None):
	if not dp:
		dp = xbmcgui.DialogProgress()
		dp.create("מצב...","בודק התקנה",' ', ' ')
	dp.update(0)
	r = requests.get(source, stream=True, timeout=10)
	try:
		total_size = r.headers['content-length'].strip()
		total_size = int(total_size)
	except:
		return
	bytes_so_far = 0

	with open(target, 'wb') as fp:
		try:
			for chunk in r.iter_content(chunk_size=(1024*8)):
				if chunk:
					bytes_so_far += len(chunk)
					percent = min((100*bytes_so_far/total_size), 100)
					dp.update(percent)

					fp.write(chunk)

					if dp.iscanceled():
						raise Exception("Canceled")
						fp.close();	r.close(); dp.close()
						return 0
		except:pass
	fp.close()
	r.close()
	return 1

def AddonExtract(_in, _out, dp):
    zin = zipfile.ZipFile(_in,  'r')
    nFiles = float(len(zin.infolist()))
    count  = 0

    try:
        for item in zin.infolist():
            count += 1
            update = count / nFiles * 100
            dp.update(int(update))
            zin.extract(item, _out)
    except Exception, e:
        print str(e)
        return False

    return True

def upd():
    xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
    xbmc.executebuiltin("XBMC.UpdateAddonRepos()")
	
def GetRepoInfo(repo):
	global repo_addons
	u1=urllib2.urlopen(repo+"addons.xml")
	dom=minidom.parse(u1)
	addons = dom.getElementsByTagName("addon")
	for addon in addons:
		id = addon.getAttribute("id")
		version = addon.getAttribute("version")
		repo_addons[id] = repo+id+"/"+id+"-"+version+".zip"

	return 1


def GetRepoInfob(repo):
	global repo_addons
	u1=urllib2.urlopen(repo+"addons.xml")
	dom=minidom.parse(u1)
	addons = dom.getElementsByTagName("addon")
	for addon in addons:
		id = addon.getAttribute("id")
		version = addon.getAttribute("version")
		repo_addons[id] = repo+"/repo/"+id+"/"+id+"-"+version+".zip"

	return 1

def GetRepoInfoc(repo):
	global repo_addons
	u1=urllib2.urlopen(repo+"addons.xml")
	dom=minidom.parse(u1)
	addons = dom.getElementsByTagName("addon")
	for addon in addons:
		id = addon.getAttribute("id")
		version = addon.getAttribute("version")
		repo_addons[id] = repo+"/Zips/"+id+"/"+id+"-"+version+".zip"

	return 1	
	

	return 1	
	
def GetRepoInfod(repo):
	global repo_addons
	u1=urllib2.urlopen(repo+"addons.xml")
	dom=minidom.parse(u1)
	addons = dom.getElementsByTagName("addon")
	for addon in addons:
		id = addon.getAttribute("id")
		version = addon.getAttribute("version")
		repo_addons[id] = repo+"/zips/"+id+"/"+id+"-"+version+".zip"

	return 1	

def benab():
    xbmc_version=xbmc.getInfoLabel("System.BuildVersion")
    version=float(xbmc_version[:4])

    if version >= 15.0 and version <= 15.9:
		pass
    if version >= 16.0 and version <= 16.9:
		pass
    if version >= 17.0 and version <= 17.9:
		xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.repotools/resources/art/ganab.py)')
		time.sleep(30)

	
def prcolor():
    xbmc_version=xbmc.getInfoLabel("System.BuildVersion")
    version=float(xbmc_version[:4])


    if version >= 15.0 and version <= 15.9:
		GetRepoInfo("http://mirror.onet.pl/pub/mirrors/kodi/addons/jarvis/")
    if version >= 16.0 and version <= 16.9:
		GetRepoInfo("http://mirror.onet.pl/pub/mirrors/kodi/addons/jarvis/")
    if version >= 17.0 and version <= 17.9:
		GetRepoInfo("http://mirror.onet.pl/pub/mirrors/kodi/addons/krypton/")

global repo_addons, AddonName
Addon = xbmcaddon.Addon
AddonName = ("name")
repo_addons = {}

Config.openSettings()
	

GetRepoInfoc("https://raw.githubusercontent.com/kobiko3030/repository.kodisenyor/master/")
GetRepoInfo("https://raw.githubusercontent.com/finalmakerr/featherence/master/")
GetRepoInfob("https://raw.githubusercontent.com/kodil/kodil/master/")
GetRepoInfo("http://repo.thewiz.info/")
#GetRepoInfob("https://raw.githubusercontent.com/tmkodirepo/repository.ToMeRepo2/master/")
prcolor()
GetRepoInfod("http://github.com/tknorris/tknorris-beta-repo/raw/master/")


if Config.getSetting("ToMeRepo") == 'true':
    AddonInstaller("repository.ToMeRepo")
	
if Config.getSetting("hetrailers") == 'true':
    AddonInstaller("plugin.video.he-trailers")

if Config.getSetting("TheWiz") == 'true':
    AddonInstaller("repository.TheWiz")

if Config.getSetting("kodisrael") == 'true':
    AddonInstaller("repository.kodil")
	
if Config.getSetting("featherence") == 'true':
    AddonInstaller("repository.featherence")

if Config.getSetting("xbmcisrael") == 'true':
    AddonInstaller("repository.xbmc-israel")	
	
if Config.getSetting("thevibe") == 'true':
    AddonInstaller("repository.thevibe")

if Config.getSetting("hetrailers") == 'true':
    AddonInstaller("plugin.video.he-trailers")

if Config.getSetting("Vodil") == 'true':
    AddonInstaller("plugin.video.Vodil")
	
if Config.getSetting("AnarchiTV") == 'true':
    AddonInstaller("plugin.video.anarchitv")

if Config.getSetting("Exodus") == 'true':
    AddonInstaller("repository.exodus")
    AddonInstaller("plugin.video.exodus")

if Config.getSetting("salts") == 'true':
    AddonInstaller("repository.tknorris.beta")
    AddonInstaller("plugin.video.salts")
	
if Config.getSetting("zen") == 'true':
    AddonInstaller("plugin.video.zen")

if Config.getSetting("sanctuary") == 'true':
    AddonInstaller("plugin.video.sanctuary")	
	
if Config.getSetting("Phoenix") == 'true':
    AddonInstaller("plugin.video.phstreams")

if Config.getSetting("specto") == 'true':
    AddonInstaller("repository.filmkodi.com")
    AddonInstaller("plugin.video.specto")

if Config.getSetting("Evolve") == 'true':
    AddonInstaller("plugin.video.Evolve")
	
if Config.getSetting("ccloudtv") == 'true':
    AddonInstaller("plugin.video.ccloudtv")

if Config.getSetting("makoTV") == 'true':
    AddonInstaller("plugin.video.MakoTV")	
	
if Config.getSetting("walla") == 'true':
    AddonInstaller("plugin.video.wallaNew.video")
	
if Config.getSetting("reshet") == 'true':
    AddonInstaller("plugin.video.reshet.video")

if Config.getSetting("channelten") == 'true':
    AddonInstaller("plugin.video.tenil")

if Config.getSetting("channelone") == 'true':
    AddonInstaller("plugin.video.IBA")
	
if Config.getSetting("hotvod") == 'true':
    AddonInstaller("plugin.video.hotVOD.video")

if Config.getSetting("KidsIl") == 'true':
    AddonInstaller("plugin.video.KIDSIL")

if Config.getSetting("nostalgia") == 'true':
    AddonInstaller("plugin.video.nostalgia")	
	
if Config.getSetting("nirepo") == 'true':
    AddonInstaller("repository.nirepo")
	
if Config.getSetting("superrepo") == 'true':
    AddonInstaller("superrepo.kodi.jarvis.all")

if Config.getSetting("xunitytalk") == 'true':
    AddonInstaller("repository.xunitytalk")

if Config.getSetting("xbmchub") == 'true':
    AddonInstaller("repository.xbmchub")
	
if Config.getSetting("wizsubs") == 'true':
    AddonInstaller("service.subtitles.thewiz")	
	
if Config.getSetting("DandyMedia") == 'true':
    AddonInstaller("plugin.video.dandymedia")

if Config.getSetting("KMusicTube") == 'true':
    AddonInstaller("plugin.video.kmusictube")	

if Config.getSetting("FeatherenceMusic") == 'true':
    AddonInstaller("plugin.video.featherence.music")

if Config.getSetting("Jango") == 'true':
    AddonInstaller("plugin.audio.jango")	
	
if Config.getSetting("TheMusicSource") == 'true':
    AddonInstaller("plugin.video.The-Music-Source")
	
if Config.getSetting("ProjectM") == 'true':
    AddonInstaller("plugin.video.projectm")	
	
if Config.getSetting("livehd") == 'true':
    AddonInstaller("plugin.video.alive.hd")

if Config.getSetting("channelten") == 'true':
    AddonInstaller("plugin.video.tenil")

if Config.getSetting("Decado") == 'true':
    AddonInstaller("plugin.video.DecadoDocs")
	
if Config.getSetting("Featherencedocu") == 'true':
    AddonInstaller("plugin.video.featherence.docu")
	
if Config.getSetting("israelive") == 'true':
    AddonInstaller("plugin.video.israelive")	

if Config.getSetting("Documentarytube") == 'true':
    AddonInstaller("plugin.video.documentarytube")

if Config.getSetting("iconspire") == 'true':
    AddonInstaller("plugin.video.iconspire")	
	
if Config.getSetting("Brettus") == 'true':
    AddonInstaller("plugin.video.Brettus.Documentaries")
	
if Config.getSetting("subcenter") == 'true':
    AddonInstaller("service.subtitles.subscenter")

if Config.getSetting("ktuvit") == 'true':
    AddonInstaller("service.subtitles.subtitle")

if Config.getSetting("torec") == 'true':
    AddonInstaller("service.subtitles.torec")
	
if Config.getSetting("opensubtitles") == 'true':
    AddonInstaller("service.subtitles.opensubtitles")

if Config.getSetting("ninfm") == 'true':
    AddonInstaller("plugin.audio.99fm-playlists")	

if Config.getSetting("mimfm") == 'true':
    AddonInstaller("plugin.audio.100fm")		
	
time.sleep(2)
xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
xbmc.executebuiltin("XBMC.UpdateAddonRepos()")
time.sleep(5)
benab()
 


dialog.ok("[COLOR green][B]הרחבות בקליק[/B][/COLOR]", 'התקנת ההרחבות הסתיימה')

time.sleep(5)
benab()


