#!/usr/bin/env python
# -*- coding: utf-8 -*-
# thanks to tomer haimovitch and the wiz

import os,sys,urllib
import xbmcaddon,xbmcplugin,xbmcgui,json, time
import reqwest
import shutil

jsonSetFont = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"Arial"}, "id":1}'

Config = xbmcaddon.Addon()
dialog = xbmcgui.Dialog()
Progress = xbmcgui.DialogProgress()
xbmc.executeJSONRPC(jsonSetFont)
reqwest.requests()
reqwest.requestsen()
time.sleep(1)
xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.repotools/resources/art/kill.py)') 


Config.setSetting(id='ToMeRepo', value='false')
Config.setSetting(id='TheWiz', value='false')
Config.setSetting(id='kodisrael', value='false')
Config.setSetting(id='featherence', value='false')
Config.setSetting(id='abeksis', value='false')
Config.setSetting(id='xbmcisrael', value='false')
Config.setSetting(id='thevibe', value='false')
Config.setSetting(id='superrepo', value='false')
Config.setSetting(id='xunitytalk', value='false')
Config.setSetting(id='xbmchub', value='false')
Config.setSetting(id='nirepo', value='false')
Config.setSetting(id='sanctuary', value='false')
Config.setSetting(id='Exodus', value='false')
Config.setSetting(id='israelive', value='false')
Config.setSetting(id='salts', value='false')
Config.setSetting(id='zen', value='false')
Config.setSetting(id='ProjectM', value='false')
Config.setSetting(id='Phoenix', value='false')
Config.setSetting(id='AnarchiTV', value='false')
Config.setSetting(id='specto', value='false')
Config.setSetting(id='Vodil', value='false')
Config.setSetting(id='meta', value='false')
Config.setSetting(id='ccloudtv', value='false')
Config.setSetting(id='hetrailers', value='false')
Config.setSetting(id='makoTV', value='false')
Config.setSetting(id='walla', value='false')
Config.setSetting(id='reshet', value='false')
Config.setSetting(id='channelten', value='false')
Config.setSetting(id='channelone', value='false')
Config.setSetting(id='Evolve', value='false')
Config.setSetting(id='DandyMedia', value='false')
Config.setSetting(id='nostalgia', value='false')
Config.setSetting(id='moviesil', value='false')
Config.setSetting(id='hotvod', value='false')
Config.setSetting(id='KidsIl', value='false')
Config.setSetting(id='AlphaMovies', value='false')

Config.setSetting(id='KMusicTube', value='false')
Config.setSetting(id='TheMusicSource', value='false')
Config.setSetting(id='FeatherenceMusic', value='false')
Config.setSetting(id='Jango', value='false')
Config.setSetting(id='livehd', value='false')
Config.setSetting(id='ninfm', value='false')
Config.setSetting(id='mimfm', value='false')

Config.setSetting(id='Decado', value='false')
Config.setSetting(id='Featherencedocu', value='false')
Config.setSetting(id='Documentarytube', value='false')
Config.setSetting(id='iconspire', value='false')
Config.setSetting(id='Brettus', value='false')

Config.setSetting(id='subcenter', value='false')
Config.setSetting(id='wizsubs', value='false')
Config.setSetting(id='torec', value='false')
Config.setSetting(id='ktuvit', value='false')
Config.setSetting(id='opensubtitles', value='false')

Config.setSetting(id='Exodus_Settings', value='false')
Config.setSetting(id='Salts_Settings', value='false')
Config.setSetting(id='Meta_Settings', value='false')
Config.setSetting(id='Specto_Settings', value='false')
Config.setSetting(id='Pvr_Settings', value='false')


sys.exit()

