import sys, traceback, urllib, xbmcaddon
from lib import common
from datetime import datetime

#with open(common.Paths.rootDir+'//test.txt', 'a') as Opened_File:
	#Opened_File.write("test\n")

def code():
	try:
		#ipCounter
		if(xbmcaddon.Addon(id = 'plugin.video.RoiD').getSetting('ipChecker')=="true"):
			myip = urllib.urlopen("http://whatismyip.akamai.com/").read()
			url = "http://roid.webutu.com/Files/ipCounter.php?ip="+myip
			urllib.urlopen(url)
			xbmcaddon.Addon(id = 'plugin.video.RoiD').setSetting('ipChecker',"false")
		#Yes/No Adult
		#if(xbmcaddon.Addon(id = 'plugin.video.RoiD').getSetting('Adult')=="true"):
			#with open(common.Paths.rootDir+'//resources//modules//Channels//_Channels_Menu_YesAdult.cfg', 'r') as _Channels_Menu_YesAdult_File:
				#with open(common.Paths.rootDir+'//resources//modules//Channels//_Channels_Menu.cfg', 'wb') as _Channels_Menu_File:
					#_Channels_Menu_File.write(_Channels_Menu_YesAdult_File.read())
		#else:
			#with open(common.Paths.rootDir+'//resources//modules//Channels//_Channels_Menu_NoAdult.cfg', 'r') as _Channels_Menu_NoAdult_File:
				#with open(common.Paths.rootDir+'//resources//modules//Channels//_Channels_Menu.cfg', 'wb') as _Channels_Menu_File:
					#_Channels_Menu_File.write(_Channels_Menu_NoAdult_File.read())
	except:
		traceback.print_exc(file = sys.stdout)