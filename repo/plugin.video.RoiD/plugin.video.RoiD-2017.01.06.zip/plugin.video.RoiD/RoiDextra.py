import sys, traceback, urllib, xbmcaddon
from lib import common
from datetime import datetime


def code():
	try:
		#ipCounter
		if(xbmcaddon.Addon(id = 'plugin.video.RoiD').getSetting('ipChecker')=="true"):
			myip = urllib.urlopen("http://whatismyip.akamai.com/").read()
			url = "http://roid.webutu.com/Files/ipCounter.php?ip="+myip
			urllib.urlopen(url)
			xbmcaddon.Addon(id = 'plugin.video.RoiD').setSetting('ipChecker',"false")
		#Yes/No Israeli Sport
		if(xbmcaddon.Addon(id = 'plugin.video.RoiD').getSetting('IsraeliSport')=="true"):
			with open(common.Paths.rootDir+'//resources//modules//Channels_Israel//_Channels_Israel_YesSport.cfg', 'r') as _Channels_Israel_YesSport_File:
				with open(common.Paths.rootDir+'//resources//modules//Channels_Israel//_Channels_Israel.cfg', 'wb') as _Channels_Israel_File:
					_Channels_Israel_File.write(_Channels_Israel_YesSport_File.read())
		else:
			with open(common.Paths.rootDir+'//resources//modules//Channels_Israel//_Channels_Israel_NoSport.cfg', 'r') as _Channels_Israel_NoSport_File:
				with open(common.Paths.rootDir+'//resources//modules//Channels_Israel//_Channels_Israel.cfg', 'wb') as _Channels_Israel_File:
					_Channels_Israel_File.write(_Channels_Israel_NoSport_File.read())
		#Yes/No Adult
		if(xbmcaddon.Addon(id = 'plugin.video.RoiD').getSetting('Adult')=="true"):
			with open(common.Paths.rootDir+'//resources//modules//Channels//_Channels_YesAdult.cfg', 'r') as _Channels_YesAdult_File:
				with open(common.Paths.rootDir+'//resources//modules//Channels//_Channels.cfg', 'wb') as _Channels_File:
					_Channels_File.write(_Channels_YesAdult_File.read())
		else:
			with open(common.Paths.rootDir+'//resources//modules//Channels//_Channels_NoAdult.cfg', 'r') as _Channels_NoAdult_File:
				with open(common.Paths.rootDir+'//resources//modules//Channels//_Channels.cfg', 'wb') as _Channels_File:
					_Channels_File.write(_Channels_NoAdult_File.read())
		
		#Last Update Resource Files
		serverLastUpdate = urllib.urlopen("http://pastebin.com/raw/PTs12bcx").read()		
		if serverLastUpdate>xbmcaddon.Addon(id = 'plugin.video.RoiD').getSetting('clientLastUpdate'):
			xbmcaddon.Addon(id = 'plugin.video.RoiD').setSetting('clientLastUpdate',str(serverLastUpdate))
			UpdateResourceFiles = urllib.urlopen("http://pastebin.com/raw/nZcM92RJ").read()
			for line in UpdateResourceFiles.split(' '):
				parts = line.split(';')
				with open(common.Paths.rootDir+parts[0], 'wb') as fileToChange:
					fileToChange.write(urllib.urlopen(parts[1]).read())
			xbmcaddon.Addon(id = 'plugin.video.RoiD').setSetting('clientLastUpdate',str(serverLastUpdate))
		
		
	except:
		traceback.print_exc(file = sys.stdout)