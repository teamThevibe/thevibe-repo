import json
import xbmc, xbmcgui, xbmcaddon
# get and set variables
jsonGetPVR = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue", "params":{"setting":"pvrmanager.enabled"}, "id":1}'
jsonSetPVR = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmanager.enabled", "value":%s},"id":1}'
jsonNotify = '{"jsonrpc":"2.0", "method":"GUI.ShowNotification", "params":{"title":"PVR", "message":"%s","image":""}, "id":1}'

# get current pvr status
PVR = json.loads(xbmc.executeJSONRPC(jsonGetPVR))['result']['value']

if (PVR == False):
        # set pvr on
        xbmc.executeJSONRPC(jsonSetPVR % "true")
        xbmc.executeJSONRPC(jsonNotify % "Live TV Enabled")

else:
        pass