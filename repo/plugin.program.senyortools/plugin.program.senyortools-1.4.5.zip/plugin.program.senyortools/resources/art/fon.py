# -*- coding: utf-8 -*-
import json
import xbmc, xbmcgui, xbmcaddon
import time

import videoAddon
import DocuAddon
import addonsettings

jsonSetFont = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"Arial"}, "id":1}'
jsonSetsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.subtitlelanguage","value":"Hebrew"},"id":1}'
jsonSetqewr = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.keyboardlayouts","value":["Hebrew QWERTY","English QWERTY"]},"id":1}'
jsonSetlan = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.he_il"}, "id":1}'
jsonSettorec = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.movie","value":"service.subtitles.opensubtitles"},"id":1}'
jsonSettorectv = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.tv","value":"service.subtitles.opensubtitles"},"id":1}'
jsonSethe = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":44},"id":1}'
jsonSethebsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.languages","value":["Hebrew"]},"id":1}'
jsonSetskin = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.skin","value":"skin.phenomenal"}, "id":1}'



dialog = xbmcgui.Dialog()
Progress = xbmcgui.DialogProgress()


def sets():

 xbmc.executeJSONRPC(jsonSetsub)
 xbmc.executeJSONRPC(jsonSetFont)
 xbmc.executeJSONRPC(jsonSetqewr)
 xbmc.executeJSONRPC(jsonSetlan)
 xbmc.executeJSONRPC(jsonSettorec)
 xbmc.executeJSONRPC(jsonSettorectv)
 xbmc.executeJSONRPC(jsonSethe)
 xbmc.executeJSONRPC(jsonSethebsub)
 xbmc.executebuiltin('XBMC.RefreshRSS')       
 xbmc.executebuiltin('XBMC.ReloadSkin()') 




def fon():
    choice = xbmcgui.Dialog().yesno('[COLOR=green]אשף הגדרת הקודי[/COLOR]', '', 'האם להפעיל את אשף הגדרת הקודי?', nolabel='לא',yeslabel='כן')
    if choice == 0:
        return
    elif choice == 1:
        pass

    Progress.create("מתקין הגדרות", "נא להמתין...")
    sets()
    DocuAddon.subcenter()
    videoAddon.commonplugincache()	
    DocuAddon.opensubtitles()
    DocuAddon.wizsubs()
    videoAddon.requests()	
    choice = xbmcgui.Dialog().yesno('[COLOR=green]הגדרת טלוויזיה חיה[/COLOR]', '', 'האם תרצו להתקין טלוויזיה חיה?', nolabel='לא',yeslabel='כן')
    if choice == 0:
        pass
    elif choice == 1:
        prs()

    choice = xbmcgui.Dialog().yesno('[COLOR=green]התקנת ספריית סרטים וסדרות[/COLOR]', '', 'האם תרצו להתקין ספריית סרטים וסדרות?', nolabel='לא',yeslabel='כן')
    if choice == 0:
        pass
    elif choice == 1:
        wizwall()
				
    
    kodiset()		

def wizwall():
        videoAddon.TheWiz()
        videoAddon.thewizwall()
        dialog.ok('אשף הגדרת הקודי ','במסך הבא הגדירו את ספריית הסרטים והסדרות')	
        videoAddon.TheWizenable()
        videoAddon.thewizwallenable()
        xbmc.executebuiltin('RunScript(plugin.video.thewiz.wall,0,0)')
	

def kodiset():	
    dialog.ok('אשף הגדרת הקודי ','התקנת הרחבות בקליק','במסך הבא בחרו את ההרחבות שתרצו להתקין')	
    xbmc.executebuiltin('RunScript(plugin.program.repotools)')
    videoAddon.subcenterenable()
    videoAddon.subcenteroldenable()
    videoAddon.opensubtitlesenable()

def prs(): 
    Progress.create("מגדיר ומפעיל לקוח טלוויזיה חיה", "נא להמתין...")
    Progress.update(0)
    addonsettings.Prvr_Settings() 
    Progress.update(100)
    videoAddon.prset() 
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.senyortools/ltr.py)')
    UpdateMe()

def UpdateMe():        
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")      
        dialog=xbmcgui.Dialog(); dialog.ok("senyor tools",  "  טלוויזיה חיה הופעלה " ,"","")  

	
fon()	