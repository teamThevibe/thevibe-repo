# -*- coding: utf-8 -*-
import json
import xbmc, xbmcgui, xbmcaddon
import time
import versioncheck
import videoAddon
import DocuAddon
import addonsettings

jsonSetFont = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"Arial"}, "id":1}'
jsonSetsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.subtitlelanguage","value":"Hebrew"},"id":1}'
jsonSetqewr = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.keyboardlayouts","value":["Hebrew QWERTY","English QWERTY"]},"id":1}'
jsonSetlan = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.he_il"}, "id":1}'
jsonSettorec = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.movie","value":"service.subtitles.opensubtitles"},"id":1}'
jsonSettorectv = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.tv","value":"service.subtitles.opensubtitles"},"id":1}'
jsonSethe = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":44},"id":1}'
jsonSethebsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.languages","value":["Hebrew"]},"id":1}'
jsonSetskin = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.skin","value":"skin.phenomenal"}, "id":1}'



dialog = xbmcgui.Dialog()
Progress = xbmcgui.DialogProgress()


def sets():

 xbmc.executeJSONRPC(jsonSetsub)
 xbmc.executeJSONRPC(jsonSetFont)
 xbmc.executeJSONRPC(jsonSetqewr)
 xbmc.executeJSONRPC(jsonSetlan)
 xbmc.executeJSONRPC(jsonSettorec)
 xbmc.executeJSONRPC(jsonSettorectv)
 xbmc.executeJSONRPC(jsonSethe)
 xbmc.executeJSONRPC(jsonSethebsub)
 xbmc.executebuiltin('XBMC.RefreshRSS')       
 xbmc.executebuiltin('XBMC.ReloadSkin()') 


sets()

def fon():

    choice = xbmcgui.Dialog().yesno('[COLOR=green]הגדרת טלוויזיה חיה[/COLOR]', '', 'האם תרצו להתקין טלוויזיה חיה?', nolabel='לא',yeslabel='כן')
    if choice == 0:
        pass
    elif choice == 1:
        prs()

    choice = xbmcgui.Dialog().yesno('[COLOR=green]התקנת ספריית סרטים וסדרות[/COLOR]', '', 'האם תרצו להתקין ספריית סרטים וסדרות?', nolabel='לא',yeslabel='כן')
    if choice == 0:
        pass
    elif choice == 1:
        wizwall()
				
    
    kodiset()		

def wizwall():
        xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.senyortools/resources/art/wall.py)')
        time.sleep(10)
        dialog.ok('אשף הגדרת הקודי ','במסך הבא הגדירו את ספריית הסרטים והסדרות')	
        xbmc.executebuiltin('RunScript(plugin.video.thewiz.wall,0,0)')
	

def kodiset():	
    dialog.ok('אשף הגדרת הקודי ','התקנת הרחבות בקליק','במסך הבא בחרו את ההרחבות שתרצו להתקין')	
    xbmc.executebuiltin('RunScript(plugin.program.repotools)')

	
def prsb():
    xbmc_version=xbmc.getInfoLabel("System.BuildVersion")
    version=float(xbmc_version[:4])


    if version >= 15.0 and version <= 15.9:
		xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.senyortools/resources/art/ltr.py)')
    if version >= 16.0 and version <= 16.9:
		xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.senyortools/resources/art/ltr.py)')
    if version >= 17.0 and version <= 17.9:
		pass

	
def prs(): 
    Progress.create("מגדיר ומפעיל לקוח טלוויזיה חיה", "נא להמתין...")
    Progress.update(0)
    addonsettings.Prvr_Settings() 
    Progress.update(100)
    videoAddon.prset() 
    prsb()
    Updates()

def Updates():        
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")      
        dialog=xbmcgui.Dialog(); dialog.ok("senyor tools",  "  טלוויזיה חיה הופעלה " ,"","")  

	
fon()	