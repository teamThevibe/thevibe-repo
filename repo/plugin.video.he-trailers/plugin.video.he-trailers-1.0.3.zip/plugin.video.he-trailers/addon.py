# -*- coding: utf-8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui,os,sys,datetime
from resources.lib.common_variables import *
from resources.lib.directory import *
from resources.lib.youtubewrapper import *
from resources.lib.watched import * 

fanart = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.he-trailers', 'fanart.jpg'))
art = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.he-trailers/resources/img', ''))

def CATEGORIES():
        addDir('ערוץ טריילרים זאת אומנות','PLMkhzh72OrOy4jiqDmvAcr8bdqlGXOr4B',1,art + '80.png')
        addDir2('טריילרים מתורגמים מאתר סרטים','plugin://plugin.video.youtube/channel/UCrA1_yVsX8bSaKdNiXj0f-w/',15,'https://yt3.ggpht.com/-Qh7eRmeh1cM/AAAAAAAAAAI/AAAAAAAAAAA/5pgkGxEAAxs/s240-c-k-no-mo-rj-c0xffffff/photo.jpg','')
        addDir2('טריילרים מתורגמים אתר סרט','plugin://plugin.video.youtube/channel/UCwLaLrXo8IYqpNfAipy3CGQ/',15,'https://yt3.ggpht.com/-BlzDF8gqZlo/AAAAAAAAAAI/AAAAAAAAAAA/j45U_eWEF4Q/s240-c-k-no-mo-rj-c0xffffff/photo.jpg','')
        addDir2('טריילרים לסרטים ישראליים','plugin://plugin.video.youtube/channel/UCN5mmIG-0CucLSRmdB5hkTQ/',15,'https://i.ytimg.com/i/N5mmIG-0CucLSRmdB5hkTQ/mq1.jpg?v=6bbe9d','')        

def metasearch(url):
    ok=True        
    xbmc.executebuiltin('XBMC.Container.Update(%s)' % url )
    return ok  		
		
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


params=get_params()
url=None
name=None
mode=None
iconimage=None
page = None
token = None

try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except:
	try: 
		mode=params["mode"]
	except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: token=urllib.unquote_plus(params["token"])
except: pass
try: page=int(params["page"])
except: page = 1

print ("Mode: "+str(mode))
print ("URL: "+str(url))
print ("Name: "+str(name))
print ("iconimage: "+str(iconimage))
print ("Page: "+str(page))
print ("Token: "+str(token))

		
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir2(name,url,mode,iconimage,fanart):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
		
				
def create_directory(dir_path, dir_name=None):
    if dir_name:
        dir_path = os.path.join(dir_path, dir_name)
    dir_path = dir_path.strip()
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
    return dir_path

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        return_youtubevideos(name,url,token,page)

elif mode==5: 
        play_youtube_video(url)

elif mode==6:
        mark_as_watched(url)

elif mode==7:
        removed_watched(url)

elif mode==8:
        add_to_bookmarks(url)

elif mode==9:
        remove_from_bookmarks(url)
		
elif mode==13:
        print ""+url
        trailers()
 
elif mode==15:
        metasearch(url)
		
xbmcplugin.endOfDirectory(int(sys.argv[1]))
