import urllib, urllib2, re, xbmcplugin, xbmcgui, xbmc, xbmcaddon, os, sys, time, binascii, zipfile, shutil

ADDON        =  xbmcaddon.Addon(id='plugin.program.totalinstaller')
AddonID      =  'plugin.program.totalinstaller'
dialog       =  xbmcgui.Dialog()
dp           =  xbmcgui.DialogProgress()
HOME         =  xbmc.translatePath('special://home/')
USERDATA     =  xbmc.translatePath(os.path.join('special://home/userdata',''))
ADDONS       =  xbmc.translatePath(os.path.join('special://home','addons',''))
TI       =  xbmc.translatePath(os.path.join('special://home/addons/plugin.program.totalinstaller'))
CB       =  xbmc.translatePath(os.path.join('special://home/addons/plugin.program.community.builds'))
CBAD       =  xbmc.translatePath(os.path.join('special://home/userdata/addon_data/plugin.program.community.builds'))
packages     = xbmc.translatePath(os.path.join('special://home/addons','packages'))
#-----------------------------------------------------------------------------------------------------------------
def download(url, dest, dp = None):
    if not dp:
        dp = xbmcgui.DialogProgress()
        dp.create("Status...","Checking Installation",' ', ' ')
    dp.update(0)
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def _pbhook(numblocks, blocksize, filesize, url, dp):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        raise Exception("Cancelled")
        dp.close()
def Extract_all(_in, _out, dp=None):
    if dp:
        return Extract_allWithProgress(_in, _out, dp)

    return Extract_allNoProgress(_in, _out)
def Extract_allNoProgress(_in, _out):
    try:
        zin = zipfile.ZipFile(_in, 'r')
        zin.extractall(_out)
    except Exception, e:
        print str(e)
        return False
    return True
def Extract_allWithProgress(_in, _out, dp):
    zin = zipfile.ZipFile(_in,  'r')
    nFiles = float(len(zin.infolist()))
    count  = 0
    try:
        for item in zin.infolist():
            count += 1
            update = count / nFiles * 100
            dp.update(int(update))
            zin.extract(item, _out)
    except Exception, e:
        print str(e)
        return False
    return True
def Open_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link     = response.read()
    response.close()
    return link.replace('\r','').replace('\n','').replace('\t','')
def Update_Check():
    internetcheck=1
    IPAddress = xbmc.getInfoLabel('Network.IPAddress')
    try:
        Open_URL('http://google.com')
    except:
        internetcheck=0
    if IPAddress =='' or internetcheck==0:
        dialog.ok("NO INTERNET CONNECTION",'Please connect to the internet then try again.','','')
        return
    else:
        checkurlraw='687474703a2f2f746f74616c78626d632e636f6d2f746f74616c7265766f6c7574696f6e2f636865636b2e747874'
        checkurl = binascii.unhexlify(checkurlraw)
        addonxml = xbmc.translatePath(os.path.join(ADDONS,AddonID,'addon.xml'))    
        localaddonversion = open(addonxml, mode='r')
        content = file.read(localaddonversion)
        file.close(localaddonversion)
        localaddonvermatch = re.compile('check="1" version="(.+?)"').findall(content)
        addonversion  = localaddonvermatch[0] if (len(localaddonvermatch) > 0) else '1.0'
        link = Open_URL(checkurl).replace('\n','').replace('\r','')
        urlversionmatch = re.compile('version="(.+?)"').findall(link)
        urlzipmatch = re.compile('url="(.+?)"').findall(link)
        urlversion  = urlversionmatch[0] if (len(urlversionmatch) > 0) else '1.0'
        urlzip  = urlzipmatch[0] if (len(urlzipmatch) > 0) else ''
        if urlversion > addonversion or not os.path.exists(TI):
            dp.create("Installing new version","Downloading ",'', 'Please Wait')
            download(urlzip, packages+'/plugin.program.totalinstaller.zip', dp)
            dp.update(0,"", "Extracting Zip Please Wait")
            Extract_all(packages+'/plugin.program.totalinstaller.zip', ADDONS, dp)
            time.sleep(1)
        shutil.rmtree(CB, ignore_errors=True)
        shutil.rmtree(CBAD, ignore_errors=True)
        dialog.ok("[COLOR=lime]VERY IMPORTANT:[/COLOR]",'The Community Builds add-on is no longer available,','please use Total Installer. Don\'t forget to enter your','TotalXBMC login details in the add-on settings!')
#-----------------------------------------------------------------------------------------------------------------    
Update_Check()
xbmcplugin.endOfDirectory(int(sys.argv[1]))