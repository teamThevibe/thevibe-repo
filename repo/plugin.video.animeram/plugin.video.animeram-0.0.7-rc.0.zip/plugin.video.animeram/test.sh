#!/bin/bash
green -vvv test
