#!/bin/bash
#if [$LAN3 -ne 0] #if ifconfig eth0 > /dev/null ; then #If you want to see the ifconfig output, then just remove the "> /dev/null"
#REPLACE WORDS IN A FILE: sed -i 's/use-ipv6=no/use-ipv6=yes/g' /storage/.config/avahi/avahi-daemon.conf
#mkdir #cp
LAN2=`ifconfig | grep -i "eth0" | wc -l`
LAN3=`ifconfig eth0 | grep -i "packets:0" | wc -l`
LAN4=`ifconfig eth0 | grep -i "inet addr" | wc -l`
WLAN2=`ifconfig | grep -i "wlan0" | wc -l`
WLAN3=`ifconfig wlan0 | grep -i "packets:0" | wc -l`
WLAN4=`ifconfig wlan0 | grep -i "inet addr" | wc -l`
PING1=`ping -W 1 -w 1 -4 -q www.google.co.il | grep -i " 0% packet loss" | wc -l`
PING2=`ping -W 1 -w 1 -4 -q www.google.co.il`
#PING2=`ping -W 1 -w 1 -4 -q 192.168.1.1 | grep -i " 0% packet loss" | wc -l`
echo PING1: $PING1 PING2: $PING2

if [ $LAN2 -eq 0 ] && [ $WLAN2 -eq 0 ] || [ $LAN4 -eq 0 ] && [ $WLAN4 -eq 0 ]; then
	echo "eth0 ($LAN2) & wlan0 ($WLAN2) are NOT connected!!!"
	ifconfig eth0 down && sleep 1 & ifconfig eth0 up && sleep 1
	echo "eth0 ($LAN2) --> Turned on!"
	ifconfig wlan0 down && sleep 1 && ifconfig wlan0 up && sleep 2
	echo "wlan0 ($WLAN2) --> Turned on!" && echo 'ifconfig'
	sleep 1
	LAN2=`ifconfig | grep -i "eth0" | wc -l`
	LAN3=`ifconfig eth0 | grep -i "packets:0" | wc -l`
	LAN4=`ifconfig eth0 | grep -i "inet addr" | wc -l`
	WLAN2=`ifconfig | grep -i "wlan0" | wc -l`
	WLAN3=`ifconfig wlan0 | grep -i "packets:0" | wc -l`
	WLAN4=`ifconfig wlan0 | grep -i "inet addr" | wc -l`
fi

if [ $LAN2 -gt 0 ] && [ $WLAN2 -gt 0 ]; then
	echo "eth0 ($LAN2) & wlan0 ($WLAN2) are connected!"
	if [ $LAN3 -eq 0 ] && [ $LAN4 -gt 0 ] && [ $WLAN3 -gt 0 -o $WLAN4 -eq 0 ]; then
		echo "eth0 have packets and IP! -> turning off wlan0!"
		ifconfig wlan0 down && sleep 1
	else
		if [ $WLAN3 -eq 0 ] && [ $WLAN4 -gt 0 ] && [ $LAN3 -gt 0 -o $LAN4 -eq 0 ]; then
			echo "wlan0 have packets and IP! -> turning off eth0!"
			ifconfig eth0 down && sleep 2
		fi
	fi
	LAN2=`ifconfig | grep -i "eth0" | wc -l`
	LAN3=`ifconfig eth0 | grep -i "packets:0" | wc -l`
	LAN4=`ifconfig eth0 | grep -i "inet addr" | wc -l`
	WLAN2=`ifconfig | grep -i "wlan0" | wc -l`
	WLAN3=`ifconfig wlan0 | grep -i "packets:0" | wc -l`
	WLAN4=`ifconfig wlan0 | grep -i "inet addr" | wc -l`
else
	echo "only one interface is up :)"
	if [ $LAN2 -gt 0 ] && [ $LAN3 -eq 0 ] && [ $LAN4 -gt 0 ]; then
		echo "eth0 ($LAN2) is connected! -> reseting 5sec..."
		ifconfig eth0 down && sleep 2 && ifconfig eth0 up # && sleep 2 && ifconfig eth0 mtu 1492
	else
		if [ $WLAN2 -gt 0 ] && [ $WLAN3 -eq 0 ] && [ $WLAN4 -gt 0 ]; then
			echo "wlan0 ($WLAN2) is connected! -> reseting 5sec..."
			#ifconfig wlan0 down && sleep 2 && ifconfig wlan0 up # && sleep 2 && ifconfig wlan0 mtu 1492
		fi
	fi
fi
echo PING1: $PING1 PING2: $PING2

#exit