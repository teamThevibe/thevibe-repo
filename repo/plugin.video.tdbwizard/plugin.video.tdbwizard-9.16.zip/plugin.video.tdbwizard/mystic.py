import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import urllib2,urllib
import extract
import downloader
import re
import time
import common as Common

AddonTitle="[COLOR ghostwhite]TDB[/COLOR] [COLOR lightsteelblue]Wizard[/COLOR]"
addon_id = 'plugin.video.tdbwizard'
ADDON = xbmcaddon.Addon(id=addon_id)
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
MYSTICICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/mystic.png'))
SUPPORT_ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/support.png'))
BASEURL = base64.b64decode(b"aHR0cDovL3RlYW10ZGJidWlsZHMuY28udWsv")
MYSTIC_JARVIS = BASEURL + base64.b64decode(b"YnVpbGRzL215c3RpYy93aXphcmRfcmVsX2phcnZpcy50eHQ=")
MYSTIC_KRYPTON = BASEURL + base64.b64decode(b"YnVpbGRzL215c3RpYy93aXphcmRfcmVsX2tyeXB0b24udHh0")
youtubelink = base64.b64decode(b"cGx1Z2luOi8vcGx1Z2luLnZpZGVvLnlvdXR1YmUvP2FjdGlvbj1wbGF5X3ZpZGVvJnZpZGVvaWQ9")
dialog = xbmcgui.Dialog()

#######################################################################
#						MYSTIC BUILD MENU
#######################################################################

def BUILDMENU():
 	
	xbmc_version=xbmc.getInfoLabel("System.BuildVersion")
	version=float(xbmc_version[:4])
	codename = "Decline"
	
	if version >= 16.0 and version <= 16.9:
		codename = 'Jarvis'
	if version >= 17.0 and version <= 17.9:
		codename = 'Krypton'
	
	if codename == "Jarvis":	
		try:
			link = Common.OPEN_URL(MYSTIC_JARVIS).replace('\n','').replace('\r','')
			match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?ersion="(.+?)".+?escription="(.+?)".+?resh="(.+?)".+?ash="(.+?)".+?outube="(.+?)".+?kin="(.+?)"').findall(link)
			for name,url,iconimage,fanart,version,desc,fresh,hash,youtube,skin in match:
				if "[COLOR white]" in name:
					Common.addItem(name,url,22,MYSTICICON,FANART,'')
				else:
					id=youtubelink+youtube
					description = str(desc + "," + hash + "," + fresh + "," + id + "," + skin)
					bname = " | [COLOR smokewhite] Downloads:[/COLOR][COLOR white] Week:[/COLOR][COLOR smokewhite] " + str(Common.count(name)) + "[/COLOR]"
					bname_total = "[COLOR white] - Total:[/COLOR] [COLOR smokewhite]" + str(Common.count_total(name)) + "[/COLOR]"
					Common.addDir(name + bname + bname_total,url,83,iconimage,fanart,description)
			Common.addItem('[COLOR smokewhite]-----------------------------------------------------------[/COLOR]',BASEURL,22,SUPPORT_ICON,FANART,'')
			Common.addItem('[COLOR lightskyblue][B]DO YOU NEED HELP OR SUPPORT?[/B][/COLOR]',BASEURL,22,SUPPORT_ICON,FANART,'')
		except:
			dialog.ok(AddonTitle, "[B][COLOR smokewhite]Sorry, TDB Wizard encountered an error[/COLOR][/B]",'[COLOR smokewhite]This is normally a website time out, please try again.[/COLOR]',"[B][COLOR white]Error Code:[/COLOR][COLOR lightskyblue] 0038[/COLOR][/B]")
	
	if codename == "Krypton":	
		try:
			link = Common.OPEN_URL(MYSTIC_KRYPTON).replace('\n','').replace('\r','')
			match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?ersion="(.+?)".+?escription="(.+?)".+?resh="(.+?)".+?ash="(.+?)".+?outube="(.+?)".+?kin="(.+?)"').findall(link)
			for name,url,iconimage,fanart,version,desc,fresh,hash,youtube,skin in match:
				if "[COLOR white]" in name:
					Common.addItem(name,url,22,MYSTICICON,FANART,'')
				else:
					id=youtubelink+youtube
					description = str(desc + "," + hash + "," + fresh + "," + id + "," + skin)
					bname = " | [COLOR smokewhite] Downloads:[/COLOR][COLOR white] Week:[/COLOR][COLOR smokewhite] " + str(Common.count(name)) + "[/COLOR]"
					bname_total = "[COLOR white] - Total:[/COLOR] [COLOR smokewhite]" + str(Common.count_total(name)) + "[/COLOR]"
					Common.addDir(name + bname + bname_total,url,83,iconimage,fanart,description)
			Common.addItem('[COLOR smokewhite]-----------------------------------------------------------[/COLOR]',BASEURL,22,SUPPORT_ICON,FANART,'')
			Common.addItem('[COLOR lightskyblue][B]DO YOU NEED HELP OR SUPPORT?[/B][/COLOR]',BASEURL,22,SUPPORT_ICON,FANART,'')
		except:
			dialog.ok(AddonTitle, "[B][COLOR smokewhite]Sorry, TDB Wizard encountered an error[/COLOR][/B]",'[COLOR smokewhite]This is normally a website time out, please try again.[/COLOR]',"[B][COLOR white]Error Code:[/COLOR][COLOR lightskyblue] 0039[/COLOR][/B]")
	
	if codename == "Decline":
		dialog.ok(AddonTitle, "Sorry we are unable to process your request","[COLOR lightskyblue][I][B]Error: TDB does not support this version of Kodi.[/COLOR][/I][/B]","[I]Your are running: [COLOR lightsteelblue][B]Kodi " + codename + " Version:[COLOR ghostwhite] %s" % version + "[/COLOR][/I][/B][/COLOR]")
