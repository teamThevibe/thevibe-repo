import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import urllib2,urllib
import extract
import downloader
import re
import time
import common as Common

AddonTitle="[COLOR ghostwhite]TDB[/COLOR] [COLOR lightsteelblue]Wizard[/COLOR]"
addon_id = 'plugin.video.tdbwizard'
ADDON = xbmcaddon.Addon(id=addon_id)
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
VULCANICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/vulcan.png'))
SUPPORT_ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/support.png'))
BASEURL = base64.b64decode(b"aHR0cDovL3RlYW10ZGJidWlsZHMuY28udWsv")
VULCAN_JARVIS = BASEURL + base64.b64decode(b"YnVpbGRzL3Z1bGNhbi93aXphcmRfcmVsX2phcnZpcy50eHQ=")
VULCAN_KRYPTON = BASEURL + base64.b64decode(b"YnVpbGRzL3Z1bGNhbi93aXphcmRfcmVsX2tyeXB0b24udHh0")
youtubelink = base64.b64decode(b"cGx1Z2luOi8vcGx1Z2luLnZpZGVvLnlvdXR1YmUvP2FjdGlvbj1wbGF5X3ZpZGVvJnZpZGVvaWQ9")
CUSTOM_URL = BASEURL + base64.b64decode(b"YnVpbGRzL3Z1bGNhbi9jdXN0b20udHh0")
CUSTOM = BASEURL + base64.b64decode(b"YnVpbGRzL3Z1bGNhbi9jdXN0b21fYnVpbGRzLw==")
dialog = xbmcgui.Dialog()

#######################################################################
#						VULCAN BUILD MENU
#######################################################################

def BUILDMENU():
 	
	xbmc_version=xbmc.getInfoLabel("System.BuildVersion")
	version=float(xbmc_version[:4])
	codename = "Decline"
	
	if version >= 16.0 and version <= 16.9:
		codename = 'Jarvis'
	if version >= 17.0 and version <= 17.9:
		codename = 'Krypton'

	if codename == "Jarvis":
		try:
			link = Common.OPEN_URL(VULCAN_JARVIS).replace('\n','').replace('\r','')
			match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?ersion="(.+?)".+?escription="(.+?)".+?resh="(.+?)".+?ash="(.+?)".+?outube="(.+?)".+?kin="(.+?)"').findall(link)
			for name,url,iconimage,fanart,version,desc,fresh,hash,youtube,skin in match:
				if "[COLOR white]" in name:
					Common.addItem(name,url,22,VULCANICON,FANART,'')
				else:
					id=youtubelink+youtube
					description = str(desc + "," + hash + "," + fresh + "," + id + "," + skin)
					bname = " | [COLOR white] Week:[/COLOR][COLOR lightskyblue][B] " + str(Common.count(name)) + "[/B][/COLOR]"
					bname_total = "[COLOR white] - Total:[/COLOR] [COLOR lightskyblue][B]" + str(Common.count_total(name)) + "[/B][/COLOR]"
					Common.addDir(name + bname + bname_total,url,83,iconimage,fanart,description)
			Common.addItem('[COLOR smokewhite]-----------------------------------------------------------[/COLOR]',BASEURL,22,SUPPORT_ICON,FANART,'')
			Common.addItem('[B][COLOR lime]YOUR CUSTOM BUILD (ONLY USE IF ASKED TO)[/COLOR][/B]',BASEURL,48,VULCANICON,FANART,'')
			Common.addItem('[COLOR lightskyblue][B]DO YOU NEED HELP OR SUPPORT?[/B][/COLOR]',BASEURL,22,SUPPORT_ICON,FANART,'')
		except:
			dialog.ok(AddonTitle, "[B][COLOR smokewhite]Sorry, TDB Wizard encountered an error[/COLOR][/B]",'[COLOR smokewhite]This is normally a website time out, please try again.[/COLOR]',"[B][COLOR white]Error Code:[/COLOR][COLOR lightskyblue] 0042[/COLOR][/B]")
	
	if codename == "Krypton":	
		try:
			link = Common.OPEN_URL(VULCAN_KRYPTON).replace('\n','').replace('\r','')
			match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?ersion="(.+?)".+?escription="(.+?)".+?resh="(.+?)".+?ash="(.+?)".+?outube="(.+?)".+?kin="(.+?)"').findall(link)
			for name,url,iconimage,fanart,version,desc,fresh,hash,youtube,skin in match:
				if "[COLOR white]" in name:
					Common.addItem(name,url,22,VULCANICON,FANART,'')
				else:
					id=youtubelink+youtube
					description = str(desc + "," + hash + "," + fresh + "," + id + "," + skin)
					bname = " | [COLOR white] Week:[/COLOR][COLOR lightskyblue][B] " + str(Common.count(name)) + "[/B][/COLOR]"
					bname_total = "[COLOR white] - Total:[/COLOR] [COLOR lightskyblue][B]" + str(Common.count_total(name)) + "[/B][/COLOR]"
					Common.addDir(name + bname + bname_total,url,83,iconimage,fanart,description)
			Common.addItem('[COLOR smokewhite]-----------------------------------------------------------[/COLOR]',BASEURL,22,SUPPORT_ICON,FANART,'')
			Common.addItem('[B][COLOR lime]YOUR CUSTOM BUILD (ONLY USE IF ASKED TO)[/COLOR][/B]',BASEURL,48,VULCANICON,FANART,'')
			Common.addItem('[COLOR lightskyblue][B]DO YOU NEED HELP OR SUPPORT?[/B][/COLOR]',BASEURL,22,SUPPORT_ICON,FANART,'')
		except:
			dialog.ok(AddonTitle, "[B][COLOR smokewhite]Sorry, TDB Wizard encountered an error[/COLOR][/B]",'[COLOR smokewhite]This is normally a website time out, please try again.[/COLOR]',"[B][COLOR white]Error Code:[/COLOR][COLOR lightskyblue] 0043[/COLOR][/B]")
	
	if codename == "Decline":
		dialog.ok(AddonTitle, "Sorry we are unable to process your request","[COLOR lightskyblue][I][B]Error: TDB does not support this version of Kodi.[/COLOR][/I][/B]","[I]Your are running: [COLOR lightsteelblue][B]Kodi " + codename + " Version:[COLOR ghostwhite] %s" % version + "[/COLOR][/I][/B][/COLOR]")

#######################################################################
#						CUSTOM BUILD
#######################################################################

def CUSTOM_BUILD():

	success = 0
	vq = Common._get_keyboard( heading="Please Enter Your Password" )
	if ( not vq ): return False, 0
	title = vq

	link = Common.OPEN_URL(CUSTOM_URL).replace('\n','').replace('\r','')
	match = re.compile('name="(.+?)".+?asskey="(.+?)"').findall(link)
	for name,passkey in match:
		if title==passkey:
			url = os.path.join(CUSTOM, title + '.zip')
			success = 1
			description = "0"
			installer.INSTALL_COMMUNITY(name,url,description)
	
	if success == 0:
		dialog = xbmcgui.Dialog()
		dialog.ok(AddonTitle, "Sorry the password entered was not found.",'[COLOR smokewhite]Thank you for using TDB Wizard[/COLOR]')
	