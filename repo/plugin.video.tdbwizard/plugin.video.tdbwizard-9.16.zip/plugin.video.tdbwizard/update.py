import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import urllib2,urllib
import re
import glob
import extract
import plugintools
import downloader
import time
import common as Common
import wipe
from urllib import FancyURLopener

class MyOpener(FancyURLopener):
	version = 'TheWizardIsHere'

myopener = MyOpener()
urlretrieve = MyOpener().retrieve
urlopen = MyOpener().open
AddonTitle="[COLOR ghostwhite]TDB[/COLOR] [COLOR lightsteelblue]Wizard[/COLOR]"
USERDATA     =  xbmc.translatePath(os.path.join('special://home/userdata',''))
TDB_VERSION  =  os.path.join(USERDATA,'tdb.txt')
LEETV_VERSION  =  os.path.join(USERDATA,'leetv.txt')
DONERIGHT_VERSION  =  os.path.join(USERDATA,'doneright.txt')
KH_VERSION  =  os.path.join(USERDATA,'kh.txt')
MYSTIC_VERSION  =  os.path.join(USERDATA,'mystic.txt')
KIDDO_VERSION  =  os.path.join(USERDATA,'kiddo.txt')
OTIS_VERSION  =  os.path.join(USERDATA,'otis.txt')
VULCAN_VERSION  =  os.path.join(USERDATA,'vulcan.txt')
DEMONSTRATORZ_VERSION  =  os.path.join(USERDATA,'demonstratorz.txt')
BASEURL = base64.b64decode(b"aHR0cDovL3RlYW10ZGJidWlsZHMuY28udWsv")

dp = xbmcgui.DialogProgress()
dialog = xbmcgui.Dialog()

############################
###CHECK FOR UPDATES########
############################

def updateaddons():

	xbmc.executebuiltin( "ActivateWindow(busydialog)" )
	xbmc.executebuiltin('UpdateAddonRepos()')
	xbmc.executebuiltin('UpdateLocalAddons()')
	xbmc.executebuiltin( "Dialog.Close(busydialog)" )
	dialog.ok(AddonTitle,'[COLOR ghostwhite]All repositories have been checked for updates.[/COLOR]','[COLOR smokewhite]All available addon updates have now been installed.[/COLOR]','')

def check():	

	xbmc.executebuiltin( "ActivateWindow(busydialog)" )

#######################################################################
#						Check for Team TDB Updates
#######################################################################

	#Information for TDB Wizard OTA updates.
	if os.path.exists(TDB_VERSION):
		VERSIONCHECK = TDB_VERSION
		FIND_URL = BASEURL + base64.b64decode(b'YnVpbGRzL3dpemFyZC91cGRhdGVfd2l6LnR4dA==')
		checkurl = BASEURL + base64.b64decode(b'YnVpbGRzL3dpemFyZC92ZXJzaW9uX2NoZWNrLnR4dA==')
		pleasecheck = 1
	#Information for Lee TV OTA updates.
	if os.path.exists(LEETV_VERSION):
		VERSIONCHECK = LEETV_VERSION
		FIND_URL = BASEURL + base64.b64decode(b"YnVpbGRzL2xlZXR2L3VwZGF0ZV93aXoudHh0")
		checkurl = BASEURL + base64.b64decode(b"YnVpbGRzL2xlZXR2L3ZlcnNpb25fY2hlY2sudHh0")
		pleasecheck = 1
	#Information for Done Right OTA updates.
	if os.path.isfile(DONERIGHT_VERSION):
		VERSIONCHECK = DONERIGHT_VERSION
		FIND_URL = BASEURL + base64.b64decode(b"YnVpbGRzL2RvbmVyaWdodC91cGRhdGVfd2l6LnR4dA==")
		checkurl = BASEURL + base64.b64decode(b"YnVpbGRzL2RvbmVyaWdodC92ZXJzaW9uX2NoZWNrLnR4dA==")
		pleasecheck = 1
	#Information for Kodi Heaven OTA updates.
	if os.path.isfile(KH_VERSION):
		VERSIONCHECK = KH_VERSION
		FIND_URL = BASEURL + base64.b64decode(b"YnVpbGRzL2tvZGloZWF2ZW4vdXBkYXRlX3dpei50eHQ=")
		checkurl = BASEURL + base64.b64decode(b"YnVpbGRzL2tvZGloZWF2ZW4vdmVyc2lvbl9jaGVjay50eHQ=")
		pleasecheck = 1
	#Information for Mystic OTA updates.
	if os.path.isfile(MYSTIC_VERSION):
		VERSIONCHECK = MYSTIC_VERSION
		FIND_URL = BASEURL + base64.b64decode(b"YnVpbGRzL215c3RpYy91cGRhdGVfd2l6LnR4dA==")
		checkurl = BASEURL + base64.b64decode(b"YnVpbGRzL215c3RpYy92ZXJzaW9uX2NoZWNrLnR4dA==")
		pleasecheck = 1
	#Information for KIDDO OTA updates.
	if os.path.isfile(KIDDO_VERSION):
		VERSIONCHECK = KIDDO_VERSION
		FIND_URL = BASEURL + base64.b64decode(b"YnVpbGRzL2tpZGRvL3VwZGF0ZV93aXoudHh0")
		checkurl = BASEURL + base64.b64decode(b"YnVpbGRzL2tpZGRvL3ZlcnNpb25fY2hlY2sudHh0")
		pleasecheck = 1
	#Information for Vulcan OTA updates.
	if os.path.isfile(VULCAN_VERSION):
		VERSIONCHECK = VULCAN_VERSION
		FIND_URL = BASEURL + base64.b64decode(b"YnVpbGRzL3Z1bGNhbi91cGRhdGVfd2l6LnR4dA==")
		checkurl = BASEURL + base64.b64decode(b"YnVpbGRzL3Z1bGNhbi92ZXJzaW9uX2NoZWNrLnR4dA==")
		pleasecheck = 1
	#Information for Demonstratorz OTA updates.
	if os.path.isfile(DEMONSTRATORZ_VERSION):
		VERSIONCHECK = DEMONSTRATORZ_VERSION
		FIND_URL = BASEURL + base64.b64decode(b"YnVpbGRzL2RlbW9uc3RyYXRvcnovdXBkYXRlX3dpei50eHQ=")
		checkurl = BASEURL + base64.b64decode(b"YnVpbGRzL2RlbW9uc3RyYXRvcnovdmVyc2lvbl9jaGVjay50eHQ=")

	if pleasecheck == 1:
		dialog = xbmcgui.Dialog()
		vers = open(VERSIONCHECK, "r")
		regex = re.compile(r'<build>(.+?)</build><version>(.+?)</version>')
		for line in vers:
			if pleasecheck == 1:
				currversion = regex.findall(line)
				for build,vernumber in currversion:
					if vernumber > 0:
						req = urllib2.Request(checkurl)
						req.add_header('User-Agent','TheWizardIsHere')
						try:
							response = urllib2.urlopen(req)
						except:
							dialog.ok(AddonTitle,'Sorry we are unable to check for updates!','The update host appears to be down.','Please check for updates later via the wizard.')
							sys.exit(1)			
							xbmc.executebuiltin( "Dialog.Close(busydialog)" )
						link=response.read()
						response.close()
						match = re.compile('<build>'+build+'</build><version>(.+?)</version><fresh>(.+?)</fresh>').findall(link)	
						for newversion,fresh in match:
							if newversion > vernumber:
								choice = xbmcgui.Dialog().yesno("UPDATE AVAILABLE", 'Found a new update for the Build', build + " ver: "+newversion, 'Do you want to install it now?', yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
								if choice == 1: 
									if fresh =='false': # TRUE
										updateurl = FIND_URL
										req = urllib2.Request(updateurl)
										req.add_header('User-Agent','TheWizardIsHere')
										try:
											response = urllib2.urlopen(req)
										except:
											dialog.ok(AddonTitle,'Sorry we were unable to download the update!','The update host appears to be down.','Please check for updates later via the wizard.')
											sys.exit(1)		
											xbmc.executebuiltin( "Dialog.Close(busydialog)" )
										link=response.read()
										response.close()
										match = re.compile('<build>'+build+'</build><url>(.+?)</url>').findall(link)
										for url in match:
								
											path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
											name = "build"
											dp = xbmcgui.DialogProgress()

											dp.create(AddonTitle,"Downloading ",'', 'Please Wait')
											lib=os.path.join(path, name+'.zip')
											try:
												os.remove(lib)
											except:
												pass
									
											downloader.download(url, lib, dp)
											addonfolder = xbmc.translatePath(os.path.join('special://','home'))
											time.sleep(2)
											dp.update(0,"", "Extracting Zip Please Wait")
											print '======================================='
											print addonfolder
											print '======================================='
											extract.all(lib,addonfolder,dp)
											time.sleep(1)
											xbmc.executebuiltin("UpdateAddonRepos")
											xbmc.executebuiltin("UpdateLocalAddons")
											time.sleep(1)
											xbmc.executebuiltin( "Dialog.Close(busydialog)" )
											dialog = xbmcgui.Dialog()
											dialog.ok(AddonTitle, "Your build has succesfully been updated to the latest version.")							
											sys.exit(1)		
									else:
										dialog.ok('[COLOR lightskyblue]A WIPE is required for the update[/COLOR]','Select the [COLOR green]YES[/COLOR] option in the NEXT WINDOW to wipe now.','Select the [COLOR lightskyblue]NO[/COLOR] option in the NEXT WINDOW to update later.','[I][COLOR smokewhite]If you wish to update later you can do so in [/COLOR][COLOR ghostwhite]TDB[/COLOR] [COLOR lightsteelblue]Wizard[/COLOR][/I]')
										xbmc.executebuiltin( "Dialog.Close(busydialog)" )
										wipe.FRESHSTART()
										sys.exit(1)		
								else:
									xbmc.executebuiltin( "Dialog.Close(busydialog)" )
									sys.exit(1)		
							else:
								xbmc.executebuiltin( "Dialog.Close(busydialog)" )
								dialog.ok(AddonTitle,'[COLOR ghostwhite]Your build is up to date.[/COLOR]', "[COLOR ghostwhite]Current Build: [/COLOR][COLOR smokewhite]" + build + "[/COLOR]", "[COLOR ghostwhite]Current Version: [/COLOR][COLOR smokewhite]" + newversion + "[/COLOR]")
								sys.exit(1)	

	#LAST LINE OF UPDATES
	xbmc.executebuiltin( "Dialog.Close(busydialog)" )
	dialog.ok(AddonTitle,'[COLOR ghostwhite]An unknown error occurred.[/COLOR]', "[COLOR smokewhite]Please contact TDB Wizard to resolve this issue.[/COLOR]", "[COLOR ghostwhite]http://tdbwizardbuilds.co.uk[/COLOR]")