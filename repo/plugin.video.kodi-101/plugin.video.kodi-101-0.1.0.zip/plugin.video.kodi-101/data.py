# -*- coding: utf-8 -*-
from cache import Cache
from video import Video
from datetime import datetime, date
from xbmc import log
from xbmc import log
from xbmcaddon import Addon
import requests
import re


@Cache
def get_data():
    """
    Returns all data
    :return: Array of video objects
    """
    list = []
    r = requests.get('https://spreadsheets.google.com/feeds/list/1DYW3csgsgAkePoe5fvZ17jv2Jvnz9uPfk3IytO9Lg-Y/1/public/basic?alt=json')
    for i in r.json()['feed']['entry']:
        matches = re.search('^category: (.+), link: (.+), description: (.+), language: (.+), credit: (.+), title: (.+)$', i['content']['$t'])
        video = Video(matches.group(6), matches.group(1), matches.group(2), matches.group(3), matches.group(4), matches.group(5))
        setattr(video, 'Timestamp', i['title']['$t'])

        try:
            days = (date.today() - datetime.strptime(video.Timestamp, "%m/%d/%Y %H:%M:%S").date()).days
            if days < 5:
                video.title = u'חדש:  ' + video.title
        except AttributeError as e:
            log("AttributeError error({0}".format(e.message))
            pass

        list.append(video)

    return list


@Cache
def get_videos(category):
    """
    Returns only videos which belong to specific category
    :param category: Category name
    :return: Array of video objects
    """
    return sorted([video for video in get_data() if video.category.encode('utf-8') == category]
                  , key=lambda video: video.Timestamp, reverse=True)

@Cache
def get_icon(category):
    """
    Returns the category's icon image
    :param category: Category name
    :return: Array of video objects
    """
    addon_folder_path = 'special://home/addons/{0}/resources/media/icons'.format(Addon().getAddonInfo('id'))
    icons = {
        u'התקנה': '{0}/install.png'.format(addon_folder_path),
        u'מעטפות (Skin)': '{0}/skins.png'.format(addon_folder_path),
        u'תוספים (Addon)': '{0}/addons.png'.format(addon_folder_path),
        u'הרחבות (Repository)': '{0}/repos.png'.format(addon_folder_path),
        u'סטרימרים': '{0}/general.png'.format(addon_folder_path),
        u'טיפים': '{0}/general.png'.format(addon_folder_path),
        u'תחזוקה': '{0}/maintain.png'.format(addon_folder_path),
        u'גיבוי': '{0}/backup.png'.format(addon_folder_path),
        u'פיתוח': '{0}/development.png'.format(addon_folder_path),
        u'חומרה': '{0}/hardware.png'.format(addon_folder_path),
        u'כללי': '{0}/general.png'.format(addon_folder_path),
        u'תקלות נפוצות': '{0}/bugs.png'.format(addon_folder_path)
    }
    return icons[category] if category in icons else icons[u'תקלות נפוצות']


@Cache
def get_categories():
    categories = set()
    for item in get_data():
        categories.add(item.category)

    return sorted(categories)