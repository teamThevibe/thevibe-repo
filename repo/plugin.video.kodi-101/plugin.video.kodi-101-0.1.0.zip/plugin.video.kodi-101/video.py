import re


class Video:
    def __init__(self, title, category, link, description, language, credit):
        self.title = title
        self.category = category
        self.link = link
        self.id = link and re.search('\?v=(\w+)', link).group(1)
        self.description = description
        self.language = language
        self.credit = credit
        self.Timestamp = None