# -*- coding: utf-8 -*-
import sys
import xbmc
import xbmcplugin
from xbmcaddon import Addon
import routing
import data
import re
# from xbmcgui import ListItem, ControlLabel, Window, getCurrentWindowId
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem, endOfDirectory


# Set type of plugin:
addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'movies')
fanart = Addon().getAddonInfo('fanart')
# window = Window(getCurrentWindowId())
# Create routing plugin:
plugin = routing.Plugin()


# Categories list
@plugin.route('/')
def index():
    # Get all categories:
    for category in data.get_categories():
        icon = data.get_icon(category)
        li = ListItem(category, iconImage=icon, thumbnailImage=icon)
        li.setArt({
            'thumb': icon,
            'poster': icon,
            'fanart': fanart
        })
        addDirectoryItem(plugin.handle, plugin.url_for(show_videos, category), li, True)

    endOfDirectory(plugin.handle)
    # xbmc.executebuiltin("Container.SetViewMode(53)")


# Category's videos list
@plugin.route('/categories/<category>/videos')
def show_videos(category):
    # Draw title:
    # label = ControlLabel(250, 220, 400, 100, category, font='font14', angle=0, textColor='0xAAFFFFFF')
    # window.addControl(label)
    # del label

    # Get channel's podcasts:
    for video in data.get_videos(category):
        youtube_video_id = re.search('\?v=([\w-]+)', video.link).group(1)
        thumb = 'http://img.youtube.com/vi/{0}/hqdefault.jpg'.format(youtube_video_id)
        li = ListItem(video.title, iconImage=thumb, thumbnailImage=thumb)
        li.setArt({
            'banner': thumb,
            'thumb': thumb,
            'poster': thumb,
            'clearart': thumb,
            'clearlogo': thumb,
            'landscape': thumb,
            'fanart': fanart
        })
        li.setInfo('video', {
            'title': video.title,
            'plot': u'{0} ([B]{1}[/B])[CR]הועלה על ידי {2} בתאריך {3}'.format(video.description, video.language, video.credit or u'אנונימי', video.Timestamp),
            'credits': video.credit
        })
        li.setProperty('IsPlayable', 'true')
        addDirectoryItem(plugin.handle, 'plugin://plugin.video.youtube/play/?video_id={0}'.format(youtube_video_id), li)

    endOfDirectory(plugin.handle)
    # xbmc.executebuiltin("Container.SetViewMode(52)")


if __name__ == '__main__':
    plugin.run()
    xbmc.executebuiltin('Notification(Kodi-101,מומלץ להיכנס לתפריט הגדרות התצוגה ולבחור הצג פרטים,5000)')
