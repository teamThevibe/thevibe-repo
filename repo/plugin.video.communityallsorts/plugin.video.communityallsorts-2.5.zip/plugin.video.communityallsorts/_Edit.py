import xbmcaddon

MainBase = 'http://goo.gl/Sij0C9'
addon = xbmcaddon.Addon('plugin.video.communityallsorts')