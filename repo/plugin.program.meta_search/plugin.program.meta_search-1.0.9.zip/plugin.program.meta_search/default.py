# -*- coding: utf-8 -*-

import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys
import urllib

USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON=xbmcaddon.Addon(id='plugin.program.meta_search')
addon_id='plugin.program.meta_search'
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
VERSION = "1.0.7"
PATH = "Meta Search"            
Addon = xbmcaddon.Addon(addon_id)
localizedString = Addon.getLocalizedString 
    
def CATEGORIES():
    addDir2(localizedString(32000).encode('utf-8'),'חיפוש מטא',3,ART+'metas.png',ART+'fanart.jpg')
    addDir(localizedString(32001).encode('utf-8'),'אקסודוס',5,ART+'exodus.png',ART+'exodus.jpg')
    addDir(localizedString(32002).encode('utf-8'),'plugin://plugin.video.specto/?action=searchNavigator',1,ART+'specto.png',ART+'specto.jpg')
    addDir2(localizedString(32005).encode('utf-8'), 'חיפוש סאלטס',4,ART+'salts.png',ART+'salt.jpg')
    addDir(localizedString(32003).encode('utf-8'),'plugin://plugin.video.youtube/kodion/search/list',1,ART+'youtube.png',ART+'youtube.jpg')
    addDir(localizedString(32004).encode('utf-8'),'plugin://script.globalsearch',2,ART+'global.png',ART+'fanart2.jpg') 
	

def meta():
    addDir('סרטים','plugin://plugin.video.meta/movies/search',1,ART+'movies.png',ART+'fanart.jpg')
    addDir('סדרות','plugin://plugin.video.meta/tv/search',1,ART+'tv.png',ART+'fanart.jpg')	
    addDir('ערוצים חיים','plugin://plugin.video.meta/live/search',1,ART+'live.png',ART+'fanart.jpg')
	
def salts():
    addDir('סרטים','plugin://plugin.video.salts/?mode=search&amp;section=Movies',1,ART+'movies.png',ART+'salt.jpg')
    addDir('סדרות','plugin://plugin.video.salts/?mode=search&amp;section=TV',1,ART+'tv.png',ART+'salt.jpg')	 

def exodus():
    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.exodus/?action=searchNavigator)")
	
def metamovies():
    xbmc.executebuiltin("ActivateWindow(10001,plugin://plugin.video.meta/movies/search)")

def metatv():
    xbmc.executebuiltin("ActivateWindow(10001,plugin://plugin.video.meta/tv/search)")

def metalive():
    xbmc.executebuiltin("ActivateWindow(10001,plugin://plugin.video.meta/live/search)")	
	
def metasearch(url):
    ok=True        
    xbmc.executebuiltin('XBMC.Container.Update(%s)' % url )
    return ok  		

def globalsearch(url):
    ok=True        
    xbmc.executebuiltin('RunScript(script.globalsearch)')
    return ok   
		
def addDir(name,url,mode,iconimage,fanart):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        

def addDir2(name, url, mode, iconimage, fanart):
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		u = 'plugin://plugin.video.youtube/%s/%s/' % (url.split( '/' )[-2], url.split( '/' )[-1])
		ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
		return ok		
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok		
		
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None



try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
        CATEGORIES()
       
elif mode==1:
        metasearch(url)
        
elif mode==2:
        globalsearch(url)
		
elif mode==3:
        meta()	

elif mode==4:
        salts()

elif mode==5:
        exodus()

elif mode==6:
        metamovies()

elif mode==7:
        metatv()

elif mode==8:
        metalive()		
		
xbmcplugin.endOfDirectory(int(sys.argv[1]))

