				var htmlFullscreen = true;
				if(window.self != window.top && window.name != 'v2') {
					htmlFullscreen = false;
				}
				var ts = new Date().getTime();
				var json_client = jQuery.Zend.jsonrpc({url: 'http://www.cda.pl/?sid=SPLosH40fgZZ5SurQKN7SjqQ1S7', async:true});

								eval(function($packed, $ascii, $count, $keywords, $encode, $decode) {$encode=function($charCode) {
    return ($charCode < $ascii ? '' : $encode(parseInt($charCode / $ascii))) +
    (($charCode = $charCode % $ascii) > 35 ? String.fromCharCode($charCode + 29) : $charCode.toString(36));
};    if (!''.replace(/^/, String)) {
        // decode all the values we need
        while ($count--) {
            $decode[$encode($count)] = $keywords[$count] || $encode($count);
        }
        // global replacement function
        $keywords = [function ($encoded) {return $decode[$encoded]}];
        // generic match
        $encode = function () {return '\\w+'};
        // reset the loop counter -  we are now doing a global replace
        $count = 1;
    }
;
    while ($count--) {
        if ($keywords[$count]) {
            $packed = $packed.replace(new RegExp('\\b' + $encode($count) + '\\b', 'g'), $keywords[$count]);
        }
    }
    return $packed;
}
('r.q(\'8-7\').p=\'1://9.0.3/c/d/f.e\';5 s(4,t){}5 o(4){}5 v(4){}5 u(4){}x 6=m 0.6.i({k:\'8-7\',l:n,j:h,w:P,M:L,K:{J:{N:"1://b.0.3/y/R.Q",I:2},},a:{H:\'1://b.0.3/a/g\',B:\'A:z:C\',D:\'1://9.0.3/c/d/f.e\',G:"1://F.0.3/E/g?",}});6.O({});',54,54,'cda|http||pl|event|function|player|688246050|mediaplayer|vsbg034|video|www|oIq0DKIcWvNXHccVZUqtGA|1456054199|mp4|lq55cefe6ac72dc029a8a46cf4643b038e|24605058|354|flash|height|id|width|new|620|onTrackingEvent|href|getElementById|document|onImpressionEvent|forced|onCustomClickTrackingEvent|onClickTrackingEvent|fullscreen|var|vast|29|01|duration|25|url|620x368|ebd|src|link|repeat|preroll|ads|false|autostart|tag|init|htmlFullscreen|php|g_embed'.split('|'),0,{}))

								$.get('/a/o',{id:246050,ts:1456010999,k:'5b6a5c0ce1755fb542d79b35e4c2954b'});