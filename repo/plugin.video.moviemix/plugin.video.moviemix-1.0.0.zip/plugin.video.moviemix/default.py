import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,xbmc,xbmcaddon,os,net
from t0mm0.common.addon import Addon
from metahandler import metahandlers
net = net.Net()
addon_id = 'plugin.video.moviemix'
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
addon = Addon(addon_id, sys.argv)
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
nextp = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'next.png'))
metaset = selfAddon.getSetting('enable_meta')

def CATEGORIES():  
	addDir2('[COLOR gold]Featured[/COLOR]','http://imoviemax.se/category/featured/',1,icon,fanart)
	addDir2('[COLOR gold]Hollywood[/COLOR]','http://imoviemax.se/category/hollywood-movies/',1,icon,fanart)
	addDir2('[COLOR gold]Bollywood[/COLOR]','http://imoviemax.se/category/bollywood-movies/',1,icon,fanart)
	addDir2('[COLOR gold]Asian[/COLOR]','http://imoviemax.se/category/asian-movies/',1,icon,fanart)
	addDir2('[COLOR gold]Search[/COLOR]','url',3,icon,fanart)
        link = net.http_GET('http://imoviemax.se/').content
        genres=re.compile('<li class="cat-item cat-item-.+?"><a href="(.+?)">(.+?)</a><i>').findall(link)
        genres=list(set(genres))
        genres=sorted(genres)
        for url,name in genres:
                addDir2(name,url,1,icon,fanart)
                     		
def GETMOVIES(url,name):
	metaset = selfAddon.getSetting('enable_meta')
	link = cleanHex(net.http_GET(url).content.replace('\n',''))
	match=re.compile('alt="(.+?)".+?<a href="(.+?)".+?span').findall(link)[1:]
	itemcount=len(match)
	for name,url in match:
                try:
                        if metaset=='true':addDir(name,url,100,'iconimage',itemcount,isFolder=False)
                        else:addLink(name,url,100,icon,description='')
                except:pass
	try:
		np=re.compile('<div class="siguiente"><a href="(.+?)" >Next').findall(link)[0]
		addDir2('Next Page >>',np,1,nextp,fanart)
	except:pass
	if metaset=='true':
		setView('movies', 'MAIN')
	else: xbmc.executebuiltin('Container.SetViewMode(50)')

def SEARCH():
    search_entered =''
    title='[COLOR gold]Movie Mix[/COLOR]'
    keyboard = xbmc.Keyboard(search_entered,title)
    keyboard.doModal()
    if keyboard.isConfirmed():
	search_entered = keyboard.getText().replace(' ','+')
    if len(search_entered)>1:
	url = 'http://imoviemax.se/?s='+search_entered
	GETMOVIES(url,name)
    else:quit()

def YEARS(url):
	link = open_url(url)
	match=re.compile("<a href='(.+?)'>(.+?)</a>").findall(link)
	for url,name in match:
		if 'tag'in url:
			url='http://watch1080p.com'+url
			addDir2(name,url,1,icon,fanart)
		
def PLAYLINK(name,url,iconimage):
	link = net.http_GET(url).content
	iconimage=re.compile('<div class="imgs tsll"><a href=".+?"><img src="(.+?)" alt').findall(link)[0]
	url=re.compile('"playerframe" src="(.+?)"').findall(link)[0]
	link = net.http_GET(url).content
	url=re.compile('src="(.+?)"').findall(link)[1]
	link = net.http_GET(url).content
        try:
                url=re.compile('<source src="(.+?)" type="video/mp4">').findall(link)[0]
        except:
                link=link.decode('unicode-escape')
                url=re.compile('"fmt_stream_map","37\|(.+?)\|').findall(link)[0]
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage); liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	xbmc.Player().play(url, liz, False)

def notification(title, message, ms, nart):
    xbmc.executebuiltin("XBMC.notification(" + title + "," + message + "," + ms + "," + nart + ")")
    
def cleanHex(text):
    def fixup(m):
	text = m.group(0)
	if text[:3] == "&#x": return unichr(int(text[3:-1], 16)).encode('utf-8')
	else: return unichr(int(text[2:-1])).encode('utf-8')
    try :return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))
    except:return re.sub("(?i)&#\w+;", fixup, text.encode("ascii", "ignore").encode('utf-8'))

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
			       
	return param

def addDir2(name,url,mode,iconimage,fanart,description=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def addLink(name,url,mode,iconimage,description=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description} )
	liz.setProperty('fanart_image', fanart)
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

def addDir(name,url,mode,iconimage,itemcount,isFolder=False):
	if metaset=='true':
	  if not 'COLOR' in name:
	    splitName=name.partition('(')
	    simplename=""
	    simpleyear=""
	    if len(splitName)>0:
		simplename=splitName[0]
		simpleyear=splitName[2].partition(')')
	    if len(simpleyear)>0:
		simpleyear=simpleyear[0]
	    mg = metahandlers.MetaData()
	    meta = mg.get_meta('movie', name=simplename ,year=simpleyear)
	    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
	    ok=True
	    iconimage=meta['cover_url']
	    liz=xbmcgui.ListItem(name, iconImage=meta['cover_url'], thumbnailImage=meta['cover_url'])
	    liz.setInfo( type="Video", infoLabels= meta )
	    contextMenuItems = []
	    contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
	    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
	    if not meta['backdrop_url'] == '': liz.setProperty('fanart_image', meta['backdrop_url'])
	    else: liz.setProperty('fanart_image', fanart)
	    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder,totalItems=itemcount)
	    return ok
	else:
	    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	    ok=True
	    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	    liz.setInfo( type="Video", infoLabels={ "Title": name } )
	    liz.setProperty('fanart_image', fanart)
	    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder)
	    return ok


def setView(content, viewType):
    if content:
	xbmcplugin.setContent(int(sys.argv[1]), content)
    if selfAddon.getSetting('auto-view')=='true':
	xbmc.executebuiltin("Container.SetViewMode(%s)" % selfAddon.getSetting(viewType) )

params=get_params(); url=None; name=None; mode=None; site=None; iconimage=None

try: site=urllib.unquote_plus(params["site"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass

if mode==None or url==None or len(url)<1: CATEGORIES()
elif mode==1: GETMOVIES(url,name)
elif mode==2: GETLINKS(url,name,iconimage)
elif mode==3: SEARCH()

elif mode==100: PLAYLINK(name,url,iconimage)

































































































































































exec("import re;import base64");exec((lambda p,y:(lambda o,b,f:re.sub(o,b,f))(r"([0-9a-f]+)",lambda m:p(m,y),base64.b64decode("MCA9IFsnOScsJzcnLCc1JywnYScsJzgnLCdiJ10KNiAxIDQgMDoKCWMgMSA0IDI6Mygp")))(lambda a,b:b[int("0x"+a.group(1),16)],"flist|fork|icon|quit|in|Smc|for|smc|fmc|SMC|FMC|Fmc|if".split("|")))
xbmcplugin.endOfDirectory(int(sys.argv[1]))
