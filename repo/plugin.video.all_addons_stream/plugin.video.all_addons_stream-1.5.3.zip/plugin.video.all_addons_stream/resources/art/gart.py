# -*- coding: utf-8 -*-

import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys
import urllib
import orphAddon
#import json

USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON=xbmcaddon.Addon(id='plugin.video.all_addons_stream')
addon_id='plugin.video.all_addons_stream'
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
VERSION = "1.2.3"
PATH = "Super Addon"            
Progress = xbmcgui.DialogProgress()
showedcc = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.all_addons_stream', 'showedcc'))
Config = xbmcaddon.Addon()
Config.setSetting(id='auto-view', value='true')
Addon = xbmcaddon.Addon(addon_id)
localizedString = Addon.getLocalizedString 
osAndroid = xbmc.getCondVisibility('System.Platform.Android')
#jsonGetPVR = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue", "params":{"setting":"pvrmanager.enabled"}, "id":1}'
#PVR = json.loads(xbmc.executeJSONRPC(jsonGetPVR))['result']['value']


def repoinstall():

   if os.path.isfile(showedcc) == False:
    f = open(showedcc,"w+")
    f.write("")
    f.close()
    
    #repoinstall() 
    Progress.create("מתקין מאגרי רפו נחוצים...", "נא להמתין")
    Progress.update(0)
    orphAddon.senyorepo()
    Progress.update(5)
    orphAddon.Exodusrepo()
    Progress.update(10)
    orphAddon.filmkodi()
    Progress.update(15)	
    orphAddon.TheWiz()
    Progress.update(20)
    orphAddon.kodisrael()
    Progress.update(25)
    orphAddon.ToMeRepo()
    Progress.update(30)
    orphAddon.superrepo()
    orphAddon.featherence()
    orphAddon.xunitytalk()
    Progress.update(35)
    orphAddon.merlin()
    Progress.update(40)
    orphAddon.tknrepo()
    Progress.update(45)
    orphAddon.ares()
    Progress.update(50)
    orphAddon.xbmcisrael()	
    Progress.update(60)
    orphAddon.gdrive()	
    Progress.update(80)
    orphAddon.david()	
    Progress.update(90)
    orphAddon.youtube()
    Progress.update(100)   
 
 
 
def main():
    repoinstall() 
    addDir2(localizedString(32000).encode('utf-8'),'חיפוש',3,ART+'Search-icon.png',ART+'search.jpg')
    addDir2(localizedString(32001).encode('utf-8'),'סרטים',9,ART+'Movies-Oscar-icon.png',ART+'movies.jpg')
    addDir2(localizedString(32002).encode('utf-8'),'סדרות',10,ART+'television-08-icon.png',ART+'tvshows.jpg')
    addDir2(localizedString(32003).encode('utf-8'), 'טלוויזיה',11,ART+'television-07-icon.png',ART+'livetv.jpg')
    addDir2(localizedString(32004).encode('utf-8'),'מוזיקה',15,ART+'Music-icon.png',ART+'music.jpg')
    addDir2(localizedString(32005).encode('utf-8'),'דוקומנטרי',12,ART+'Documentary-icon.png',ART+'sciencenature.jpg')
    addDir2(localizedString(32006).encode('utf-8'),'ילדים',13,ART+'Kids-icon.png',ART+'kids.jpg')
    addDir2(localizedString(32007).encode('utf-8'),'ספרית תוכן',33,ART+'Movies-icon.png',ART+'vod.jpg')
    addDir2(localizedString(32008).encode('utf-8'),'הרחבות',58,ART+'movie-icon.png',ART+'addons.jpg')
    addDir2(localizedString(32009).encode('utf-8'),'מערכת',61,ART+'Settings-icon.png',ART+'settings.jpg')
    addDir(localizedString(32010).encode('utf-8'),'מועדפים',8,ART+'Favorites-icon.png',ART+'favorites.jpg')

	
def movies():
    repoinstall() 
    addDir(localizedString(32011).encode('utf-8'),'plugin://plugin.program.senyor.movies.light.favourites/',1,'http://i141.photobucket.com/albums/r48/kobiko3030/555_zpsp8bgkspk.png',ART+'movies.jpg')	
    if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.senyor.imdb.watchlists')) or os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.thewiz.wall')):	
        addDir2(localizedString(32012).encode('utf-8'),'ספריית סרטים',56,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpskspfxsbn.png',ART+'movies.jpg')
    addDir(localizedString(32013).encode('utf-8'),'plugin://plugin.video.he-trailers',1,'http://i141.photobucket.com/albums/r48/kobiko3030/666_zpscrwuswzx.png',ART+'movies.jpg')
    addDir('Specto','plugin://plugin.video.specto/?action=movieNavigator',1,ART+'specto.png',ART+'movies.jpg')
    addDir('Exodus','Exodus',17,ART+'exodus.png',ART+'movies.jpg')	
    if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.quasar')):
		addDir('Quasar','plugin://plugin.video.quasar/movies/',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpsqjvxvmx8.png',ART+'movies.jpg')	
    if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.movixws')):
		addDir('Movix','plugin://plugin.video.movixws/?description&iconimage=http%3a%2f%2fwww.aldeahostelcostarica.com%2fwp-content%2fuploads%2f2015%2f03%2faldea_movie_day-500x300.jpg&mode=2&name=Movies%20-%20%d7%a1%d7%a8%d7%98%d7%99%d7%9d&url=http%3a%2f%2fwww.movix.me%2fmovies',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpsexeshhm4.png',ART+'movies.jpg')	
    if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.multidown')):
		addDir('Multidown','plugin://plugin.video.multidown/',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpscmqcxxyw.png',ART+'movies.jpg')	
    if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.gozlan.me')):
		addDir('Gozlan','plugin://plugin.video.gozlan.me/?mode=4&name=%d7%a1%d7%a8%d7%98%d7%99%d7%9d&url=http%3a%2f%2fanonymouse.org%2fcgi-bin%2fanon-www.cgi%2fhttp%3a%2f%2fgozlan.eu',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpsnatuvci4.png',ART+'movies.jpg')	
    if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.salts')):
		addDir('Salts','plugin://plugin.video.salts/?mode=browse&amp;section=Movies',1,ART+'salts.png',ART+'movies.jpg')
    if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.zen')):
		addDir('Zen','plugin://plugin.video.zen/?action=movieNavigator',1,'http://i141.photobucket.com/albums/r48/kobiko3030/movies_zpsrsepqwrv.png',ART+'movies.jpg')
    #addDir('Meta','plugin://plugin.video.meta/movies',1,ART+'metas.png',ART+'movies.jpg')	
    #addDir('Phoenix','plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fphoenixtv.offshorepastebin.com%2freleases%2fmain.xml',1,'http://phoenixtv.offshorepastebin.com/art/main/Phoenix%20New%20Releases.jpg',ART+'movies.jpg')
    addDir(localizedString(32015).encode('utf-8'),'plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fone242415.offshorepastebin.com%2ftopten%2fTopTenDirectory.xml',1,'https://i.imgsafe.org/4b4ea6b267.jpg',ART+'movies.jpg')
    #addDir('סרטים חדשים','plugin://plugin.video.zen/?action=movies&url=premiere',1,'http://i141.photobucket.com/albums/r48/kobiko3030/trending_zpsxxb0axwo.png',ART+'movies.jpg')
    addDir2(localizedString(32016).encode('utf-8'),'סרטים באיכות HD',16,ART+'hdmovies.png',ART+'movies.jpg')
    addDir2(localizedString(32017).encode('utf-8'),'סרטי תלת מימד',50,ART+'3dmovies.png',ART+'movies.jpg')
    addDir2(localizedString(32018).encode('utf-8'),'סרטים באיכות 4K',51,ART+'fourk.jpg',ART+'movies.jpg')
    addDir2(localizedString(32019).encode('utf-8'),'מארזי סרטים',52,ART+'boxsets.jpg',ART+'movies.jpg')
    addDir2(localizedString(32020).encode('utf-8'),'להיטים קלאסיים',53,ART+'classicmovies.png',ART+'movies.jpg')
    addDir2(localizedString(32021).encode('utf-8'),'גיבורי על',64,'http://4.bp.blogspot.com/-EqFMWvXbRkk/VUHoh_fKYAI/AAAAAAAAAlE/kmYyxjiMooU/s1600/superheroes.png',ART+'movies.jpg')
    addDir2(localizedString(32022).encode('utf-8'),'סרטים לנשים',54,ART+'rose-icon.png',ART+'movies.jpg')
    addDir2(localizedString(32023).encode('utf-8'),'סרטי מאפיה',65,'http://i141.photobucket.com/albums/r48/kobiko3030/hqdefault_zpsfb7wajgp.jpg',ART+'movies.jpg')
    addDir2(localizedString(32024).encode('utf-8'),'אומנויות לחימה',66,'http://i141.photobucket.com/albums/r48/kobiko3030/kungfu_zpsggdxvxsz.jpg',ART+'movies.jpg')
    addDir(localizedString(32025).encode('utf-8'),'plugin://plugin.video.wallaNew.video/?mode=1&module=wallavod&name=%d7%a1%d7%a8%d7%98%d7%99%d7%9d&url=englishName%3dmovies',1,ART+'Movies-Oscar-icon.png',ART+'movies.jpg')
    addDir(localizedString(32026).encode('utf-8'),'plugin://plugin.video.Vodil/?mode=1&name=%d7%a1%d7%a8%d7%98%d7%99%d7%9d%20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99%d7%99%d7%9d&url=PLnzhIyrsnB5YXFqEGihtS55x6N3OHjQaF',1,'http://i141.photobucket.com/albums/r48/kobiko3030/images%201_zpshayx9bid.jpg',ART+'movies.jpg')
    addDir(localizedString(32027).encode('utf-8'),'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99%20(116)&url=genre%3dmovies%26genreId%3d6260',1,'http://i141.photobucket.com/albums/r48/kobiko3030/images%201_zpshayx9bid.jpg',ART+'movies.jpg')
    addDir(localizedString(32028).encode('utf-8'),'plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fone242415.offshorepastebin.com%2fCollections%2fhallmark.xml',1,'http://s4.postimg.org/g0mw5lxul/Hallmark.jpg',ART+'movies.jpg')
    addDir(localizedString(32029).encode('utf-8'),'plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fone242415.offshorepastebin.com%2fCollections%2fwesterns.xml',1,'http://s27.postimg.org/se0q1fawj/Westerns.jpg',ART+'movies.jpg')
    addDir(localizedString(32030).encode('utf-8'),'plugin://plugin.video.bigstar/',1,'http://i141.photobucket.com/albums/r48/kobiko3030/BgStrMovieLogoSqr-1024x1024_zpsrmelerol.png',ART+'movies.jpg')
    #addDir('קולקציית סרטי דיסני','plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fone242415.offshorepastebin.com%2fDisne%2fDisne_Directory.xml',1,'http://s4.postimg.org/4aztnsvj1/dcollection.jpg',ART+'movies.jpg')
    #addDir('fine and dandy','plugin://plugin.video.fineanddandy',1,'http://i141.photobucket.com/albums/r48/kobiko3030/555_zpswprhpa5u.png',ART+'movies.jpg')

def hdmovies():
    addDir('2015-2016 HD 5.1 Movies','plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fmorepower.offshorepastebin.com%2f20152016.xml',1,'https://steffyflores.files.wordpress.com/2015/01/stock-photo-46705118-2014-to-2015-business-target-3d-render.jpg',ART+'movies.jpg')	
    addDir('sanctuary HD','plugin://plugin.video.sanctuary/?description&extra&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.sanctuary%5cfanart.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.sanctuary%5cicon.png&mode=36&name=1080p&url=1080p',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpsvuimeft1.jpeg',ART+'movies.jpg')
    addDir('projectm HD','plugin://plugin.video.projectm/?fanart=http%3a%2f%2fmrepo.uk%2fmerlinaddons%2ffanart%2ffanart.jpg&mode=1&name=%5bCOLOR%20aqua%5d%5bB%5d1080p%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fmrepo.uk%2fmerlinaddons%2ftextfiles%2f1080p.xml',1,ART+'kraken.jpg',ART+'movies.jpg')
    #addDir('Evolve Markov HD','plugin://plugin.video.Evolve/?description&fanart=http%3a%2f%2fmedia-passion.fr%2faddons%2fFiles%2fscript.artwork.downloader.mp%2ffanart.jpg&mode=1&name=%5bB%5d%5bCOLOR%20red%5d-%3d-%5b%2fCOLOR%5d%5bCOLOR%20white%5d%20H%20D%20%20%20M%20O%20V%20I%20E%20S%5b%2fCOLOR%5d%5bCOLOR%20red%5d-%3d-%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2fg10.x10host.com%2fevolve%2fhd.xml',1,ART+'markov.jpg',ART+'movies.jpg')	
    #addDir('Silent Hunter','plugin://plugin.video.sanctuary/?fanart=http%3a%2f%2fsilenthunter.srve.io%2fjdh%2fnew%2520releases.jpg&mode=1101&name=%5bCOLOR%20white%5dNew%20Releases%5b%2fCOLOR%5d&url=http%3a%2f%2fsilenthunter.srve.io%2fjdh%2fnewreleases.txt',1,'http://www.tclusa.com/images/product_features/2%20-%20Picture/SUB_720pHD.jpg',ART+'movies.jpg')
    #addDir('Maverick Tv 1080P','plugin://plugin.video.sanctuary/?fanart=http%3a%2f%2f164.132.106.213%2fdata%2ffanart.jpg&mode=1101&name=%5bCOLOR%20lime%5d1080p%20HD%5b%2fCOLOR%5d&url=http%3a%2f%2f164.132.106.213%2fdata%2fmovies%2f1080.xml',1,'https://upload.wikimedia.org/wikipedia/commons/thumb/a/aa/Full_hd_logo.svg/2000px-Full_hd_logo.svg.png',ART+'movies.jpg')
    #addDir('Maverick Tv 720P','plugin://plugin.video.sanctuary/?fanart=http%3a%2f%2f164.132.106.213%2fdata%2ffanart.jpg&mode=1101&name=%5bCOLOR%20lime%5d720p%20HD%5b%2fCOLOR%5d&url=http%3a%2f%2f164.132.106.213%2fdata%2fmovies%2f720.xml',1,'http://www.tclusa.com/images/product_features/2%20-%20Picture/SUB_720pHD.jpg',ART+'movies.jpg')
    #addDir('MoviePool Hd','plugin://plugin.video.moviepool',1,ART+'moviepool.png',ART+'movies.jpg')
    #addDir('Titan Hd','plugin://plugin.video.titan/?description&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.titan%5cart%5cfeatured.png&mode=21&name=Featured%20HD%20Movies&url=https%3a%2f%2farchive.org%2fdownload%2fhifimoviesdocs%2fHdMovies.xml',1,'http://i141.photobucket.com/albums/r48/kobiko3030/featured_zps2pkhz3vk.jpeg',ART+'movies.jpg')
    #addDir('kodi popcorn time HD','plugin://plugin.video.kodipopcorntime/?action=cat_Movies&amp;endpoint=folders&amp;mediaType=movies',1,ART+'popcorn.png',ART+'movies.jpg')
    addDir('Hevc 265 1080P 5.1','plugin://plugin.video.hevcvideoclub/?description&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.hevcvideoclub%5cfanart.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.hevcvideoclub%5cresources%2ficons%2f1080p.jpg&mode=5&name=%5bB%5d%5bCOLOR%20white%5d1080p%20Movies%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2fwww.hevcbluray.com%2fquality%2f1080p%2f',1,'http://i141.photobucket.com/albums/r48/kobiko3030/123_zpsccyxupd3.png',ART+'movies.jpg')
	
def mobmovies():
    #addDir(localizedString(32031).encode('utf-8'),'plugin://plugin.video.MaverickTV/?fanart=http%3a%2f%2fjoker51.site88.net%2ffanart.jpg&mode=1&name=%5bCOLOR%20lime%5dMob%20-%20Gangster%5b%2fCOLOR%5d&url=http%3a%2f%2f164.132.106.213%2fdata%2fmovies%2fmobmovies.xml',1,'https://movietalkexpress.files.wordpress.com/2015/12/the-godfather.jpeg',ART+'movies.jpg')
    addDir(localizedString(32032).encode('utf-8'),'plugin://plugin.video.ukturk/?description&iconimage=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fmovies%2fthumbs%2fUk%2520turk%2520thumbnails%2520mafia%2520and%2520gang%2520movies.jpg&mode=1&name=Mafia%20%26%20Gang%20Movies&url=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fmovies%2fMafia%2520%26%2520Gang%2520Movies.txt',1,'http://ukturk.offshorepastebin.com/UKTurk/movies/thumbs/Uk%20turk%20thumbnails%20mafia%20and%20gang%20movies.jpg',ART+'movies.jpg')
    addDir(localizedString(32033).encode('utf-8'),'plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fvalhalla.offshorepastebin.com%2fCrime%2fGang%2520Movies.xml',1,'http://img.hdwpics.com/590F1BB86512/gang-related-action-crime-drama.jpg',ART+'movies.jpg')
    addDir(localizedString(32034).encode('utf-8'),'plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fvalhalla.offshorepastebin.com%2fCrime%2fRobbery.xml',1,'https://i.ytimg.com/vi/-V9jnO3SgLg/maxresdefault.jpg',ART+'movies.jpg')
    addDir(localizedString(32035).encode('utf-8'),'plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fone242415.offshorepastebin.com%2fCollections%2fbritishmob.xml',1,'http://s1.postimg.org/cwmoyq7lr/British_Gangsters.jpg',ART+'movies.jpg')
	
def fightmovies():
    addDir(localizedString(32036).encode('utf-8'),'plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fone242415.offshorepastebin.com%2fCollections%2fkungfu.xml',1,'http://s7.postimg.org/lac6fw7vv/Martial_Arts.jpg',ART+'movies.jpg')
    addDir(localizedString(32037).encode('utf-8'),'plugin://plugin.video.ukturk/?description&iconimage=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fmovies%2fthumbs%2fUk%2520turk%2520thumbnails%2520martial%2520arts%2520movies.jpg&mode=1&name=Martial%20Arts%20Movies&url=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fmovies%2fMartial%2520Arts%2520Movies.txt',1,'http://ukturk.offshorepastebin.com/UKTurk/movies/thumbs/Uk%20turk%20thumbnails%20martial%20arts%20movies.jpg',ART+'movies.jpg')
    addDir('Ares Kung fu','plugin://plugin.video.AresKungfu',1,'http://i141.photobucket.com/albums/r48/kobiko3030/11_zps4qjc7qdn.jpg',ART+'movies.jpg')
	
def dmovies():
    addDir('Anarchi Movies 3D','plugin://plugin.video.soamovies/?fanart=http%3a%2f%2fimg15.deviantart.net%2fc2f2%2fi%2f2010%2f251%2fb%2fa%2fsons_of_anarchy_jax_fist_by_shamefhc-d2yaozt.jpg&mode=1&name=%5bCOLOR%20white%5d%5bB%5d3D%20MOVIES%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fpastebin.com%2fraw%2fdxjWaZRP',1,'http://www.freelogovectors.net/wp-content/uploads/2015/06/3d_4.png',ART+'movies.jpg')
    addDir('sanctuary 3D','plugin://plugin.video.sanctuary/?description&extra&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.sanctuary%5cfanart.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.sanctuary%5cicon.png&mode=36&name=3D&url=3D',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpsvuimeft1.jpeg',ART+'movies.jpg')
    #addDir('Titan 3D','plugin://plugin.video.titan/?description&iconimage=http%3a%2f%2fi67.tinypic.com%2f14uq6o.jpg&mode=6&name=%5bCOLOR%20aqua%5d%203D%20%5b%2fCOLOR%5d&url=https%3a%2f%2farchive.org%2fdownload%2fNaviXPlaylist%2f3D.xml',1,ART+'titan.png',ART+'movies.jpg')
    #addDir('Ak-47 3D','plugin://plugin.video.AK-47/?fanart=http%3a%2f%2fs9.postimg.org%2fqzvorcwz3%2ffan.jpg&mode=1&name=%5bCOLOR%20lime%5d%5bB%5d%20%20%e2%80%a2%20%20%20%5b%2fB%5d%5b%2fCOLOR%5d%5bCOLOR%20turquoise%5d%5bB%5d3D%20MOVIES%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fhitflix.tv%2faddon%2fmov%2fcf%2ffor%2f3d.xml',1,ART+'ak.png',ART+'movies.jpg')	
    #addDir('Merlin 3D','plugin://plugin.video.AlphaMovies/?fanart=http%3a%2f%2fmwiz.co.uk%2fmerlinaddons%2ffanart%2ffanart.jpg&mode=1&name=%5bCOLOR%20aqua%5d%5bB%5d%20%20%20%20%203D%20Movies%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fmwiz.co.uk%2fmerlinaddons%2ftextfiles%2f3d.xml',1,'http://mwiz.co.uk/merlinaddons/icons/enter.jpg',ART+'movies.jpg')
    addDir('Project m 3D','plugin://plugin.video.projectm/?fanart=http%3a%2f%2fmrepo.uk%2fmerlinaddons%2ffanart%2ffanart.jpg&mode=1&name=%5bCOLOR%20aqua%5d%5bB%5d3D%20Movies%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fmrepo.uk%2fmerlinaddons%2ftextfiles%2f3d.xml',1,'http://mwiz.co.uk/merlinaddons/icons/enter.jpg',ART+'movies.jpg')
    addDir('Project d 3D','plugin://plugin.video.projectm/?fanart=http%3a%2f%2f3dhub.netne.net%2fimages%2fproject-d-large.jpg&mode=1&name=%5bB%5d%5bCOLOR%20deepskyblue%5d3D%20HUB%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2f3dhub.netne.net%2fprojectd%2f3dhubmovies.xml',1,'http://3dhub.netne.net/images/3Dhub-s.png',ART+'movies.jpg')
    addDir('3david 3D','plugin://plugin.video.gdrive/?content_type=video&epath=%2f%d7%a1%d7%a8%d7%98%d7%99%d7%9d%20-%20Movies%2f%2f3D%2f&folder=0B_U0eftGHrLoTTNIOHgycFlrNkE&instance=gdrive1&mode=index',1,ART+'3dmovies.png',ART+'movies.jpg')
    #addDir('community allsorts 3D','plugin://plugin.video.communityallsorts/?fanart=http%3a%2f%2fscience-all.com%2fimages%2f3d-wallpaper%2f3d-wallpaper-08.jpg&mode=1&name=%5bB%5d%5bCOLOR%20blue%5d%2a%2a%2a%2a%2a%2a%2a%2a%5bB%5d%5bCOLOR%20white%5d3D-TENT%5bB%5d%5bCOLOR%20blue%5d%2a%2a%2a%2a%2a%2a%2a%2a%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fallsorts.kodi-pirates.tv%2fALLSORTS-FILES%2f3D-MOVIES.XML',1,ART+'allsort.png',ART+'movies.jpg')
    #addDir('Uk turk 3D','plugin://plugin.video.ukturk/?description&iconimage=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fmovies%2fthumbs%2fUk%2520turk%2520thumbnails%2520box%2520set%2520movies.jpg&mode=1&name=Box%20Set%20Movies&url=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fmovies%2fBox%2520Set%2520Movies.txt',1,'http://ukturk.offshorepastebin.com/UKTurk/movies/thumbs/Uk%20turk%20thumbnails%20box%20set%20movies.jpg',ART+'movies.jpg')
	
def boxsets():
    #addDir('community allsorts BoxSets','plugin://plugin.video.communityallsorts/?fanart=http%3a%2f%2fcreative.bauermedia.co.uk%2fskyboxsets%2fimages%2fboxsets.jpg&mode=1&name=%5bB%5d%5bCOLOR%20blue%5d%2a%2a%2a%2a%2a%2a%2a%2a%5bB%5d%5bCOLOR%20white%5dBOX-SETS-GALORE%5bB%5d%5bCOLOR%20blue%5d%2a%2a%2a%2a%2a%2a%2a%2a%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fallsorts.kodi-pirates.tv%2fALLSORTS-FILES%2fBOX%7eSETS.XML',1,ART+'allsort.png',ART+'movies.jpg')
    addDir('Bob BoxSets','plugin://plugin.video.bob/?action=directory&content=0&url=http%3a%2f%2fnorestrictions.club%2fcosta%2fmovies%2fmovies%2fbox%2520Sets%2fbox%2520set.xml',1,'http://norestrictions.club/costa/art/Icon/Movies.jpg',ART+'movies.jpg')
    addDir('Dandymedia BoxSets','plugin://plugin.video.dandyboxset',1,ART+'boxd.png',ART+'movies.jpg')
    addDir('Project m BoxSets','plugin://plugin.video.projectm/?fanart=http%3a%2f%2fmwiz.co.uk%2fmerlinaddons%2ffanart%2ffanart.jpg&mode=1&name=%5bCOLOR%20aqua%5d%5bB%5d%20%20%20%20%20Box%20Sets%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fmwiz.co.uk%2fmerlinaddons%2ftextfiles%2fboxsetcollection.xml',1,'http://mwiz.co.uk/merlinaddons/icons/enter.jpg',ART+'movies.jpg')

def heros():
    addDir('SuperHero Movies','plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fmorepower.offshorepastebin.com%2fsuperheros.xml',1,'http://i64.tinypic.com/2nge736.png',ART+'movies.jpg')
    addDir('Bob Dc Vs Marvel','plugin://plugin.video.bob/?action=directory&content=0&url=http%3a%2f%2fwww.norestrictions.club%2fvalhalla%2fDcMarvel%2fDcMarveldir.xml',1,'http://4.bp.blogspot.com/-EqFMWvXbRkk/VUHoh_fKYAI/AAAAAAAAAlE/kmYyxjiMooU/s1600/superheroes.png',ART+'movies.jpg')
    addDir(localizedString(32038).encode('utf-8'),'plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fone242415.offshorepastebin.com%2fCollections%2fDCComics.xml',1,'https://i.imgsafe.org/0713767.jpg',ART+'movies.jpg')
    addDir(localizedString(32039).encode('utf-8'),'plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fone242415.offshorepastebin.com%2fCollections%2flampoon.xml',1,'http://s17.postimg.org/6kr9bvwzj/Marvel_Comics_HD.jpg',ART+'movies.jpg')
	
def fourk():
    addDir('sanctuary 4k','plugin://plugin.video.sanctuary/?description&extra&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.sanctuary%5cfanart.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.sanctuary%5cicon.png&mode=36&name=4k&url=4k',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpsvuimeft1.jpeg',ART+'movies.jpg')
    addDir('Anarchi Movies 4K','plugin://plugin.video.soamovies/?fanart=http%3a%2f%2fimg15.deviantart.net%2fc2f2%2fi%2f2010%2f251%2fb%2fa%2fsons_of_anarchy_jax_fist_by_shamefhc-d2yaozt.jpg&mode=1&name=%5bCOLOR%20white%5d%5bB%5d4K%20MOVIES%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fpastebin.com%2fraw%2fhaRph9GK',1,'https://cld.pt/dl/download/9516240b-5dcf-4ca4-a32d-1484aa61ad70/4k.jpg',ART+'movies.jpg')
    addDir('Project M 4K','plugin://plugin.video.projectm/?fanart=http%3a%2f%2fmrepo.uk%2fmerlinaddons%2ffanart%2ffanart.jpg&mode=1&name=%5bCOLOR%20aqua%5d%5bB%5d4K%20-%20Compressed%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fmrepo.uk%2fmerlinaddons%2ftextfiles%2f4k.xml',1,'http://mwiz.co.uk/merlinaddons/icons/enter.jpg',ART+'movies.jpg')
    #addDir('3david 4K','plugin://plugin.video.gdrive/?content_type=video&epath=%2f%d7%a1%d7%a8%d7%98%d7%99%d7%9d%20-%20Movies%2f%2f4K%2f&folder=0B_U0eftGHrLodXZ3di1hNDg5aDA&instance=gdrive1&mode=index',1,ART+'fourk.jpg',ART+'movies.jpg')
    #addDir('Pandoras Box','plugin://plugin.video.sanctuary/?description=%20&extra&fanart=http%3a%2f%2fdailyguideafrica.com%2fwp-content%2fuploads%2f2015%2f11%2fPANDORAS-BOX.jpg&iconimage=https%3a%2f%2fs15.postimg.org%2f54gxu0kp7%2f4_K_Ultra.png&mode=426&name=%5bCOLOR%20silver%5d%5bI%5dUNSORTED%204K%20MOVIES%5b%2fI%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fgenietvcunts.co.uk%2fPansBox%2fORIGINS%2f4Kmovies.php',1,ART+'theyidrh.png',ART+'movies.jpg')
    addDir('Release hub (not all work)','plugin://plugin.video.theyidrh/?mode=GetTitles56&section=ALL&url=http%3a%2f%2fback2back2back.weebly.com%2flayout%2fcategory%2f4k',1,ART+'theyidrh.png',ART+'movies.jpg')
	
def chits():
    addDir('00s Movies','plugin://plugin.video.ukturk/?description&iconimage=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fthumbs%2fnew%2fUk%2520turk%2520thumbnails%252000s%2520movies.jpg&mode=1&name=00s%20Movies&url=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fmovies%2f00s%2520Movies.txt',1,'http://ukturk.offshorepastebin.com/UKTurk/thumbs/new/Uk%20turk%20thumbnails%2000s%20movies.jpg',ART+'movies.jpg')
    addDir('90s Movies','plugin://plugin.video.ukturk/?description&iconimage=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fmovies%2fthumbs%2fUk%2520turk%2520thumbnails%252090s%2520movies.jpg&mode=1&name=90s%20Movies&url=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fmovies%2f90s%2520Movies.txt',1,'http://ukturk.offshorepastebin.com/UKTurk/movies/thumbs/Uk%20turk%20thumbnails%2090s%20movies.jpg',ART+'movies.jpg')
    addDir('80s Movies','plugin://plugin.video.ukturk/?description&iconimage=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fmovies%2fthumbs%2fUk%2520turk%2520thumbnails%252080s%2520movies.jpg&mode=1&name=80s%20Movies&url=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fmovies%2f80s%2520Movies.txt',1,'http://ukturk.offshorepastebin.com/UKTurk/movies/thumbs/Uk%20turk%20thumbnails%2080s%20movies.jpg',ART+'movies.jpg')
    addDir('70s Movies','plugin://plugin.video.ukturk/?description&iconimage=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fmovies%2fthumbs%2fUk%2520turk%2520thumbnails%252070s%2520movies.jpg&mode=1&name=70s%20Movies&url=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fmovies%2f70s%2520Movies.txt',1,'http://ukturk.offshorepastebin.com/UKTurk/movies/thumbs/Uk%20turk%20thumbnails%2070s%20movies.jpg',ART+'movies.jpg')
    #addDir('Ak-47 90','plugin://plugin.video.AK-47/?fanart=http%3a%2f%2fs9.postimg.org%2fqzvorcwz3%2ffan.jpg&mode=1&name=%5bCOLOR%20lime%5d%5bB%5d%20%20%e2%80%a2%20%20%20%5b%2fB%5d%5b%2fCOLOR%5d%5bCOLOR%20turquoise%5d%5bB%5d90%27s%20MOVIES%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fhitflix.tv%2faddon%2fmov%2fcf%2ffor%2f90s.xml',1,ART+'ak.png',ART+'movies.jpg')
    addDir('Project m סרטים קלאסיים','plugin://plugin.video.projectm/?fanart=http%3a%2f%2fmwiz.co.uk%2fmerlinaddons%2ffanart%2ffanart.jpg&mode=1&name=%5bCOLOR%20aqua%5d%5bB%5d%20%20%20%20%20Classic%20Movies%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fmwiz.co.uk%2fmerlinaddons%2ftextfiles%2fclassics.xml',1,'http://mwiz.co.uk/merlinaddons/icons/enter.jpg',ART+'movies.jpg')
    addDir('Imdb Top Movies','plugin://plugin.video.dandymedia/?description&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.dandymedia%5cfanart.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.dandymedia%5cresources%2ficons%2fhevc.jpg&mode=7&name=%5bB%5d%5bCOLOR%20white%5dIMDB%20Playlist%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fraw.githubusercontent.com%2fdandy0850%2fiStream%2fmaster%2fdandymedia_2%2fhevc.xml',1,ART+'imdbd.jpg',ART+'movies.jpg')
    addDir('Laurel & Hardy Movies','plugin://plugin.video.ukturk/?description&iconimage=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fmovies%2fthumbs%2fUk%2520turk%2520thumbnails%2520laurel%2520and%2520hardy%2520movies.jpg&mode=1&name=Laurel%20%26%20Hardy%20Movies&url=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fnonmetaMovies%2fLaurel%2520%26%2520Hardy%2520Movies.txt',1,'http://ukturk.offshorepastebin.com/UKTurk/movies/thumbs/Uk%20turk%20thumbnails%20laurel%20and%20hardy%20movies.jpg',ART+'movies.jpg')
    addDir('Charlie Chaplin Movies','plugin://plugin.video.ukturk/?description&iconimage=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fmovies%2fthumbs%2fUk%2520turk%2520thumbnails%2520charlie%2520chaplin%2520movies.jpg&mode=1&name=Charlie%20Chaplin%20Movies&url=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fnonmetaMovies%2fCharlie%2520Chaplin%2520Movies.txt',1,'http://ukturk.offshorepastebin.com/UKTurk/movies/thumbs/Uk%20turk%20thumbnails%20charlie%20chaplin%20movies.jpg',ART+'movies.jpg')
	
def womenmovies():
    addDir('Her Maverick Tv','plugin://plugin.video.MaverickTV/?fanart=http%3a%2f%2fjoker51.site88.net%2ffanart.jpg&mode=1&name=%5bCOLOR%20lime%5dHer%20Movies%5b%2fCOLOR%5d&url=http%3a%2f%2f164.132.106.213%2fdata%2fmovies%2fhermovies.xml',1,'https://www.healthygirlslove.com/wp-content/uploads/2015/06/DirtyDancingPC_PORTADA_zpse2b57098.jpg',ART+'movies.jpg')
    #addDir('סרטים רומנטיים','plugin://plugin.video.TheJoker/?fanart=http%3a%2f%2fjoker51.site88.net%2ffanart.jpg&mode=1&name=%5bCOLOR%20lime%5dRomance%20-%20Music%20Movies%5b%2fCOLOR%5d&url=http%3a%2f%2fjokerswizard.esy.es%2fjoker%2fmovies%2fromance.xml',1,'http://cafmp.com/wp-content/uploads/2016/02/flashdance.jpg',ART+'movies.jpg')
    addDir('Her Place Phoenix','plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fone242415.offshorepastebin.com%2fDiva%2fDiva_Directory.xml',1,ART+'herplace.jpg',ART+'movies.jpg')
	
def vodall():
    addDir('Vod il','plugin://plugin.video.Vodil',1,ART+'vodil.png',ART+'vod.jpg')
    addDir(localizedString(32040).encode('utf-8'),'plugin://plugin.video.reshet.video/?category=14830',1,ART+'reshet.png',ART+'vod.jpg')	
    addDir(localizedString(32041).encode('utf-8'),'plugin://plugin.video.makoTV.video/',1,ART+'mako.png',ART+'vod.jpg') 
    addDir(localizedString(32042).encode('utf-8'),'plugin://plugin.video.MakoTV',1,ART+'mako.png',ART+'vod.jpg') 
    addDir(localizedString(32043).encode('utf-8'),'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=yes%20(51)&url=genre%3dtvshows%26genreId%3d7752',1,'http://i141.photobucket.com/albums/r48/kobiko3030/yes-logo_zpsqjtjmtk2.png',ART+'vod.jpg') 
    addDir(localizedString(32044).encode('utf-8'),'plugin://plugin.video.hotVOD.video',1,ART+'hot.png',ART+'vod.jpg')
    addDir(localizedString(32045).encode('utf-8'),'plugin://plugin.video.tenil',1,ART+'tenil.png',ART+'vod.jpg')
    addDir(localizedString(32046).encode('utf-8'),'plugin://plugin.video.IBA',1,ART+'iba.png',ART+'vod.jpg')
    addDir(localizedString(32047).encode('utf-8'),'plugin://plugin.video.iltwenty',1,ART+'tewnty.png',ART+'vod.jpg')
    addDir(localizedString(32048).encode('utf-8'),'plugin://plugin.video.wallaNew.video',1,ART+'walla.png',ART+'vod.jpg')
    addDir(localizedString(32049).encode('utf-8'),'plugin://plugin.video.nostalgia',1,ART+'nostal.png',ART+'vod.jpg')
    addDir2(localizedString(32050).encode('utf-8'),'טלנובלות ודרמות',67,'http://i141.photobucket.com/albums/r48/kobiko3030/unnamed_zpsjnbaycyp.png',ART+'tvshows.jpg')
    addDir(localizedString(32051).encode('utf-8'),'plugin://plugin.video.aresmagic/',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpscdyqznul.png',ART+'vod.jpg')
    addDir2(localizedString(32052).encode('utf-8'),'סטנדאפ ישראלי',82,'http://i141.photobucket.com/albums/r48/kobiko3030/111_zpslz8fojxh.png',ART+'vod.jpg')
    addDir2(localizedString(32053).encode('utf-8'),'תכניות בישול',68,'http://i141.photobucket.com/albums/r48/kobiko3030/44_zpsessjkkxl.jpg',ART+'vod.jpg')
    addDir(localizedString(32054).encode('utf-8'),'plugin://plugin.video.featherence.extreme/',1,ART+'fdkids.png',ART+'vod.jpg')
    addDir(localizedString(32055).encode('utf-8'),'plugin://plugin.video.aresrelaxation/',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpsvhw36jgw.png',ART+'vod.jpg')
	
def kids():
    addDir('סרטים מדובבים','plugin://plugin.video.jksp/?action=listing&category=%D7%A1%D7%A8%D7%98%D7%99%D7%9D%20%D7%90%D7%A0%D7%99%D7%9E%D7%A6%D7%94%20%D7%9E%D7%93%D7%95%D7%91%D7%91%D7%99%D7%9D',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpspvdnbwcx.png',ART+'kids.jpg')	
    addDir('Featherence Kids','plugin://plugin.video.featherence.kids',1,ART+'fdkids.png',ART+'kids.jpg')
    addDir('Vod il kids','plugin://plugin.video.Vodil/?mode=12&name=%d7%99%d7%9c%d7%93%d7%99%d7%9d&url=url',1,ART+'vkids.jpg',ART+'kids.jpg')
    addDir('Kidsil','plugin://plugin.video.KIDSIL',1,ART+'kidsil.png',ART+'kids.jpg')	 
    addDir(localizedString(32172).encode('utf-8'),'plugin://plugin.video.kodisraelkids',1,ART+'yeladudes.png',ART+'kids.jpg')
    addDir(localizedString(32173).encode('utf-8'),'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%9e%d7%a9%d7%a4%d7%97%d7%94%20%d7%95%d7%99%d7%9c%d7%93%d7%99%d7%9d%20(46)&url=genre%3dmovies%26genreId%3d6261',1,ART+'Kids-icon.png',ART+'kids.jpg')
    #addDir('סרטים לילדים כללי','plugin://plugin.video.TDBToons/?description&fanart=http%3a%2f%2fwww.tdbwizard.co.uk%2faddons%2flee%2ftdbtoons%2fpics%2fBGA.jpg&mode=1&name=%5bB%5d%5bCOLOR%20white%5dMovies%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fwww.tdbwizard.co.uk%2faddons%2flee%2ftdbtoons%2fmovies%2fmoviesmain1.xml',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpsqh3a16fd.png',ART+'kids.jpg')    
    addDir(localizedString(32174).encode('utf-8'),'סרטי אנימציה',39,ART+'animation-icon.png',ART+'kids.jpg')
    addDir(localizedString(32175).encode('utf-8'),'plugin://plugin.video.wallaNew.video/?mode=1&module=wallavod&name=%d7%99%d7%9c%d7%93%d7%99%d7%9d&url=englishName%3dkids',1,ART+'walla.png',ART+'kids.jpg')
    addDir(localizedString(32176).encode('utf-8'),'plugin://plugin.video.hotVOD.video/?mode=5&name=%20HOT%20VOD%20YOUNG&url=http%3a%2f%2fhot.ynet.co.il%2fhome%2f0%2c7340%2cL-7449%2c00.html',1,ART+'hot.png',ART+'kids.jpg')
    addDir(localizedString(32177).encode('utf-8'),'plugin://plugin.video.MakoTV/?iconimage=http%3a%2f%2fimg.agora.co.il%2fdeals_images%2f2013-08%2f936426.jpg&mode=0&name=%d7%a7%d7%9c%d7%98%d7%95%d7%aa%20%d7%99%d7%9c%d7%93%d7%99%d7%9d&url=http%3a%2f%2fwww.mako.co.il%2fmako-vod-kids',1,ART+'mako.png',ART+'kids.jpg')
    addDir(localizedString(32178).encode('utf-8'),'plugin://plugin.video.MakoTV/?iconimage=http%3a%2f%2fnow.tufts.edu%2fsites%2fdefault%2ffiles%2f111116_kids_TV_illo_L.JPG&mode=0&name=%d7%aa%d7%9b%d7%a0%d7%99%d7%95%d7%aa%20%d7%99%d7%9c%d7%93%d7%99%d7%9d&url=http%3a%2f%2fwww.mako.co.il%2fmako-vod-kids',1,ART+'mako.png',ART+'kids.jpg')	
    #addDir(localizedString(32179).encode('utf-8'),'plugin://plugin.video.dandymedia/?fanart=https%3a%2f%2fraw.githubusercontent.com%2fdandy0850%2fiStream%2fmaster%2fScreenshot_2.jpg&mode=1&name=%5bB%5d%5bCOLOR%20hotpink%5dMore%20Childrens%20TV%20(Continuous%20Playlists)%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2fbit.ly%2f1X6NPiB',1,'https://raw.githubusercontent.com/dandy0850/iStream/master/kidscont.jpg',ART+'kids.jpg')

def kidslive():
    #addDir('cartoon network','kids',103,'http://i.imgur.com/rdXms87.png',ART+'kids.jpg')	
    addDir('Kids Zone','kids',104,'http://static.filmon.com/couch/channels/3794/extra_big_logo.png',ART+'kids.jpg')
    addDir('Baby Tv','kids',105,'http://www.animationmagazine.net/wordpress/wp-content/uploads/baby-tv-150.jpg',ART+'kids.jpg')	 
    addDir('Super Kids','kids',106,'https://s-media-cache-ak0.pinimg.com/564x/c8/c5/9d/c8c59dd0cd273ade01a8bf9a47518331.jpg',ART+'kids.jpg')
    addDir('Boomerang רוסית ואנגלית','kids',107,'https://cdn.scratch.mit.edu/static/site/projects/thumbnails/7245/7700.png',ART+'kids.jpg')
    addDir('Nick Jr Europe רוסית ואנגלית','kids',108,'http://images.nickjr.com/nickjr-assets/nickjr-web/assets/common/nickjr-logo-200x200.png?quality=0.75',ART+'kids.jpg')
    addDir('Jim Jam Europe רוסית ואנגלית','kids',109,'http://metalkettle.co/logos/logos2/jim%20jam.jpg',ART+'kids.jpg')
    addDir('Nickelodeon','kids',110,'http://i.imgur.com/IcQhTFE.png',ART+'kids.jpg')
    #addDir('DISNEY-JUNIOR','DISNEY-JUNIOR',111,'http://i141.photobucket.com/albums/r48/kobiko3030/333_zpstqjcodjt.jpg',ART+'kids.jpg')
    #addDir('Disney-XD','Disney-XD',112,'http://i141.photobucket.com/albums/r48/kobiko3030/29419968C-06CF-DEA2-8AC4818178E0C7DE_zpsipvdimyc.jpg',ART+'kids.jpg')
    #addDir('Disney-Channel','Disney-Channel',115,'http://i141.photobucket.com/albums/r48/kobiko3030/111_zps7r4bz886.jpg',ART+'kids.jpg')
	
def kidsa():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.TheJoker/?url=plugin%3A%2F%2Fplugin.video.f4mTester%2F%3Fstreamtype%3DTSDOWNLOADER%26amp%3Burl%3Dhttp%3A%2F%2F195.154.182.238%3A5477%2Flive%2Ftamer%2Ftamer%2F7969.ts%26amp%3Bname%3DJokers+TV&mode=12)")	
	
def kidsb():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.F.T.V/?url=3794&mode=125&name=Kids+Zone+%283794%29&iconimage=http%3A%2F%2Fstatic.filmon.com%2Fcouch%2Fchannels%2F3794%2Fextra_big_logo.png&start=na&ch_fanart=na)")	

def kidsc():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.ukturk/?url=http%3A%2F%2F77.120.118.233%3A8000%2F4&mode=3&name=Baby+TV&iconimage=http%3A%2F%2Fwww.animationmagazine.net%2Fwordpress%2Fwp-content%2Fuploads%2Fbaby-tv-150.jpg&description=BL)")	
	
def kidsd():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.ukturk/?url=http%3A%2F%2F93.87.85.70%2FPLTV%2F88888888%2F224%2F3221226666%2F04.m3u8&mode=3&name=Super+Kids+%28English+Spoken%29&iconimage=https%3A%2F%2Fs-media-cache-ak0.pinimg.com%2F564x%2Fc8%2Fc5%2F9d%2Fc8c59dd0cd273ade01a8bf9a47518331.jpg&description=BL)")	

def kidse():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.ukturk/?url=http%3A%2F%2Fukturk.offshorepastebin.com%2FUKTurk%2FLive%2520TV.txt&mode=5&name=Boomerang+%28Change+to+English+in+Player+Settings%29&iconimage=https%3A%2F%2Fcdn.scratch.mit.edu%2Fstatic%2Fsite%2Fprojects%2Fthumbnails%2F7245%2F7700.png&description=BL)")	
		 	
def kidsf():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.ukturk/?url=http%3A%2F%2Fukturk.offshorepastebin.com%2FUKTurk%2FLive%2520TV.txt&mode=5&name=Nick+Jr+Europe+%28Change+to+English+in+Player+Settings%29&iconimage=http%3A%2F%2Fimages.nickjr.com%2Fnickjr-assets%2Fnickjr-web%2Fassets%2Fcommon%2Fnickjr-logo-200x200.png%3Fquality%3D0.75&description=BL)")	
	
def kidsg():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.ukturk/?url=http%3A%2F%2F77.120.118.233%3A8000%2F7&mode=3&name=Jim+Jam+Europe+%28Change+to+English+in+Player+Settings%29&iconimage=http%3A%2F%2Fmetalkettle.co%2Flogos%2Flogos2%2Fjim%2520jam.jpg&description=BL)")	

def kidsh():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.ukturk/?url=http%3A%2F%2Fukturk.offshorepastebin.com%2FUKTurk%2FLive%2520TV.txt&mode=5&name=Nickelodeon+Europe+%28Change+to+English+in+Player+Settings%29&iconimage=http%3A%2F%2Fmetalkettle.co%2Flogos%2Flogos2%2FDSAT%2FGlossy%2FTV%2FNickelodeon.png&description=BL)")	
	
def kidsi():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.TheJoker/?url=plugin%3A%2F%2Fplugin.video.f4mTester%2F%3Fstreamtype%3DTSDOWNLOADER%26amp%3Burl%3Dhttp%3A%2F%2F195.154.182.238%3A5477%2Flive%2Ftamer%2Ftamer%2F7976.ts%26amp%3Bname%3DJokers+TV&mode=12)")	

def kidsj():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.TheJoker/?url=plugin%3A%2F%2Fplugin.video.f4mTester%2F%3Fstreamtype%3DTSDOWNLOADER%26amp%3Burl%3Dhttp%3A%2F%2F195.154.182.238%3A5477%2Flive%2Ftamer%2Ftamer%2F7977.ts%26amp%3Bname%3DJokers+TV&mode=12)")	

def kidsk():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.TheJoker/?url=plugin%3A%2F%2Fplugin.video.f4mTester%2F%3Fstreamtype%3DTSDOWNLOADER%26amp%3Burl%3Dhttp%3A%2F%2F195.154.182.238%3A5477%2Flive%2Ftamer%2Ftamer%2F7975.ts%26amp%3Bname%3DJokers+TV&mode=12)")	
			
	
def tv():
    repoinstall()
    addDir(localizedString(32056).encode('utf-8'),'plugin://plugin.program.senyor.tvshow.light.favourites/',1,'http://i141.photobucket.com/albums/r48/kobiko3030/555_zpsp8bgkspk.png',ART+'tvshows.jpg')	
    if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.senyor.imdb.watchlists')) or os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.thewiz.wall')):	
        addDir2(localizedString(32057).encode('utf-8'),'ספריית סדרות',57,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpskspfxsbn.png',ART+'tvshows.jpg')
    addDir(localizedString(32058).encode('utf-8'),'plugin://plugin.video.specto/?action=tvshows&url=popular',1,'http://i141.photobucket.com/albums/r48/kobiko3030/years_zpstujl7txo.png',ART+'tvshows.jpg')	
    addDir(localizedString(32059).encode('utf-8'),'plugin://plugin.video.zen/?action=tvshows&url=premiere',1,'http://i141.photobucket.com/albums/r48/kobiko3030/years_zpstujl7txo.png',ART+'tvshows.jpg')
    addDir('Exodus','plugin://plugin.video.exodus/?action=tvNavigator',55,ART+'exodus.png',ART+'tvshows.jpg')
    addDir('Specto','plugin://plugin.video.specto/?action=tvNavigator',1,ART+'specto.png',ART+'tvshows.jpg')
    if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.quasar')):
		addDir('Quasar','plugin://plugin.video.quasar/shows/',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpsqjvxvmx8.png',ART+'movies.jpg')	
    if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.salts')):
		addDir('Salts','plugin://plugin.video.salts/?mode=browse&section=TV',1,ART+'salts.png',ART+'tvshows.jpg')
    if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.zen')):
		addDir('Zen','plugin://plugin.video.zen/?action=tvNavigator',1,'http://i141.photobucket.com/albums/r48/kobiko3030/channels_zpspdkpzgf0.png',ART+'tvshows.jpg')
    if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.sdarot.tv')):
		addDir('Sdarot.tv','plugin://plugin.video.sdarot.tv/',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpsw44vuhfx.png',ART+'movies.jpg')	
    if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.movixws')):
		addDir('Movix','plugin://plugin.video.movixws/?description&iconimage=https%3a%2f%2fencrypted-tbn1.gstatic.com%2fimages%3fq%3dtbn%3aANd9GcQ8J4zMJ1vcu5vG5WYoVG2pZRzrCSbdghVXDPf0L08vS1mehbTzcg&mode=2&name=Series%20-%20%d7%a1%d7%93%d7%a8%d7%95%d7%aa&url=http%3a%2f%2fwww.movix.me%2fseries',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpsexeshhm4.png',ART+'movies.jpg')	
    if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.gozlan.me')):
		addDir('Gozlan','plugin://plugin.video.gozlan.me/?mode=5&name=%d7%a1%d7%93%d7%a8%d7%95%d7%aa&url=http%3a%2f%2fanonymouse.org%2fcgi-bin%2fanon-www.cgi%2fhttp%3a%2f%2fgozlan.eu%2fseries.html',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpsnatuvci4.png',ART+'movies.jpg')
		#addDir('Meta','plugin://plugin.video.meta/tv',1,ART+'metas.png',ART+'tvshows.jpg')	
    #addDir2('טלנובלות ודרמות','טלנובלות ודרמות',67,'http://i141.photobucket.com/albums/r48/kobiko3030/unnamed_zpsjnbaycyp.png',ART+'tvshows.jpg')

def soupe():
    #addDir('סדרות אסיאתיות מתורגמות','plugin://plugin.video.asian4HB',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpskh8nten5.png',ART+'tvshows.jpg')
    addDir(localizedString(32180).encode('utf-8'),'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%98%d7%9c%d7%a0%d7%95%d7%91%d7%9c%d7%95%d7%aa%20(31)&url=genre%3dtvshows%26genreId%3d6280',1,'http://i141.photobucket.com/albums/r48/kobiko3030/2148605-54_zpsuufrudqz.jpg',ART+'tvshows.jpg')
    addDir(localizedString(32181).encode('utf-8'),'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%95%d7%99%d7%95%d7%94%20(12)&url=genre%3dtvshows%26genreId%3d7587',1,'http://i141.photobucket.com/albums/r48/kobiko3030/unnamed_zpsjnbaycyp.png',ART+'tvshows.jpg')
    addDir(localizedString(32182).encode('utf-8'),'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%93%d7%a8%d7%9e%d7%94%20(19)&url=genre%3dtvshows%26genreId%3d6254',1,'http://i141.photobucket.com/albums/r48/kobiko3030/200px-Baam_zpshp4l7u4w.png',ART+'tvshows.jpg')
	
def movieslb():
    addDir(localizedString(32060).encode('utf-8'),'videodb://recentlyaddedmovies',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpskspfxsbn.png',ART+'movies.jpg')
    addDir(localizedString(32061).encode('utf-8'),'videodb://movies/titles',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpskspfxsbn.png',ART+'movies.jpg')
    addDir(localizedString(32062).encode('utf-8'),'videodb://movies/years',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpskspfxsbn.png',ART+'movies.jpg')
    addDir(localizedString(32063).encode('utf-8'),'videodb://movies/genres',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpskspfxsbn.png',ART+'movies.jpg')
    #addDir(localizedString(32064).encode('utf-8'),'plugin://plugin.video.thewiz.wall',1,ART+'wiz.png',ART+'movies.jpg')

def tvlb():
    addDir(localizedString(32065).encode('utf-8'),'videodb://tvshows/titles',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpskspfxsbn.png',ART+'tvshows.jpg')
    addDir(localizedString(32066).encode('utf-8'),'videodb://tvshows/years',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpskspfxsbn.png',ART+'tvshows.jpg')
    addDir(localizedString(32067).encode('utf-8'),'videodb://tvshows/genres',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpskspfxsbn.png',ART+'tvshows.jpg')
    addDir(localizedString(32068).encode('utf-8'),'videodb://recentlyaddedepisodes',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpskspfxsbn.png',ART+'tvshows.jpg')
    addDir(localizedString(32069).encode('utf-8'),'plugin://plugin.video.specto/?action=calendar&url=progress',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpstoog4xow.png',ART+'tvshows.jpg')
    addDir(localizedString(32070).encode('utf-8'),'plugin://plugin.video.salts/?mode=show_bookmarks&section=TV',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpstoog4xow.png',ART+'tvshows.jpg')
    addDir(localizedString(32071).encode('utf-8'),'התקדמות סדרות אקסודוס',76,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpstoog4xow.png',ART+'tvshows.jpg')
    #addDir(localizedString(32072).encode('utf-8'),'plugin://plugin.video.thewiz.wall',1,ART+'wiz.png',ART+'tvshows.jpg')

def cooking():
    addDir(localizedString(32073).encode('utf-8'),'plugin://plugin.video.Vodil/?mode=17&name=%d7%90%d7%95%d7%9b%d7%9c%20%d7%95%d7%91%d7%99%d7%a9%d7%95%d7%9c&url=url',1,'http://i141.photobucket.com/albums/r48/kobiko3030/44_zpsessjkkxl.jpg',ART+'tvshows.jpg')
    addDir(localizedString(32074).encode('utf-8'),'plugin://plugin.video.projectm/?fanart=http%3a%2f%2fmwiz.co.uk%2fmerlinaddons%2ffanart%2ffanart.jpg&mode=1&name=%5bCOLOR%20aqua%5d%5bB%5d%20%20%20%20%20Cooking%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fmwiz.co.uk%2fmerlinaddons%2ftextfiles%2fcooking.xml',1,'http://mwiz.co.uk/merlinaddons/icons/cooking.jpg',ART+'tvshows.jpg')
    addDir(localizedString(32075).encode('utf-8'),'plugin://plugin.video.arescookbook',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpsotsxnfgm.png',ART+'tvshows.jpg')
    addDir(localizedString(32076).encode('utf-8'),'plugin://plugin.video.areschefskills/',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zps6a0b4bit.png',ART+'tvshows.jpg')
    addDir(localizedString(32077).encode('utf-8'),'plugin://plugin.video.yt-cook',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zps0z1uduyl.png',ART+'tvshows.jpg')
    addDir(localizedString(32078).encode('utf-8'),'plugin://plugin.video.yt-cook2',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpsx6legmjk.png',ART+'tvshows.jpg')
    addDir(localizedString(32079).encode('utf-8'),'plugin://plugin.video.yt-cook3',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpsyyuqsjk8.png',ART+'tvshows.jpg')
    addDir(localizedString(32080).encode('utf-8'),'plugin://plugin.video.gordon.ura.cz',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpspqnacaho.png',ART+'tvshows.jpg')		

def standup():
    addDir(localizedString(32183).encode('utf-8'),'plugin://plugin.video.youtube/channel/UCVbCUgpl_9DA0iUsS_rkIbQ/playlists/',1,'https://i.ytimg.com/vi/TOx9Lv6FVoo/mqdefault.jpg',ART+'vod.jpg')
    addDir(localizedString(32184).encode('utf-8'),'plugin://plugin.video.youtube/channel/UCHaEhu1lOjCfHSHg_R2dpkg/playlists/',1,'https://i.ytimg.com/vi/PwvrKx8eku4/mqdefault.jpg',ART+'vod.jpg')
    addDir(localizedString(32185).encode('utf-8'),'plugin://plugin.video.youtube/kodion/search/query/?q=%d7%a1%d7%98%d7%a0%d7%93%d7%90%d7%a4%20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99',1,'https://i.ytimg.com/vi/OLvmm807z6Q/hqdefault.jpg',ART+'vod.jpg')
    addDir(localizedString(32186).encode('utf-8'),'plugin://plugin.video.youtube/channel/UC6m6ZW8UBINQPhcEL-g2xCA/',1,'https://yt3.ggpht.com/-MeBhktusxtQ/AAAAAAAAAAI/AAAAAAAAAAA/lXOWlgd5mu0/s240-c-k-no-mo-rj-c0xffffff/photo.jpg',ART+'vod.jpg')
	
def addons():
    addDir(localizedString(32081).encode('utf-8'),'addons://sources/video',1,ART+'movie-icon.png',ART+'video.jpg')
    addDir(localizedString(32082).encode('utf-8'),'addons://sources/executable',1,ART+'Settings-icon.png',ART+'software.jpg')
    addDir(localizedString(32083).encode('utf-8'),'addons://sources/audio',1,ART+'Music-icon.png',ART+'music.jpg')
    #addDir('מאגרי רפו','addons://repos',1,ART+'Movies-icon.png',ART+'addons.jpg')
    addDir(localizedString(32084).encode('utf-8'),'ניהול הרחבות',59,ART+'Movies-icon.png',ART+'addons.jpg')
    addDir(localizedString(32085).encode('utf-8'),'הוספת מקור מכתובת',60,ART+'Movies-icon.png',ART+'filesmanager.jpg')
    addDir(localizedString(32086).encode('utf-8'),'מנהל קבצי וידאו',75,ART+'Movies-icon.png',ART+'filesmanager.jpg')
    addDir(localizedString(32212).encode('utf-8'),'מנהל קבצי אודיו',127,ART+'Music-icon.png',ART+'filesmanager.jpg')
    addDir(localizedString(32087).encode('utf-8'),'plugin://plugin.program.senyortools/?url=url&mode=92',1,ART+'updates.jpg',ART+'filesmanager.jpg')
    addDir2(localizedString(32203).encode('utf-8'),'ניהול הרחבות',121,'http://i141.photobucket.com/albums/r48/kobiko3030/1480521740_sign-up_zpsztvaqr8e.png',ART+'addons.jpg')
    if osAndroid: 
		addDir(localizedString(32213).encode('utf-8'),'androidapp://sources/apps',1,'http://i141.photobucket.com/albums/r48/kobiko3030/android_zpsqnmhdlsr.png',ART+'addons.jpg')

def addonssettings():
    addDir(localizedString(32210).encode('utf-8'),'plugin://plugin.video.exodus/?action=openSettings&query=3.1',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpstoog4xow.png',ART+'video.jpg')
    addDir(localizedString(32211).encode('utf-8'),'plugin://plugin.video.specto/?action=openSettings&query=5.1',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpstoog4xow.png',ART+'video.jpg')
    addDir(localizedString(32209).encode('utf-8'),'plugin://plugin.video.salts/?mode=auth_trakt',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpstoog4xow.png',ART+'video.jpg')
    addDir(localizedString(32208).encode('utf-8'),'מטא',126,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpstoog4xow.png',ART+'video.jpg')
    addDir(localizedString(32205).encode('utf-8'),'סאבסנטר',123,'http://i141.photobucket.com/albums/r48/kobiko3030/22_zps6kehzgb0.png',ART+'video.jpg')
    addDir(localizedString(32206).encode('utf-8'),'כתובית',122,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpsm6d6cobp.png',ART+'video.jpg')
    addDir(localizedString(32204).encode('utf-8'),'כתובית',124,'http://i141.photobucket.com/albums/r48/kobiko3030/33_zpsnhqwa96o.png',ART+'video.jpg') 
    addDir(localizedString(32207).encode('utf-8'),'טורק',125,'http://i141.photobucket.com/albums/r48/kobiko3030/44_zpsbbfhezu7.png',ART+'video.jpg') 	
 
def ktuvitset():
	xbmcaddon.Addon('service.subtitles.subscenter').openSettings()
	
def subceterset():
	xbmcaddon.Addon('service.subtitles.subtitle').openSettings()

def opensubsset():
	xbmcaddon.Addon('service.subtitles.opensubtitles').openSettings()

def torecset():
	xbmcaddon.Addon('service.subtitles.torec').openSettings()

def metaset():
	xbmcaddon.Addon('plugin.video.meta').openSettings()	
	
def system():
    addDir(localizedString(32088).encode('utf-8'),'יציאה מהקודי',69,'http://i141.photobucket.com/albums/r48/kobiko3030/icon4_zpskpycuto6.png',ART+'settings.jpg')
    addDir(localizedString(32089).encode('utf-8'),'הגדרות מערכת',62,ART+'Settings-icon.png',ART+'settings.jpg')
    addDir2(localizedString(32090).encode('utf-8'),'תחזוקה לקודי',81,'http://i141.photobucket.com/albums/r48/kobiko3030/tools_zpsyulrul0r.png',ART+'settings.jpg')
    addDir(localizedString(32091).encode('utf-8'),'plugin://plugin.program.senyortools',1,ART+'tools.png',ART+'settings.jpg')	
    addDir(localizedString(32084).encode('utf-8'),'ניהול הרחבות',59,ART+'Movies-icon.png',ART+'addons.jpg')
    addDir(localizedString(32085).encode('utf-8'),'הוספת מקור מכתובת',60,ART+'Movies-icon.png',ART+'filesmanager.jpg')
    addDir(localizedString(32086).encode('utf-8'),'מנהל קבצי וידאו',75,ART+'Movies-icon.png',ART+'filesmanager.jpg')
    addDir(localizedString(32212).encode('utf-8'),'מנהל קבצי אודיו',127,ART+'Music-icon.png',ART+'filesmanager.jpg')
    addDir2(localizedString(32203).encode('utf-8'),'ניהול הרחבות',121,'http://i141.photobucket.com/albums/r48/kobiko3030/1480521740_sign-up_zpsztvaqr8e.png',ART+'addons.jpg')
	
def maintnence():
    addDir(localizedString(32092).encode('utf-8'),'plugin://plugin.program.echowizard/?description&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.echowizard%5cresources%5cart%5cmaintwall.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.echowizard%5cresources%5cart%5ctools.png&mode=5&name=%5bCOLOR%20ghostwhite%5d%5bB%5dMAINTENANCE%20TOOLS%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2fechocoder.co.uk%2f',1,'http://i141.photobucket.com/albums/r48/kobiko3030/tools_zpsyulrul0r.png',ART+'settings.jpg')
    addDir(localizedString(32093).encode('utf-8'),'plugin://plugin.program.echowizard/?description&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.echowizard%5cfanart.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.echowizard%5cresources%5cart%5cspeed_test.png&mode=16&name=%5bCOLOR%20ghostwhite%5d%5bB%5dSPEED%20TEST%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fechocoder.co.uk%2f',1,'http://i141.photobucket.com/albums/r48/kobiko3030/speed_test_zpss5fuuija.png',ART+'settings.jpg')
	
def livetvs():
    addDir(localizedString(32094).encode('utf-8'),'plugin://plugin.program.senyor.livetv.light.favourites/',1,'http://i141.photobucket.com/albums/r48/kobiko3030/555_zpsp8bgkspk.png',ART+'livetv.jpg')	
    #if (PVR == True):
    addDir(localizedString(32095).encode('utf-8'),'טלוויזיה חיה - Pvr',63,ART+'televiz.png',ART+'livetv.jpg')
    addDir('האח הגדול','האח הגדול',120,'http://i141.photobucket.com/albums/r48/kobiko3030/bigb_zpsaf0wqbnr.png',ART+'livetv.jpg')
    if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.RoiD')):
		addDir('RoiD','plugin://plugin.video.RoiD/',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpshttrwd45.png',ART+'movies.jpg')	
    #addDir(localizedString(32096).encode('utf-8'),'plugin://plugin.video.anarchitv/?iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.anarchitv%5cresources%2ficons%2f%2fallchannels.png&mode=100&name=%5bCOLOR%20white%5d%5bB%5d%d7%a2%d7%a8%d7%95%d7%a6%d7%99%20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%5b%2fB%5d%5b%2fCOLOR%5d&url=%d7%a2%d7%a8%d7%95%d7%a6%d7%99%20%d7%99%d7%a9%d7%a8%d7%90%d7%9c',1,'http://i141.photobucket.com/albums/r48/kobiko3030/israelch_zpstx88s4oo.png',ART+'livetv.jpg')
    addDir(localizedString(32097).encode('utf-8'),'plugin://plugin.video.anarchitv/?iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.anarchitv%5cresources%2ficons%2f%2fallchannels.png&mode=2&name=%5bCOLOR%20green%5d%5bB%5d%d7%a2%d7%a8%d7%95%d7%a6%d7%99%20%d7%91%d7%a1%d7%99%d7%a1%20%7c%20Basic%20Channels%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fwww.youtube.com',1,ART+'televiz.png',ART+'livetv.jpg')
    addDir(localizedString(32098).encode('utf-8'),'plugin://plugin.video.israelive',1,ART+'ilive.png',ART+'livetv.jpg')	
    addDir('Filmon.tv','plugin://plugin.video.filmon.simple/',1,ART+'filmon.jpg',ART+'livetv.jpg')
    addDir('Youtube Live Channels','plugin://plugin.video.ytlive/',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpstf623rch.png',ART+'livetv.jpg')
    addDir(localizedString(32099).encode('utf-8'),'plugin://plugin.video.ukturk/?description&iconimage=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fthumbs%2fnew%2fUk%2520turk%2520thumbnails%2520live%2520tv.jpg&mode=1&name=Live%20TV&url=http%3a%2f%2fukturk.offshorepastebin.com%2fUKTurk%2fLive%2520TV.txt',1,'http://ukturk.offshorepastebin.com/UKTurk/thumbs/new/Uk%20turk%20thumbnails%20live%20tv.jpg',ART+'livetv.jpg')    
    addDir('Oblivion Tv','plugin://plugin.video.sanctuary/?description&extra&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.sanctuary%5cfanart.jpg&iconimage=http%3a%2f%2fherovision.x10host.com%2ffreeview%2foblivion.png&mode=1129&name=Oblivion%20IPTV&url',1,'http://oblivionbuilds.com/Oblivionlogo.png',ART+'livetv.jpg')
    addDir(localizedString(32100).encode('utf-8'),'plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fcrusader88.offshorepastebin.com%2fCrusaderStreams%2fCountries%2fmain2.xml',1,ART+'cruseder.jpg',ART+'livetv.jpg')	
    #addDir('Phoenix Tv','plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fphoenixtv.offshorepastebin.com%2ftv%2fmain.xml',1,ART+'fontv.jpg',ART+'livetv.jpg')
    addDir('Ccloud Tv','plugin://plugin.video.ccloudtv',1,ART+'ccloud.png',ART+'livetv.jpg')
    #addDir('Evolve Golaith Tv','plugin://plugin.video.Evolve/?description&fanart=http%3a%2f%2fwww.matsbuilds.uk%2fpics%2fevolve%2ffanart.jpg&mode=1&name=%5bB%5d%5bCOLOR%20red%5dL%5b%2fCOLOR%5d%5bCOLOR%20white%5dive%5b%2fCOLOR%5d%20%5bCOLOR%20red%5dT%5b%2fCOLOR%5d%5bCOLOR%20white%5dV%5b%2fCOLOR%5d%20%20%20%20%20%20%20%5bCOLOR%20red%5dUpdated%20-%2027%2f08%2f16%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2fwww.matsbuilds.uk%2fGoliathLists%2flivetv1.xml',1,ART+'golyat.jpg',ART+'livetv.jpg')		
    #addDir('ערוצים חיים אוכל ויין','plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fone242415.offshorepastebin.com%2fCollections%2fwine.xml',1,'http://s17.postimg.org/bu9kfqxin/Foodn_Wine.jpg',ART+'livetv.jpg')

def premium():
    addDir('UK: E!','UK: E!',114,'http://i141.photobucket.com/albums/r48/kobiko3030/E_515_355_zpsy8llmtwm.jpg',ART+'livetv.jpg')
    addDir('UK: E! link 2','UK: E!',114,'http://i141.photobucket.com/albums/r48/kobiko3030/E_515_355_zpsy8llmtwm.jpg',ART+'livetv.jpg')
    addDir('Nat Geo Wild','Nat Geo Wild',116,'http://i141.photobucket.com/albums/r48/kobiko3030/photo_zpsaov7edqa.jpg',ART+'livetv.jpg')
    addDir(localizedString(32101).encode('utf-8'),'ערוץ הטיולים',117,'http://i141.photobucket.com/albums/r48/kobiko3030/travel-channel_web-logo.rend.tccom.616.462_zpsk5ihvv7k.jpeg',ART+'livetv.jpg')
    #addDir('DISCOVERY TURBO','DISCOVERY TURBO',118,'http://i141.photobucket.com/albums/r48/kobiko3030/11223_zpsn6ltgbtb.png',ART+'livetv.jpg')
    #addDir('Discovery Science','Discovery Science',119,'http://i141.photobucket.com/albums/r48/kobiko3030/5566_zpsasdrgk23.jpg',ART+'livetv.jpg')
    #addDir('Discovery History','Discovery History',120,'http://i141.photobucket.com/albums/r48/kobiko3030/DISCHIST-2010-ID-CATHEDRAL-1-4_zpspcv7euv9.jpg',ART+'livetv.jpg')
    #addDir('Ccloud Tv','plugin://plugin.video.ccloudtv',1,ART+'ccloud.png',ART+'livetv.jpg')	

def premiuma():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.ukturk/?url=http%3A%2F%2F46.166.162.35%3A9090%2Fload%2Fb0922f3fa8aa%2F6.m3u8&mode=3&name=E+U.S&iconimage=http%3A%2F%2Fwww.brandsoftheworld.com%2Fsites%2Fdefault%2Ffiles%2Fstyles%2Flogo-thumbnail%2Fpublic%2F0000%2F9012%2Fbrand.gif%3Fitok%3DyDnAOYWD&description=BL)")	

def netgeow():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.ukturk/?url=http%3A%2F%2Fukturk.offshorepastebin.com%2FUKTurk%2FLive%2520TV.txt&mode=5&name=Nat+Geo+Wild+US&iconimage=http%3A%2F%2Fmetalkettle.co%2Flogos%2Flogos2%2FDSAT%2FGlossy%2FTV%2FNat%2520Geo%2520Wild.png&description=BL)")	

def nationag():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.Evolve/?url=http%3A%2F%2Fwww.filmon.com%2Ftv%2Ftravel-channel1&mode=2&name=%5BCOLOR+white%5DTravel+Channel+%2B1%5B%2FCOLOR%5D&description=&fanart=http%3A%2F%2Fi.imgur.com%2F2JsFYHJ.png)")	

def dturbo():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.TheJoker/?url=plugin%3A%2F%2Fplugin.video.f4mTester%2F%3Fstreamtype%3DTSDOWNLOADER%26amp%3Burl%3Dhttp%3A%2F%2Fju031.jupiter.fastwebserver.de%3A8000%2Flive%2Fkris%2Fkris%2F8361.ts%26amp%3Bname%3DJokers+TV&mode=12)")	

def dScience():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.TheJoker/?url=plugin%3A%2F%2Fplugin.video.f4mTester%2F%3Fstreamtype%3DTSDOWNLOADER%26amp%3Burl%3Dhttp%3A%2F%2Fju031.jupiter.fastwebserver.de%3A8000%2Flive%2Fkris%2Fkris%2F8359.ts%26amp%3Bname%3DJokers+TV&mode=12)")	

def bigb():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.israelive/?categoryid=10065&iconimage=http%3A%2F%2Fupload.wikimedia.org%2Fwikipedia%2Fhe%2Fthumb%2F4%2F44%2FBigBrotherIsrael.jpg%2F250px-BigBrotherIsrael.jpg&mode=10&channelid=11597)")	
		
	
def israeltv():
    addDir2(localizedString(32187).encode('utf-8'),'ערוץ 2',93,'http://televiz.net/static/img/logos/c22.png',ART+'livetv.jpg')	
    addDir2(localizedString(32188).encode('utf-8'),'ערוץ 10',94,'http://televiz.net/static/img/logos/c10.png',ART+'livetv.jpg')
    addDir2(localizedString(32189).encode('utf-8'),'ערוץ 1',84,'http://televiz.net/static/img/logos/c11.png',ART+'livetv.jpg')	

def chone():
    addDir(localizedString(32190).encode('utf-8'),'הערוץ הראשון ישראלייב',85,'http://televiz.net/static/img/logos/c11.png',ART+'livetv.jpg')
    addDir(localizedString(32191).encode('utf-8'),'הערוץ הראשון ישראלייב',87,'http://televiz.net/static/img/logos/c11.png',ART+'livetv.jpg')
    addDir(localizedString(32192).encode('utf-8'),'ערוץ 1 Televiz',86,'http://televiz.net/static/img/logos/c11.png',ART+'livetv.jpg')	
    #addDir('ערוץ 1 bbts','ערוץ 1 bbts',88,'http://televiz.net/static/img/logos/c11.png',ART+'livetv.jpg')
 
def chonea():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.israelive/?url=channel-511M%3Fmode%3D33&mode=10&name=%5BCOLOR+yellow%5D%5BB%5D%D7%94%D7%A2%D7%A8%D7%95%D7%A5+%D7%94%D7%A8%D7%90%D7%A9%D7%95%D7%9F%5B%2FB%5D%5B%2FCOLOR%5D+-+%5BCOLOR+orange%5D%5BB%5D%D7%9B%D7%95%D7%A9%D7%A8+%D7%98%D7%95%D7%91+%D7%99%D7%A9%D7%A8%D7%90%D7%9C%5B%2FB%5D%5B%2FCOLOR%5D+%5BCOLOR+burlywood%5D%5B08%3A02-08%3A15%5D%5B%2FCOLOR%5D+-+%5BCOLOR+white%5DNext%3A+%5BB%5D%D7%93%D7%95%D7%90%D7%98+%D7%99%D7%A9%D7%A8%D7%90%D7%9C%D7%99+-+%D7%A9%D7%9C%D7%9E%D7%94+%D7%92%D7%A8%D7%95%D7%A0%D7%99%D7%9A+%D7%95%D7%A9%D7%9C%D7%95%D7%9D+%D7%9E%D7%95%D7%A8%28%D7%A9.%D7%97%29%5B%2FB%5D%5B%2FCOLOR%5D+%5BCOLOR+burlywood%5D%5B08%3A15-08%3A40%5D%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fimg.mako.co.il%2F2008%2F05%2F01%2F01%2Ffirst_channel_logo_b.jpg&description=%D7%AA%D7%9B%D7%A0%D7%99%D7%AA+%D7%9B%D7%95%D7%A9%D7%A8+%D7%99%D7%95%D7%9E%D7%99%D7%AA+%D7%94%D7%9E%D7%A2%D7%91%D7%99%D7%A8%D7%94+%D7%A9%D7%99%D7%A2%D7%95%D7%A8+%D7%94%D7%AA%D7%A2%D7%9E%D7%9C%D7%95%D7%AA+%D7%A2%D7%9D+%D7%93%D7%92%D7%A9%D7%99%D7%9D+%D7%A2%D7%9C+%D7%99%D7%99%D7%A9%D7%95%D7%9E%D7%99%D7%9D+%D7%90%D7%A4%D7%A9%D7%A8%D7%99%D7%99%D7%9D+%D7%91%D7%97%D7%99%D7%99+%D7%94%D7%99%D7%95%D7%9D+%D7%99%D7%95%D7%9D.+%D7%9B%27+%D7%A2%D7%91%2F%D7%A2%D7%A8.&displayname=%D7%94%D7%A2%D7%A8%D7%95%D7%A5+%D7%94%D7%A8%D7%90%D7%A9%D7%95%D7%9F&categoryid=10065)")	
	
def choneb():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.anarchitv/?url=rtmp%3A%2F%2Fiba-s.vidnt.com%2Fiba_channel-511MRepeat%2Fchannel-511M_4.stream&mode=1&name=%D7%94%D7%A2%D7%A8%D7%95%D7%A5+%D7%94%D7%A8%D7%90%D7%A9%D7%95%D7%9F&iconimage=http%3A%2F%2Fteleviz.net%2Fstatic%2Fimg%2Flogos%2Fc11.png)")	

def chonec():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.israelive/?url=channel-511B%3Fmode%3D33&mode=10&name=%5BCOLOR+yellow%5D%5BB%5D%D7%94%D7%A2%D7%A8%D7%95%D7%A5+%D7%94%D7%A8%D7%90%D7%A9%D7%95%D7%9F%5B%2FB%5D%5B%2FCOLOR%5D+-+%5BCOLOR+orange%5D%5BB%5D%D7%9B%D7%95%D7%A9%D7%A8+%D7%98%D7%95%D7%91+%D7%99%D7%A9%D7%A8%D7%90%D7%9C%5B%2FB%5D%5B%2FCOLOR%5D+%5BCOLOR+burlywood%5D%5B08%3A02-08%3A15%5D%5B%2FCOLOR%5D+-+%5BCOLOR+white%5DNext%3A+%5BB%5D%D7%93%D7%95%D7%90%D7%98+%D7%99%D7%A9%D7%A8%D7%90%D7%9C%D7%99+-+%D7%A9%D7%9C%D7%9E%D7%94+%D7%92%D7%A8%D7%95%D7%A0%D7%99%D7%9A+%D7%95%D7%A9%D7%9C%D7%95%D7%9D+%D7%9E%D7%95%D7%A8%28%D7%A9.%D7%97%29%5B%2FB%5D%5B%2FCOLOR%5D+%5BCOLOR+burlywood%5D%5B08%3A15-08%3A40%5D%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fimg.mako.co.il%2F2008%2F05%2F01%2F01%2Ffirst_channel_logo_b.jpg&description=%D7%AA%D7%9B%D7%A0%D7%99%D7%AA+%D7%9B%D7%95%D7%A9%D7%A8+%D7%99%D7%95%D7%9E%D7%99%D7%AA+%D7%94%D7%9E%D7%A2%D7%91%D7%99%D7%A8%D7%94+%D7%A9%D7%99%D7%A2%D7%95%D7%A8+%D7%94%D7%AA%D7%A2%D7%9E%D7%9C%D7%95%D7%AA+%D7%A2%D7%9D+%D7%93%D7%92%D7%A9%D7%99%D7%9D+%D7%A2%D7%9C+%D7%99%D7%99%D7%A9%D7%95%D7%9E%D7%99%D7%9D+%D7%90%D7%A4%D7%A9%D7%A8%D7%99%D7%99%D7%9D+%D7%91%D7%97%D7%99%D7%99+%D7%94%D7%99%D7%95%D7%9D+%D7%99%D7%95%D7%9D.+%D7%9B%27+%D7%A2%D7%91%2F%D7%A2%D7%A8.&displayname=%D7%94%D7%A2%D7%A8%D7%95%D7%A5+%D7%94%D7%A8%D7%90%D7%A9%D7%95%D7%9F&categoryid=10065)")	
	
def choned():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.anarchitv/?url=rtmp%3A%2F%2Fiba-s.vidnt.com%2Fiba_channel-511MRepeat%2Fchannel-511M_4.stream&mode=1&name=%D7%94%D7%A2%D7%A8%D7%95%D7%A5+%D7%94%D7%A8%D7%90%D7%A9%D7%95%D7%9F&iconimage=http%3A%2F%2Fteleviz.net%2Fstatic%2Fimg%2Flogos%2Fc11.png)")			
 
def chtow():
    addDir(localizedString(32193).encode('utf-8'),'ערוץ 2 כל השבוע Televiz',89,'http://televiz.net/static/img/logos/c22.png',ART+'livetv.jpg')
    addDir(localizedString(32194).encode('utf-8'),'ערוץ 2 רשת ראשון-רביעי Israelive',90,'http://televiz.net/static/img/logos/c22.png',ART+'livetv.jpg')
    addDir(localizedString(32194).encode('utf-8'),'ערוץ 2 רשת ראשון-רביעי Israelive',91,'http://televiz.net/static/img/logos/c22.png',ART+'livetv.jpg')	
    addDir(localizedString(32195).encode('utf-8'),'ערוץ 2 קשת רביעי-שבת Israelive',92,'http://televiz.net/static/img/logos/c22.png',ART+'livetv.jpg')
    addDir(localizedString(32196).encode('utf-8'),'ערוץ 2 bbts',100,'http://televiz.net/static/img/logos/c22.png',ART+'livetv.jpg')
    addDir(localizedString(32197).encode('utf-8'),'ערוץ 2 כל השבוע Televiz',101,'http://televiz.net/static/img/logos/c22.png',ART+'livetv.jpg')  
 
def chtowa():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.anarchitv/?url=http%3A%2F%2Fbesttv1.httplive.it.best-tv.com%2Fbesttv1%2Fstream_reshet_neveilan_02_1%2Fplaylist.m3u8&mode=1&name=%D7%A2%D7%A8%D7%95%D7%A5+22&iconimage=http%3A%2F%2Fteleviz.net%2Fstatic%2Fimg%2Flogos%2Fc22.png)")	
	
def chtowb():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.israelive/?url=http%3A%2F%2Freshet207788-i.akamaihd.net%2Fhls%2Flive%2F207509%2Flive%2Fencoder_index.m3u8&mode=10&name=%5BCOLOR+yellow%5D%5BB%5D%D7%A2%D7%A8%D7%95%D7%A5+2+%D7%A8%D7%A9%D7%AA+%D7%9E%D7%A8%D7%90%D7%A9%D7%95%D7%9F+%D7%A2%D7%93+%D7%A9%D7%9C%D7%99%D7%A9%D7%99%5B%2FB%5D%5B%2FCOLOR%5D+-+%5BCOLOR+orange%5D%5BB%5D%D7%99%D7%A9%D7%99%D7%A8%21+%D7%9E%D7%94%D7%93%D7%95%D7%A8%D7%94+%D7%A8%D7%90%D7%A9%D7%95%D7%A0%D7%94%5B%2FB%5D%5B%2FCOLOR%5D+%5BCOLOR+burlywood%5D%5B16%3A45-17%3A30%5D%5B%2FCOLOR%5D+-+%5BCOLOR+white%5DNext%3A+%5BB%5D%D7%A2%D7%95%D7%A9%D7%99%D7%9D+%D7%A1%D7%93%D7%A8%5B%2FB%5D%5B%2FCOLOR%5D+%5BCOLOR+burlywood%5D%5B17%3A30-18%3A00%5D%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fwww.themarker.com%2Fpolopoly_fs%2F1.593973.1297938795%21%2Fimage%2F4142077372.jpg_gen%2Fderivatives%2Flandscape_468%2F4142077372.jpg&description=%D7%9E%D7%94%D7%93%D7%95%D7%A8%D7%AA+%D7%94%D7%97%D7%93%D7%A9%D7%95%D7%AA+%D7%94%D7%A8%D7%90%D7%A9%D7%95%D7%A0%D7%94+%D7%A9%D7%9C+%D7%94%D7%99%D7%95%D7%9D%2C+%D7%94%D7%A2%D7%95%D7%A1%D7%A7%D7%AA+%D7%91%D7%97%D7%93%D7%A9%D7%95%D7%AA+%D7%94%D7%99%D7%95%D7%9D+%D7%91%D7%99%D7%A9%D7%A8%D7%90%D7%9C+%D7%95%D7%91%D7%A2%D7%95%D7%9C%D7%9D%2C+%D7%91%D7%94%D7%92%D7%A9%D7%AA+%D7%90%D7%95%D7%A8%D7%9F+%D7%95%D7%99%D7%99%D7%92%D7%A0%D7%A4%D7%9C%D7%93.+%D7%9B%27+%D7%A1%D7%9E%D7%95%D7%99%D7%95%D7%AA.&displayname=%D7%A2%D7%A8%D7%95%D7%A5+2+%D7%A8%D7%A9%D7%AA+%D7%9E%D7%A8%D7%90%D7%A9%D7%95%D7%9F+%D7%A2%D7%93+%D7%A9%D7%9C%D7%99%D7%A9%D7%99&categoryid=10065)")	

def chtowc():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.israelive/?url=http%3A%2F%2Fbesttv1.httplive.it.best-tv.com%2Fbesttv1%2Fstream_reshet_neveilan_02_2%2Fplaylist.m3u8&mode=10&name=%5BCOLOR+yellow%5D%5BB%5D%D7%A2%D7%A8%D7%95%D7%A5+2+%D7%A8%D7%A9%D7%AA+%D7%9E%D7%A8%D7%90%D7%A9%D7%95%D7%9F+%D7%A2%D7%93+%D7%A9%D7%9C%D7%99%D7%A9%D7%99%5B%2FB%5D%5B%2FCOLOR%5D+-+%5BCOLOR+orange%5D%5BB%5D%D7%99%D7%A9%D7%99%D7%A8%21+%D7%9E%D7%94%D7%93%D7%95%D7%A8%D7%94+%D7%A8%D7%90%D7%A9%D7%95%D7%A0%D7%94%5B%2FB%5D%5B%2FCOLOR%5D+%5BCOLOR+burlywood%5D%5B16%3A45-17%3A30%5D%5B%2FCOLOR%5D+-+%5BCOLOR+white%5DNext%3A+%5BB%5D%D7%A2%D7%95%D7%A9%D7%99%D7%9D+%D7%A1%D7%93%D7%A8%5B%2FB%5D%5B%2FCOLOR%5D+%5BCOLOR+burlywood%5D%5B17%3A30-18%3A00%5D%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fwww.themarker.com%2Fpolopoly_fs%2F1.593973.1297938795%21%2Fimage%2F4142077372.jpg_gen%2Fderivatives%2Flandscape_468%2F4142077372.jpg&description=%D7%9E%D7%94%D7%93%D7%95%D7%A8%D7%AA+%D7%94%D7%97%D7%93%D7%A9%D7%95%D7%AA+%D7%94%D7%A8%D7%90%D7%A9%D7%95%D7%A0%D7%94+%D7%A9%D7%9C+%D7%94%D7%99%D7%95%D7%9D%2C+%D7%94%D7%A2%D7%95%D7%A1%D7%A7%D7%AA+%D7%91%D7%97%D7%93%D7%A9%D7%95%D7%AA+%D7%94%D7%99%D7%95%D7%9D+%D7%91%D7%99%D7%A9%D7%A8%D7%90%D7%9C+%D7%95%D7%91%D7%A2%D7%95%D7%9C%D7%9D%2C+%D7%91%D7%94%D7%92%D7%A9%D7%AA+%D7%90%D7%95%D7%A8%D7%9F+%D7%95%D7%99%D7%99%D7%92%D7%A0%D7%A4%D7%9C%D7%93.+%D7%9B%27+%D7%A1%D7%9E%D7%95%D7%99%D7%95%D7%AA.&displayname=%D7%A2%D7%A8%D7%95%D7%A5+2+%D7%A8%D7%A9%D7%AA+%D7%9E%D7%A8%D7%90%D7%A9%D7%95%D7%9F+%D7%A2%D7%93+%D7%A9%D7%9C%D7%99%D7%A9%D7%99&categoryid=10065)")	
	
def chtowd():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.israelive/?url=6540b8dcb64fd31006%3Fmode%3D2&mode=10&name=%5BCOLOR+yellow%5D%5BB%5D%D7%A2%D7%A8%D7%95%D7%A5+2+%D7%A7%D7%A9%D7%AA+%D7%9E%D7%A8%D7%91%D7%99%D7%A2%D7%99+%D7%A2%D7%93+%D7%A9%D7%91%D7%AA%5B%2FB%5D%5B%2FCOLOR%5D+-+%5BCOLOR+orange%5D%5BB%5D%D7%99%D7%A9%D7%99%D7%A8%21+%D7%9E%D7%94%D7%93%D7%95%D7%A8%D7%94+%D7%A8%D7%90%D7%A9%D7%95%D7%A0%D7%94%5B%2FB%5D%5B%2FCOLOR%5D+%5BCOLOR+burlywood%5D%5B16%3A45-17%3A30%5D%5B%2FCOLOR%5D+-+%5BCOLOR+white%5DNext%3A+%5BB%5D%D7%A2%D7%95%D7%A9%D7%99%D7%9D+%D7%A1%D7%93%D7%A8%5B%2FB%5D%5B%2FCOLOR%5D+%5BCOLOR+burlywood%5D%5B17%3A30-18%3A00%5D%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fwww.themarker.com%2Fpolopoly_fs%2F1.593973.1297938795%21%2Fimage%2F4142077372.jpg_gen%2Fderivatives%2Flandscape_468%2F4142077372.jpg&description=%D7%9E%D7%94%D7%93%D7%95%D7%A8%D7%AA+%D7%94%D7%97%D7%93%D7%A9%D7%95%D7%AA+%D7%94%D7%A8%D7%90%D7%A9%D7%95%D7%A0%D7%94+%D7%A9%D7%9C+%D7%94%D7%99%D7%95%D7%9D%2C+%D7%94%D7%A2%D7%95%D7%A1%D7%A7%D7%AA+%D7%91%D7%97%D7%93%D7%A9%D7%95%D7%AA+%D7%94%D7%99%D7%95%D7%9D+%D7%91%D7%99%D7%A9%D7%A8%D7%90%D7%9C+%D7%95%D7%91%D7%A2%D7%95%D7%9C%D7%9D%2C+%D7%91%D7%94%D7%92%D7%A9%D7%AA+%D7%90%D7%95%D7%A8%D7%9F+%D7%95%D7%99%D7%99%D7%92%D7%A0%D7%A4%D7%9C%D7%93.+%D7%9B%27+%D7%A1%D7%9E%D7%95%D7%99%D7%95%D7%AA.&displayname=%D7%A2%D7%A8%D7%95%D7%A5+2+%D7%A7%D7%A9%D7%AA+%D7%9E%D7%A8%D7%91%D7%99%D7%A2%D7%99+%D7%A2%D7%93+%D7%A9%D7%91%D7%AA&categoryid=10065)")	

def chtowe():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.ccloudtv/?url=http%3A%2F%2Freshet207788-i.akamaihd.net%2Fhls%2Flive%2F207509%2Flive%2Fencoder_index.m3u8&mode=1&name=Israeli+Ch+2+Reshet+%28Documentary%29+%28IL%29+%28Israeli%29&iconimage=https%3A%2F%2Fupload.wikimedia.org%2Fwikipedia%2Fcommons%2Fa%2Fa2%2FChannel_10_logo.jpg)")	

def chtowf():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.anarchitv/?url=http%3A%2F%2Freshet207788-i.akamaihd.net%2Fhls%2Flive%2F207509%2Flive%2Fencoder_index.m3u8&mode=1&name=%D7%A2%D7%A8%D7%95%D7%A5+22+%D7%A8%D7%A9%D7%AA&iconimage=http%3A%2F%2Fteleviz.net%2Fstatic%2Fimg%2Flogos%2Fc611.png)")	
		
	
def chten():
    addDir(localizedString(32198).encode('utf-8'),'ערוץ 10 Televiz',95,'http://televiz.net/static/img/logos/c10.png',ART+'livetv.jpg')
    addDir(localizedString(32199).encode('utf-8'),'ערוץ 10 Israelive',96,'http://televiz.net/static/img/logos/c10.png',ART+'livetv.jpg')
    addDir(localizedString(32199).encode('utf-8'),'ערוץ 10 Israelive',97,'http://televiz.net/static/img/logos/c10.png',ART+'livetv.jpg')	
    #addDir('ערוץ 10 bbts','ערוץ 10 bbts',98,'http://televiz.net/static/img/logos/c10.png',ART+'livetv.jpg')
    addDir(localizedString(32200).encode('utf-8'),'ערוץ 10 Ccloud',99,'http://televiz.net/static/img/logos/c10.png',ART+'livetv.jpg')
  
 
def chtena():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.anarchitv/?url=http%3A%2F%2Fnana10-hdl-il-sw.ctedgecdn.net%2FNana10-Live%2Famlst%3Ahd_%2C1000%2C1500%2C1800%2C%2Fchunklist.m3u8&mode=1&name=%D7%A2%D7%A8%D7%95%D7%A5+10+%D7%99%D7%A9%D7%A8%D7%90%D7%9C&iconimage=http%3A%2F%2Fteleviz.net%2Fstatic%2Fimg%2Flogos%2Fc10.png)")	
	
def chtenb():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.israelive/?url=http%3A%2F%2Fnana10-hdl-il-sw.ctedgecdn.net%2FNana10-Live%2Famlst%3Ahd_%2C1000%2C1500%2C1800%2C%2Fchunklist.m3u8&mode=10&name=%5BCOLOR+yellow%5D%5BB%5D%D7%A2%D7%A8%D7%95%D7%A5+10%5B%2FB%5D%5B%2FCOLOR%5D+-+%5BCOLOR+orange%5D%5BB%5D%D7%99%D7%A9%D7%99%D7%A8%21+%D7%92%D7%99%D7%90+%D7%A4%D7%99%D7%A0%D7%A1+-+1428%5B%2FB%5D%5B%2FCOLOR%5D+%5BCOLOR+burlywood%5D%5B19%3A07-19%3A57%5D%5B%2FCOLOR%5D+-+%5BCOLOR+white%5DNext%3A+%5BB%5D%D7%99%D7%A9%D7%99%D7%A8%21+%D7%97%D7%93%D7%A9%D7%95%D7%AA+10+-+%D7%A2%D7%9D+%D7%AA%D7%9E%D7%A8+%D7%90%D7%99%D7%A9-%D7%A9%D7%9C%D7%95%D7%9D%5B%2FB%5D%5B%2FCOLOR%5D+%5BCOLOR+burlywood%5D%5B19%3A57-21%3A00%5D%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fupload.wikimedia.org%2Fwikipedia%2Fhe%2Farchive%2F4%2F48%2F20120408220922%21Channel_10_logo.png&description=%D7%9E%D7%92%D7%96%D7%99%D7%9F+%D7%97%D7%93%D7%A9%D7%95%D7%AA+%D7%94%D7%91%D7%99%D7%93%D7%95%D7%A8+%D7%94%D7%9E%D7%95%D7%91%D7%99%D7%9C+%D7%91%D7%99%D7%A9%D7%A8%D7%90%D7%9C+%D7%9E%D7%91%D7%99%D7%90+%D7%9C%D7%9B%D7%9D+%D7%91%D7%9B%D7%9C+%D7%A2%D7%A8%D7%91+%D7%90%D7%AA+%D7%94%D7%A1%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D+%D7%94%D7%9B%D7%99+%D7%97%D7%9E%D7%99%D7%9D+%D7%95%D7%94%D7%A9%D7%A2%D7%A8%D7%95%D7%A8%D7%99%D7%95%D7%AA+%D7%94%D7%9B%D7%99+%D7%9E%D7%A8%D7%AA%D7%A7%D7%95%D7%AA+%D7%A9%D7%9C+%D7%A2%D7%95%D7%9C%D7%9D+%D7%94%D7%96%D7%95%D7%94%D7%A8.+%D7%91%D7%9B%D7%9C+%D7%99%D7%95%D7%9D%2C+%D7%92%D7%99%D7%90+%D7%A4%D7%99%D7%A0%D7%A1+%D7%95%D7%A6%D7%95%D7%95%D7%AA+%D7%94%D7%9B%D7%AA%D7%91%D7%99%D7%9D+%D7%9E%D7%A2%D7%93%D7%9B%D7%A0%D7%99%D7%9D+%D7%90%D7%AA%D7%9B%D7%9D+%D7%91%D7%97%D7%93%D7%A9%D7%95%D7%AA+%D7%94%D7%97%D7%A9%D7%95%D7%91%D7%95%D7%AA+%D7%91%D7%90%D7%9E%D7%AA.+%D7%9B%27+%D7%A1%D7%9E%D7%95%D7%99%D7%95%D7%AA.&displayname=%D7%A2%D7%A8%D7%95%D7%A5+10&categoryid=10065)")	

def chtenc():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.israelive/?url=http%3A%2F%2Fnana10-hdl-il.ctedgecdn.net%2FNana10-Live%2Famlst%3Ahd_%2C1000%2C1500%2C1800%2C%2Fplaylist.m3u8&mode=10&name=%5BCOLOR+yellow%5D%5BB%5D%D7%A2%D7%A8%D7%95%D7%A5+10%5B%2FB%5D%5B%2FCOLOR%5D+-+%5BCOLOR+orange%5D%5BB%5D%D7%99%D7%A9%D7%99%D7%A8%21+%D7%92%D7%99%D7%90+%D7%A4%D7%99%D7%A0%D7%A1+-+1428%5B%2FB%5D%5B%2FCOLOR%5D+%5BCOLOR+burlywood%5D%5B19%3A07-19%3A57%5D%5B%2FCOLOR%5D+-+%5BCOLOR+white%5DNext%3A+%5BB%5D%D7%99%D7%A9%D7%99%D7%A8%21+%D7%97%D7%93%D7%A9%D7%95%D7%AA+10+-+%D7%A2%D7%9D+%D7%AA%D7%9E%D7%A8+%D7%90%D7%99%D7%A9-%D7%A9%D7%9C%D7%95%D7%9D%5B%2FB%5D%5B%2FCOLOR%5D+%5BCOLOR+burlywood%5D%5B19%3A57-21%3A00%5D%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fupload.wikimedia.org%2Fwikipedia%2Fhe%2Farchive%2F4%2F48%2F20120408220922%21Channel_10_logo.png&description=%D7%9E%D7%92%D7%96%D7%99%D7%9F+%D7%97%D7%93%D7%A9%D7%95%D7%AA+%D7%94%D7%91%D7%99%D7%93%D7%95%D7%A8+%D7%94%D7%9E%D7%95%D7%91%D7%99%D7%9C+%D7%91%D7%99%D7%A9%D7%A8%D7%90%D7%9C+%D7%9E%D7%91%D7%99%D7%90+%D7%9C%D7%9B%D7%9D+%D7%91%D7%9B%D7%9C+%D7%A2%D7%A8%D7%91+%D7%90%D7%AA+%D7%94%D7%A1%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D+%D7%94%D7%9B%D7%99+%D7%97%D7%9E%D7%99%D7%9D+%D7%95%D7%94%D7%A9%D7%A2%D7%A8%D7%95%D7%A8%D7%99%D7%95%D7%AA+%D7%94%D7%9B%D7%99+%D7%9E%D7%A8%D7%AA%D7%A7%D7%95%D7%AA+%D7%A9%D7%9C+%D7%A2%D7%95%D7%9C%D7%9D+%D7%94%D7%96%D7%95%D7%94%D7%A8.+%D7%91%D7%9B%D7%9C+%D7%99%D7%95%D7%9D%2C+%D7%92%D7%99%D7%90+%D7%A4%D7%99%D7%A0%D7%A1+%D7%95%D7%A6%D7%95%D7%95%D7%AA+%D7%94%D7%9B%D7%AA%D7%91%D7%99%D7%9D+%D7%9E%D7%A2%D7%93%D7%9B%D7%A0%D7%99%D7%9D+%D7%90%D7%AA%D7%9B%D7%9D+%D7%91%D7%97%D7%93%D7%A9%D7%95%D7%AA+%D7%94%D7%97%D7%A9%D7%95%D7%91%D7%95%D7%AA+%D7%91%D7%90%D7%9E%D7%AA.+%D7%9B%27+%D7%A1%D7%9E%D7%95%D7%99%D7%95%D7%AA.&displayname=%D7%A2%D7%A8%D7%95%D7%A5+10&categoryid=10065)")	
	
def chtend():
    xbmc.executebuiltin("PlayMedia(http://nana10-hdl.ctedgecdn.net/Nana10-Live/amlst:hd_,1000,1500,1800,/playlist.m3u8#?b?b*t)")	

def chtene():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.ccloudtv/?url=http%3A%2F%2Fnana10-hdl.ctedgecdn.net%2FNana10-Live%2Famlst%3Ahd_%252C1000%252C1500%252C1800%252C%2Fplaylist.m3u8&mode=1&name=Israeli+Ch+10+%28Documentary%29+%28IL%29+%28Israeli%29&iconimage=https%3A%2F%2Fupload.wikimedia.org%2Fwikipedia%2Fcommons%2Fa%2Fa2%2FChannel_10_logo.jpg)")	
		 	
 
def docu():
    addDir2(localizedString(32102).encode('utf-8'),'הרחבות דוקומנטריה',77,ART+'Documentary-icon.png',ART+'sciencenature.jpg')
    addDir2(localizedString(32103).encode('utf-8'),'דוקו מדע וטבע בעברית',78,ART+'Documentary-icon.png',ART+'sciencenature.jpg')
    addDir2(localizedString(32104).encode('utf-8'),'ערוצי טלוויזיה חיים דוקו',79,ART+'Documentary-icon.png',ART+'sciencenature.jpg')
    addDir2(localizedString(32105).encode('utf-8'),'חיות וטבע',80,ART+'Documentary-icon.png',ART+'sciencenature.jpg')
    addDir(localizedString(32106).encode('utf-8'),'plugin://plugin.video.DecadoDocs/?description&mode=1&name=Conspiracy&url=http%3a%2f%2ftopdocumentaryfilms.com%2fcategory%2fcrime-conspiracy%2f',1,ART+'Documentary-icon.png',ART+'sciencenature.jpg')
    addDir(localizedString(32107).encode('utf-8'),'plugin://plugin.video.DecadoDocs/?description&mode=1&name=History&url=http%3a%2f%2ftopdocumentaryfilms.com%2fcategory%2fhistory%2f',1,ART+'Documentary-icon.png',ART+'sciencenature.jpg')
    addDir(localizedString(32108).encode('utf-8'),'plugin://plugin.video.DecadoDocs/?description&mode=1&name=Science&url=http%3a%2f%2ftopdocumentaryfilms.com%2fcategory%2fscience-technology%2f',1,ART+'Documentary-icon.png',ART+'sciencenature.jpg')	
    addDir(localizedString(32109).encode('utf-8'),'plugin://plugin.video.youtube/playlist/PL152bjytsMC6bL6e5QJHXCdL1VDtI2Boc/',1,ART+'Documentary-icon.png',ART+'sciencenature.jpg')
    addDir(localizedString(32110).encode('utf-8'),'plugin://plugin.video.youtube/channel/UCgLTuWANjVycg1qYHYPxmnA/',1,ART+'Documentary-icon.png',ART+'sciencenature.jpg')
    addDir(localizedString(32111).encode('utf-8'),'plugin://plugin.video.youtube/playlist/PL152bjytsMC5DJj7z8WHQn5gDPmOt9P5F/',1,ART+'Documentary-icon.png',ART+'sciencenature.jpg')
    addDir(localizedString(32112).encode('utf-8'),'plugin://plugin.video.youtube/playlist/PL152bjytsMC6yQ1XXF1ia2B0YttPeKtfN/',1,ART+'Documentary-icon.png',ART+'sciencenature.jpg')	
    addDir(localizedString(32113).encode('utf-8'),'plugin://plugin.video.youtube/playlist/PL152bjytsMC7T0Q7xHWHHiP5Y7dJLRWiG/',1,ART+'Documentary-icon.png',ART+'sciencenature.jpg')
    addDir(localizedString(32114).encode('utf-8'),'plugin://plugin.video.youtube/playlist/PL152bjytsMC4A4OmwlIfUdeD8sqoEU4gN/',1,ART+'Documentary-icon.png',ART+'sciencenature.jpg')
    addDir(localizedString(32115).encode('utf-8'),'plugin://plugin.video.youtube/playlist/PL152bjytsMC43QlLMf4YNK7rNP4CByIms/',1,ART+'Documentary-icon.png',ART+'sciencenature.jpg')
    addDir(localizedString(32116).encode('utf-8'),'plugin://plugin.video.youtube/playlist/PL152bjytsMC70yAAW7ryCt0o63EQ71Vjg/',1,ART+'Documentary-icon.png',ART+'sciencenature.jpg')	
    addDir(localizedString(32117).encode('utf-8'),'plugin://plugin.video.youtube/playlist/PL152bjytsMC6GTxge816-PC_H5Ai9rYhD/',1,ART+'Documentary-icon.png',ART+'sciencenature.jpg')
    addDir(localizedString(32118).encode('utf-8'),'plugin://plugin.video.AresMafia/',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon_zpsirkl5ugb.png',ART+'sciencenature.jpg')	
		
def docuaddons():
    addDir(localizedString(32119).encode('utf-8'),'plugin://plugin.video.Vodil/?mode=11&name=%d7%93%d7%95%d7%a7%d7%95%d7%9e%d7%a0%d7%98%d7%a8%d7%99&url=url',1,'http://i141.photobucket.com/albums/r48/kobiko3030/documentary_zpsylsxppgu.jpg',ART+'sciencenature.jpg')
    addDir('Decado Documentary','plugin://plugin.video.DecadoDocs',1,ART+'decado.png',ART+'sciencenature.jpg')
    addDir('Brettus Documentary','plugin://plugin.video.Brettus.Documentaries',1,ART+'brettus.png',ART+'sciencenature.jpg')	 
    addDir('documentarytube','plugin://plugin.video.documentarytube',1,ART+'documentarytube.png',ART+'sciencenature.jpg')
    addDir('featherence docu','plugin://plugin.video.featherence.docu',1,ART+'featherencedocu.png',ART+'sciencenature.jpg')
    #addDir('סרטי דוקו','plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fone242415.offshorepastebin.com%2fMisc%2fdocs.xml',1,'http://s28.postimg.org/op4gqc0ot/Documentaries.jpg',ART+'sciencenature.jpg')
    #addDir('דוקומנטרי חי Uktv','plugin://plugin.video.uktvnow/?channelid&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.uktvnow%5cresources%5cart%5cdoc.PNG&mode=1&name=Documentary&url=6',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon-9_zpss7pgqvev.png',ART+'sciencenature.jpg')
    addDir(localizedString(32120).encode('utf-8'),'plugin://plugin.video.israelive/?categoryid=9999&description&displayname=10451&iconimage=http%3a%2f%2fwallpapers.free-review.net%2fwallpapers%2f23%2fNature_-_Wallpaper_for_Windows_7.jpg&mode=2&name=%5bCOLOR%20blue%5d%5bB%5d%5bScience%20%26%20nature%20-%20%d7%9e%d7%93%d7%a2%20%d7%95%d7%98%d7%91%d7%a2%5d%5b%2fB%5d%5b%2fCOLOR%5d&url',1,ART+'ilive.png',ART+'sciencenature.jpg')
    addDir(localizedString(32121).encode('utf-8'),'plugin://plugin.video.ccloudtv/?iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.ccloudtv%5cresources%2ficons%2f%2fdocumentary.png&mode=54&name=%5bCOLOR%20white%5dDocumentary%5b%2fCOLOR%5d&url=documentary',1,ART+'ccloud.png',ART+'sciencenature.jpg')	
    addDir('Evolve Goliath Doku','plugin://plugin.video.Evolve/?description&fanart=http%3a%2f%2fwww.matsbuilds.uk%2fpics%2fevolve%2ffanart.jpg&mode=1&name=%5bB%5d%5bCOLOR%20red%5dD%5b%2fCOLOR%5d%5bCOLOR%20white%5documentaries%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2fpastebin.com%2fraw%2fbAd5cCRm',1,ART+'golyat.jpg',ART+'sciencenature.jpg')	

def docuanimales():
    addDir(localizedString(32122).encode('utf-8'),'plugin://plugin.video.DecadoDocs/?description&mode=1&name=Nature&url=http%3a%2f%2ftopdocumentaryfilms.com%2fcategory%2fnature-wildlife%2f',1,ART+'decado.png',ART+'sciencenature.jpg')
    addDir(localizedString(32123).encode('utf-8'),'plugin://plugin.video.youtube/playlist/PL5o3ll3G4acxgDMSO7JXvDsosQ-UDPL6n/',1,'https://pbs.twimg.com/profile_images/378800000078781818/34de1b7ed5a7babc5ba6a6c4376e21e6.jpeg',ART+'sciencenature.jpg')	 
    addDir(localizedString(32124).encode('utf-8'),'plugin://plugin.video.projectm/?fanart=http%3a%2f%2fmwiz.co.uk%2fmerlinaddons%2ffanart%2ffanart.jpg&mode=1&name=%5bCOLOR%20aqua%5d%5bB%5d%20%20%20%20%20Nature%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fmwiz.co.uk%2fmerlinaddons%2ftextfiles%2fmerlinnature.xml',1,'http://mwiz.co.uk/merlinaddons/icons/nature.jpg',ART+'sciencenature.jpg')
    addDir(localizedString(32125).encode('utf-8'),'plugin://plugin.video.Vodil/?mode=1&name=%d7%a1%d7%a8%d7%98%d7%95%d7%a0%d7%99%d7%9d%20%d7%a4%d7%95%d7%a4%d7%95%d7%9c%d7%a8%d7%99%d7%99%d7%9d%20%d7%a1%d7%a8%d7%98%d7%99%20%d7%98%d7%91%d7%a2%20%d7%aa%d7%99%d7%a2%d7%95%d7%93%d7%99%d7%99%d7%9d&url=PL5o3ll3G4acxgDMSO7JXvDsosQ-UDPL6n',1,'http://i141.photobucket.com/albums/r48/kobiko3030/documentary_zpsylsxppgu.jpg',ART+'sciencenature.jpg')	 
    addDir('National Geographic','plugin://plugin.video.Vodil/?mode=1&name=%d7%a0%d7%a9%d7%99%d7%95%d7%a0%d7%9c%20%d7%92%d7%99%d7%90%d7%95%d7%92%d7%a8%d7%a4%d7%99%d7%a7&url=PLnzhIyrsnB5bP-t6Q6jfKANduI0KyxzkW',1,'http://i141.photobucket.com/albums/r48/kobiko3030/8314256770_9c5f3ab104_zpsmeaswrsb.jpg',ART+'sciencenature.jpg')	 
    addDir('Net Geo Wild','plugin://plugin.video.Vodil/?mode=1&name=Net%20Geo%20Wild&url=PLnzhIyrsnB5aCGBlzR9RPhX3xH3YZN8DG',1,'http://i141.photobucket.com/albums/r48/kobiko3030/images_zpslvjojskf.jpg',ART+'sciencenature.jpg')	 
    addDir(localizedString(32126).encode('utf-8'),'plugin://plugin.video.youtube/channel/UC3HohuFUk2IyjweMKagufQw/',1,'https://yt3.ggpht.com/-4nHixblGJtg/AAAAAAAAAAI/AAAAAAAAAAA/cWcLIgRmWwU/s100-c-k-no/photo.jpg',ART+'sciencenature.jpg')	 
    addDir(localizedString(32127).encode('utf-8'),'plugin://plugin.video.Vodil/?mode=1&name=%d7%90%d7%a4%d7%a8%d7%99%d7%a7%d7%94&url=PLnzhIyrsnB5bmxEqQVckOIP2xJEo34ULg',1,'http://i141.photobucket.com/albums/r48/kobiko3030/documentary_zpsylsxppgu.jpg',ART+'sciencenature.jpg')	 
    addDir(localizedString(32128).encode('utf-8'),'plugin://plugin.video.Vodil/?mode=1&name=%d7%93%d7%99%d7%a0%d7%95%d7%96%d7%90%d7%95%d7%a8%d7%99%d7%9d&url=PLnzhIyrsnB5bxAwKewvF4q8ORDR9HysZc',1,'http://i141.photobucket.com/albums/r48/kobiko3030/documentary_zpsylsxppgu.jpg',ART+'sciencenature.jpg')	 
    addDir(localizedString(32129).encode('utf-8'),'plugin://plugin.video.Vodil/?mode=1&name=%d7%97%d7%99%d7%95%d7%aa%20%d7%a7%d7%98%d7%9c%d7%a0%d7%99%d7%95%d7%aa&url=PLnzhIyrsnB5Yh0sE2zKFBvKAvoOoqsaVK',1,'http://i141.photobucket.com/albums/r48/kobiko3030/documentary_zpsylsxppgu.jpg',ART+'sciencenature.jpg')	 
    addDir(localizedString(32130).encode('utf-8'),'plugin://plugin.video.youtube/playlist/PL152bjytsMC5aOcBWY-y97pGKaks-Zdpv/',1,ART+'documentarytube.png',ART+'sciencenature.jpg')
    addDir(localizedString(32131).encode('utf-8'),'plugin://plugin.video.youtube/playlist/PL152bjytsMC6XeU_IyEbaxbgtRonyWhco/',1,ART+'documentarytube.png',ART+'sciencenature.jpg')
    addDir(localizedString(32132).encode('utf-8'),'plugin://plugin.video.youtube/playlist/PL152bjytsMC6YnVebMUshTFlNx8Z97_Ow/',1,ART+'documentarytube.png',ART+'sciencenature.jpg')
    addDir(localizedString(32133).encode('utf-8'),'plugin://plugin.video.youtube/playlist/PL152bjytsMC6oiNllYbAOMFCH8lXiRunF/',1,ART+'documentarytube.png',ART+'sciencenature.jpg')
    addDir(localizedString(32134).encode('utf-8'),'plugin://plugin.video.youtube/playlist/PL152bjytsMC7yGJjC2GYuXvLaXpn7wcZh/',1,ART+'documentarytube.png',ART+'sciencenature.jpg')
	
def docuheb():
    addDir(localizedString(32135).encode('utf-8'),'plugin://plugin.video.featherence.docu/?desc=%d7%a6%d7%a4%d7%94%20%d7%91%d7%9e%d7%92%d7%95%d7%95%d7%9f%20%d7%aa%d7%9b%d7%a0%d7%99%d7%9d%20%d7%91%d7%a0%d7%95%d7%a9%d7%90%20-%d7%93%d7%95%d7%a7%d7%95%d7%9e%d7%a0%d7%98%d7%a8%d7%99%20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99.&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.featherence.docu%5cfanart.jpg&iconimage=http%3a%2f%2fin.bgu.ac.il%2fwelcome%2fEventGalleries%2f%25D7%259C%25D7%25A9%25D7%2595%25D7%259F%2520%25D7%25A2%25D7%2591%25D7%25A8%25D7%2599%25D7%25AA.jpg&mode=108&name=%d7%93%d7%95%d7%a7%d7%95%d7%9e%d7%a0%d7%98%d7%a8%d7%99%20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99&num=1&url=None&viewtype=50',1,ART+'featherencedocu.png',ART+'sciencenature.jpg')
    addDir(localizedString(32136).encode('utf-8'),'plugin://plugin.video.Vodil/?mode=1&name=%d7%a1%d7%a8%d7%98%d7%95%d7%a0%d7%99%20%d7%98%d7%91%d7%a2%20%d7%91%d7%a2%d7%91%d7%a8%d7%99%d7%aa&url=PLnzhIyrsnB5Y8Ymf2ryG-LlX0DxK0JD5N',1,'http://i141.photobucket.com/albums/r48/kobiko3030/documentary_zpsylsxppgu.jpg',ART+'sciencenature.jpg')
    addDir(localizedString(32137).encode('utf-8'),'plugin://plugin.video.MakoTV/?iconimage=http%3a%2f%2fopendoclab.mit.edu%2fwp%2fwp-content%2fuploads%2f2011%2f09%2fcamera.jpg&mode=0&name=%d7%93%d7%95%d7%a7%d7%95%d7%9e%d7%a0%d7%98%d7%a8%d7%99%20-%20%d7%aa%d7%9b%d7%a0%d7%99%d7%95%d7%aa&url=http%3a%2f%2fwww.mako.co.il%2fmako-vod-more%2fdocu_tv',1,'http://opendoclab.mit.edu/wp/wp-content/uploads/2011/09/camera.jpg',ART+'sciencenature.jpg')
    addDir(localizedString(32138).encode('utf-8'),'plugin://plugin.video.MakoTV/?iconimage=http%3a%2f%2fopendoclab.mit.edu%2fwp%2fwp-content%2fuploads%2f2011%2f09%2fcamera.jpg&mode=0&name=%d7%93%d7%95%d7%a7%d7%95%d7%9e%d7%a0%d7%98%d7%a8%d7%99%20-%20%d7%a1%d7%a8%d7%98%d7%99%d7%9d&url=http%3a%2f%2fwww.mako.co.il%2fmako-vod-more%2fdocu_tv',1,'http://opendoclab.mit.edu/wp/wp-content/uploads/2011/09/camera.jpg',ART+'sciencenature.jpg')	 
    addDir(localizedString(32139).encode('utf-8'),'plugin://plugin.video.hotVOD.video/?mode=5&name=%d7%a2%d7%a8%d7%95%d7%a5%208&url=http%3a%2f%2fhot.ynet.co.il%2fhome%2f0%2c7340%2cL-7461%2c00.html',1,'http://i141.photobucket.com/albums/r48/kobiko3030/080_zpspw9zkpt1.jpg',ART+'sciencenature.jpg')
    addDir(localizedString(32140).encode('utf-8'),'plugin://plugin.video.movixws/?description&iconimage=http%3a%2f%2ficons.iconarchive.com%2ficons%2faaron-sinuhe%2ftv-movie-folder%2f512%2fDocumentaries-National-Geographic-icon.png&mode=2&name=Documentary%20-%20%d7%93%d7%95%d7%a7%d7%95%d7%9e%d7%a0%d7%98%d7%a8%d7%99&url=http%3a%2f%2fwww.movix.me%2fgenres%2fDocumentary',1,'http://icons.iconarchive.com/icons/aaron-sinuhe/tv-movie-folder/512/Documentaries-National-Geographic-icon.png',ART+'sciencenature.jpg')
    addDir(localizedString(32141).encode('utf-8'),'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=%d7%93%d7%95%d7%a7%d7%95%20(43)&url=genre%3dmovies%26genreId%3d6263',1,'http://i141.photobucket.com/albums/r48/kobiko3030/walla_zpsvfkl91lo.jpg',ART+'sciencenature.jpg')	
    addDir(localizedString(32142).encode('utf-8'),'plugin://plugin.video.wallaNew.video/?mode=2&module=wallavod&name=yes%20%d7%93%d7%95%d7%a7%d7%95%20(22)&url=genre%3dmovies%26genreId%3d8526',1,'http://i141.photobucket.com/albums/r48/kobiko3030/yes-logo_zpsqjtjmtk2.png',ART+'sciencenature.jpg')
    addDir(localizedString(32143).encode('utf-8'),'plugin://plugin.video.ilten/?category=2118',1,'http://images.applicaster.com/accounts/69/broadcasters/67/categories/2118/image_assets/41609/original.png?1322053599',ART+'sciencenature.jpg')
	
def doculive():
    addDir(localizedString(32201).encode('utf-8'),'plugin://plugin.video.ccloudtv/?iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.ccloudtv%5cresources%2ficons%2f%2fdocumentary.png&mode=54&name=%5bCOLOR%20white%5dDocumentary%5b%2fCOLOR%5d&url=documentary',1,ART+'ccloud.png',ART+'sciencenature.jpg')	
    #addDir('דוקומנטרי חי Uktv','plugin://plugin.video.uktvnow/?channelid&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.uktvnow%5cresources%5cart%5cdoc.PNG&mode=1&name=Documentary&url=6',1,'http://i141.photobucket.com/albums/r48/kobiko3030/icon-9_zpss7pgqvev.png',ART+'sciencenature.jpg')
    addDir(localizedString(32202).encode('utf-8'),'plugin://plugin.video.israelive/?categoryid=9999&description&displayname=10451&iconimage=http%3a%2f%2fwallpapers.free-review.net%2fwallpapers%2f23%2fNature_-_Wallpaper_for_Windows_7.jpg&mode=2&name=%5bCOLOR%20blue%5d%5bB%5d%5bScience%20%26%20nature%20-%20%d7%9e%d7%93%d7%a2%20%d7%95%d7%98%d7%91%d7%a2%5d%5b%2fB%5d%5b%2fCOLOR%5d&url',1,ART+'ilive.png',ART+'sciencenature.jpg')
 
def music():
    addDir2(localizedString(32144).encode('utf-8'),'plugin://plugin.video.alive.hd',72,ART+'Music-icon.png',ART+'music.jpg')	
    addDir2(localizedString(32145).encode('utf-8'),'plugin://plugin.video.alive.hd',70,'http://s27.postimg.org/bwjiufa9v/Live_In_Concert.jpg',ART+'music.jpg')	
    addDir2(localizedString(32146).encode('utf-8'),'plugin://plugin.video.alive.hd',71,ART+'kmusictube.png',ART+'music.jpg')
    addDir2(localizedString(32147).encode('utf-8'),'plugin://plugin.video.alive.hd',74,'http://goo.gl/efZexq',ART+'music.jpg')	
    addDir(localizedString(32148).encode('utf-8'),'plugin://plugin.video.Vodil/?mode=13&name=%d7%9e%d7%95%d7%96%d7%99%d7%a7%d7%94&url=url',1,ART+'vodilmusic.jpg',ART+'music.jpg')
    addDir2(localizedString(32149).encode('utf-8'),'plugin://plugin.video.alive.hd',73,ART+'merlinr.png',ART+'music.jpg')	 
    addDir(localizedString(32150).encode('utf-8'),'plugin://plugin.video.Karaokeil',1,ART+'Karaokeil.png',ART+'music.jpg')
 
def liveshows():
    addDir(localizedString(32151).encode('utf-8'),'plugin://plugin.video.featherence.music/?desc=%d7%a6%d7%a4%d7%94%20%d7%91%d7%9e%d7%92%d7%95%d7%95%d7%9f%20%d7%aa%d7%9b%d7%a0%d7%99%d7%9d%20%d7%91%d7%a0%d7%95%d7%a9%d7%90%20-%d7%94%d7%95%d7%a4%d7%a2%d7%95%d7%aa%20%d7%97%d7%99%d7%95%d7%aa%20%d7%9e%d7%99%d7%a9%d7%a8%d7%90%d7%9c.&fanart=https%3a%2f%2fupload.wikimedia.org%2fwikipedia%2fcommons%2f7%2f72%2fFlickr_-_Government_Press_Office_(GPO)_-_Shlomo_Artzi_performing_at_a_rock_festival_in_the_Red_Sea.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cscript.featherence.service%5cresources%5cicons%5cguitar.png&mode=10104&name=%d7%94%d7%95%d7%a4%d7%a2%d7%95%d7%aa%20%d7%97%d7%99%d7%95%d7%aa%20%d7%9e%d7%99%d7%a9%d7%a8%d7%90%d7%9c&num=1&url=None&viewtype=0',1,ART+'fdkids.png',ART+'music.jpg')	
    addDir(localizedString(32152).encode('utf-8'),'plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fone242415.offshorepastebin.com%2finconcert%2fconcertsdirectory.xml',1,'http://s27.postimg.org/bwjiufa9v/Live_In_Concert.jpg',ART+'music.jpg')
    addDir(localizedString(32153).encode('utf-8'),'plugin://plugin.video.alive.hd',1,ART+'alivehd.png',ART+'music.jpg')	
    addDir(localizedString(32154).encode('utf-8'),'plugin://plugin.video.Vodil/?mode=16&name=%d7%94%d7%95%d7%a4%d7%a2%d7%95%d7%aa%20%d7%97%d7%99%d7%95%d7%aa&url=url',1,ART+'liveshow.jpg',ART+'music.jpg')
    addDir(localizedString(32155).encode('utf-8'),'plugin://plugin.video.The-Music-Source/?fanart=https%3a%2f%2fi.ytimg.com%2fvi%2fwUpM7xOGAlo%2fmaxresdefault.jpg&mode=1&name=%5bCOLOR%20dodgerblue%5dMusic%5b%2fCOLOR%5d%20Concerts%20&url=http%3a%2f%2fpastebin.com%2fraw.php%3fi%3dQ0pk8kyg',1,'http://wallpaperscraft.com/image/linkin_park_concert_action_microphone_guitars_2174_1920x1080.jpg',ART+'music.jpg')

def ilmusic():
    addDir(localizedString(32156).encode('utf-8'),'plugin://plugin.video.Vodil/?mode=1&name=%d7%a9%d7%99%d7%a8%d7%99%d7%9d%20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99%d7%9d%20%d7%97%d7%93%d7%a9%d7%99%d7%9d&url=PLD_zAoRa9UcA4U7jHXTx3hDF3om7zM5jd',1,ART+'vodilmusic.jpg',ART+'music.jpg')
    addDir(localizedString(32157).encode('utf-8'),'plugin://plugin.video.kmusictube/?action&iconimage&list=%d7%9e%d7%95%d7%96%d7%99%d7%a7%d7%94%20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99%d7%aa%3c%3ehttp%3a%2f%2fshironet.mako.co.il%2fhtml%2findexes%2fperformers%2f%3c%3e%3c%3e&mode=israeli_artists&name=%d7%9e%d7%95%d7%96%d7%99%d7%a7%d7%94%20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99%d7%aa&type&url=http%3a%2f%2fshironet.mako.co.il%2fhtml%2findexes%2fperformers%2f',1,ART+'kmusictube.png',ART+'music.jpg')	
    addDir(localizedString(32158).encode('utf-8'),'plugin://plugin.audio.99fm-playlists/channels/10/playlists',1,'http://eco99fm.maariv.co.il/download/SetsCategories/9/channels03-ISRAELI.jpg',ART+'music.jpg')
    addDir(localizedString(32159).encode('utf-8'),'plugin://plugin.video.featherence.music/?desc=%d7%a6%d7%a4%d7%94%20%d7%91%d7%9e%d7%92%d7%95%d7%95%d7%9f%20%d7%aa%d7%9b%d7%a0%d7%99%d7%9d%20%d7%91%d7%a0%d7%95%d7%a9%d7%90%20-%d7%9e%d7%95%d7%96%d7%99%d7%a7%d7%94%20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99%d7%aa.&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.featherence.music%5cfanart.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cscript.featherence.service%5cresources%5cicons%5cmusic.png&mode=10101&name=%d7%9e%d7%95%d7%96%d7%99%d7%a7%d7%94%20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99%d7%aa&num=1&url=None&viewtype=0',1,ART+'fdkids.png',ART+'music.jpg')

def worldmusic():
    addDir(localizedString(32160).encode('utf-8'),'plugin://plugin.video.The-Music-Source/?fanart=http%3a%2f%2fi64.tinypic.com%2f6h2sso.jpg&mode=1&name=%5bCOLOR%20burlywood%5dIPTV%5b%2fCOLOR%5d%20Music%20Channels%20&url=http%3a%2f%2fpastebin.com%2fraw.php%3fi%3dpXgNwd5K',1,'http://i.ytimg.com/vi/0idGEskBqSw/maxresdefault.jpg',ART+'music.jpg')
    addDir(localizedString(32161).encode('utf-8'),'plugin://plugin.video.TheJukeBox/?description&fanart=http%3a%2f%2fmatsbuilds.uk%2fpics%2fjukebox%2ffanart.png&mode=1&name=%5bCOLOR%20red%5d%5bB%5dLIVE%20Music%20Channels%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2fpastebin.com%2fraw%2f7tCv4wLs',1,'http://matsbuilds.uk/pics/jukebox/live_music.png',ART+'music.jpg')
    addDir(localizedString(32162).encode('utf-8'),'=plugin://plugin.video.wildhitz/?fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.wildhitz%5cfanart.jpg&mode=6&name=Playlist&url=top3',1,ART+'wildhitz.png',ART+'music.jpg')
    addDir(localizedString(32163).encode('utf-8'),'plugin://plugin.video.kmusictube/?action&iconimage&list=%d7%9e%d7%95%d7%96%d7%99%d7%a7%d7%94%20%d7%9c%d7%95%d7%a2%d7%96%d7%99%d7%aa%3c%3eurl%3c%3e%3c%3e&mode=ENGLISH_CATEGORIES&name=%d7%9e%d7%95%d7%96%d7%99%d7%a7%d7%94%20%d7%9c%d7%95%d7%a2%d7%96%d7%99%d7%aa&type&url=url',1,ART+'kmusictube.png',ART+'music.jpg')	
    addDir(localizedString(32164).encode('utf-8'),'plugin://plugin.audio.jango/?iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.audio.jango%5cart%2ficon_browse_music.jpg&id&list=%3ctype%20%27list%27%3e&mode=2&name=Browse%20Music&type&url=http%3a%2f%2fwww.jango.com%2fbrowse_music',1,ART+'jango.png',ART+'music.jpg')
    addDir(localizedString(32165).encode('utf-8'),'plugin://plugin.video.featherence.music/?desc=%d7%a6%d7%a4%d7%94%20%d7%91%d7%9e%d7%92%d7%95%d7%95%d7%9f%20%d7%aa%d7%9b%d7%a0%d7%99%d7%9d%20%d7%91%d7%a0%d7%95%d7%a9%d7%90%20-%d7%9e%d7%95%d7%96%d7%99%d7%a7%d7%94%20%d7%9c%d7%95%d7%a2%d7%96%d7%99%d7%aa.&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.featherence.music%5cfanart.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cscript.featherence.service%5cresources%5cicons%5cus.png&mode=111&name=%d7%9e%d7%95%d7%96%d7%99%d7%a7%d7%94%20%d7%9c%d7%95%d7%a2%d7%96%d7%99%d7%aa&num=1&url=None&viewtype=0',1,ART+'fdkids.png',ART+'music.jpg')
	
	
def radiom():
    addDir(localizedString(32166).encode('utf-8'),'plugin://plugin.audio.internet-radio/',1,'http://i141.photobucket.com/albums/r48/kobiko3030/2016-09-19_08-23-28_zps9gntkpyy.png',ART+'music.jpg')
    addDir(localizedString(32167).encode('utf-8'),'plugin://plugin.video.israelive/?categoryid=9999&description&displayname=10000&iconimage=http%3a%2f%2fmdmorrope.gob.pe%2fportalweb%2fimagenes%2fradioss.png&mode=2&name=%5bCOLOR%20blue%5d%5bB%5d%5bRadio%20From%20Israel%20-%20%d7%a8%d7%93%d7%99%d7%95%5d%5b%2fB%5d%5b%2fCOLOR%5d&url',1,ART+'ilive.png',ART+'music.jpg')	
    addDir(localizedString(32168).encode('utf-8'),'plugin://plugin.video.The-Music-Source/?fanart=http%3a%2f%2fi68.tinypic.com%2f33w7f5w.jpg&mode=1&name=%5bCOLOR%20dodgerblue%5dLive%20%5b%2fCOLOR%5dRadio%20Stations%20&url=http%3a%2f%2fpastebin.com%2fraw.php%3fi%3dAiLA9g7b',1,'http://i62.tinypic.com/2vuj4v9.png',ART+'music.jpg')
    addDir(localizedString(32169).encode('utf-8'),'plugin://plugin.video.TheJukeBox/?description&fanart=http%3a%2f%2fmatsbuilds.uk%2fpics%2fjukebox%2ffanart.png&mode=1&name=%5bCOLOR%20red%5d%5bB%5dRadio%20Section%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2fwww.matsbuilds.uk%2fprivate%2fradiostations.xml',1,'http://matsbuilds.uk/pics/jukebox/radio.png',ART+'music.jpg')
    addDir(localizedString(32170).encode('utf-8'),'plugin://plugin.audio.merlinradio',1,ART+'merlinr.png',ART+'music.jpg')
	
def musicaddons():
    addDir(localizedString(32171).encode('utf-8'),'plugin://plugin.video.Vodil/?mode=13&name=%d7%9e%d7%95%d7%96%d7%99%d7%a7%d7%94&url=url',1,ART+'vodilmusic.jpg',ART+'music.jpg')
    addDir('99fm playlists','plugin://plugin.audio.99fm-playlists',1,ART+'nine.png',ART+'music.jpg')
    #addDir('Alpha Bits','plugin://plugin.video.AlphaMovies/?fanart&mode=1&name=%5bCOLOR%20lawngreen%5d%5bB%5dAlphaBeats%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2falphaaddon.co.uk%2fthealpha%2falphabeats-v2%2falphabeats.txt',1,'http://alphaaddon.comli.com/alphabeats.jpg',ART+'music.jpg')
    addDir('featherence music','plugin://plugin.video.featherence.music',1,ART+'fdkids.png',ART+'music.jpg')		
    addDir('jango','plugin://plugin.audio.jango',1,ART+'jango.png',ART+'music.jpg')
    addDir('kmusictube','plugin://plugin.video.kmusictube/?content_type=audio',1,ART+'kmusictube.png',ART+'music.jpg')
    addDir('The Music Source','plugin://plugin.video.The-Music-Source',1,ART+'tmso.png',ART+'music.jpg')	
    addDir('wildhitz','plugin://plugin.video.wildhitz',1,ART+'wildhitz.png',ART+'music.jpg')
    addDir('The Jukbox','plugin://plugin.video.TheJukeBox',1,ART+'tjbox.png',ART+'music.jpg')
	
def meta():
    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.program.meta_search/?content_type=video)")
	
def browaddons():
    xbmc.executebuiltin("ActivateWindow(AddonBrowser)")
	
def addsource():
    xbmc.executebuiltin("ActivateWindow(FileManager)")
	
def videomange():
    xbmc.executebuiltin("ActivateWindow(Videos,Files,return)")

def Audiomanage():
    xbmc.executebuiltin("ActivateWindow(Music,Files,return)")	

def setti():
    xbmc.executebuiltin("ActivateWindow(Settings)")	
	
def exodus():
    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.exodus/?action=searchNavigator)")
	
def exodustrakt():
    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.exodus/?action=calendar&url=progress)")	
	
def exodustv():
    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.exodus/?action=tvNavigator)")		
	
def exodusmovies():
    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.exodus/?action=movieNavigator)")	

def chonea():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.israelive/?url=channel-511B%3Fmode%3D33&mode=10&name=%5BCOLOR+yellow%5D%5BB%5D%D7%94%D7%A2%D7%A8%D7%95%D7%A5+%D7%94%D7%A8%D7%90%D7%A9%D7%95%D7%9F%5B%2FB%5D%5B%2FCOLOR%5D+-+%5BCOLOR+orange%5D%5BB%5D%D7%A2%D7%A8%D7%91+%D7%97%D7%93%D7%A9+-+%D7%A2%D7%9D+%D7%93%D7%9F+%D7%9E%D7%A8%D7%92%D7%9C%D7%99%D7%AA%5B%2FB%5D%5B%2FCOLOR%5D+%5BCOLOR+burlywood%5D%5B16%3A59-17%3A34%5D%5B%2FCOLOR%5D+-+%5BCOLOR+white%5DNext%3A+%5BB%5D%D7%9C%D7%90%D7%9E%D7%A8%D7%99%D7%A7%D7%94+%D7%99%D7%A9+%D7%9B%D7%A9%D7%A8%D7%95%D7%9F%2C+%D7%A2%D7%95%D7%A0%D7%94+11+-+%D7%A4%D7%A8%D7%A7+20%5B%2FB%5D%5B%2FCOLOR%5D+%5BCOLOR+burlywood%5D%5B17%3A34-19%3A00%5D%5B%2FCOLOR%5D&iconimage=http%3A%2F%2Fimg.mako.co.il%2F2008%2F05%2F01%2F01%2Ffirst_channel_logo_b.jpg&description=%D7%AA%D7%9B%D7%A0%D7%99%D7%AA+%D7%90%D7%A7%D7%98%D7%95%D7%90%D7%9C%D7%99%D7%94+%D7%99%D7%95%D7%9E%D7%99%D7%AA+%D7%94%D7%9E%D7%9C%D7%95%D7%95%D7%94+%D7%91%D7%A2%D7%93%D7%9B%D7%95%D7%A0%D7%99+%D7%97%D7%93%D7%A9%D7%95%D7%AA+%D7%9E%D7%90%D7%95%D7%9C%D7%A4%D7%9F+%22%D7%9E%D7%91%D7%98%22.+%D7%9E%D7%92%D7%99%D7%A9%3A+%D7%93%D7%9F+%D7%9E%D7%A8%D7%92%D7%9C%D7%99%D7%AA.&displayname=%D7%94%D7%A2%D7%A8%D7%95%D7%A5+%D7%94%D7%A8%D7%90%D7%A9%D7%95%D7%9F&categoryid=10065)")	
	
def choneb():
    xbmc.executebuiltin("PlayMedia(plugin://plugin.video.anarchitv/?url=rtmp%3A%2F%2Fiba-s.vidnt.com%2Fiba_channel-511MRepeat%2Fchannel-511M_4.stream&mode=1&name=%D7%94%D7%A2%D7%A8%D7%95%D7%A5+%D7%94%D7%A8%D7%90%D7%A9%D7%95%D7%9F&iconimage=http%3A%2F%2Fteleviz.net%2Fstatic%2Fimg%2Flogos%2Fc11.png)")	
		
def exoduskids():
    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.exodus/?action=movies&amp;url=http%3a%2f%2fwww.imdb.com%2fsearch%2ftitle%3ftitle_type%3dfeature%2ctv_movie%26languages%3den%26num_votes%3d100%2c%26release_date%3ddate%5b730%5d%2cdate%5b30%5d%26genres%3danimation%26sort%3dmoviemeter%2casc%26count%3d40%26start%3d1&quot)")	

def Favourites():
    xbmc.executebuiltin("ActivateWindow(Favourites)")	
	
def livepvr():
    xbmc.executebuiltin("ActivateWindow(MyPVR)")

def exitkodi():
    xbmc.executebuiltin("Quit")	
	
def metasearch(url):
    ok=True        
    xbmc.executebuiltin('XBMC.Container.Update(%s)' % url )
    return ok  		

def addDir(name,url,mode,iconimage,fanart):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        

def addDir2(name, url, mode, iconimage, fanart):
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		u = 'plugin://plugin.video.youtube/%s/%s/' % (url.split( '/' )[-2], url.split( '/' )[-1])
		ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
		return ok		
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok		

	
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None



try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:     
		repoinstall()
		main()
       
elif mode==1:
        metasearch(url)
        
elif mode==2:
        globalsearch(url)
		
elif mode==3:
        meta()	

elif mode==4:
        salts()

elif mode==5:
        exodus()

elif mode==8:
        Favourites()

elif mode==9:
        movies()	

elif mode==10:
        tv()			

elif mode==11:
        livetvs()	
		
elif mode==12:
        docu()	

elif mode==13:
        kids()	

elif mode==14:
        vod()

elif mode==15:
        music()

elif mode==16:
        hdmovies()

elif mode==17:
        exodusmovies()

elif mode==20:
        multyaddons()

elif mode==26:
        Vodil()

elif mode==33:
        vodall()		
		
elif mode==39:
        exoduskids()

elif mode==50:
        dmovies()

elif mode==51:
        fourk()

elif mode==52:
        boxsets()

elif mode==53:
        chits()

elif mode==54:
        womenmovies()

elif mode==55:
        exodustv()

elif mode==56:
        movieslb()	

elif mode==57:
        tvlb()

elif mode==58:
        addons()

elif mode==59:
        browaddons()		

elif mode==60:
        addsource()
		
elif mode==61:
        system()

elif mode==62:
        setti()

elif mode==63:
        livepvr()

elif mode==64:
        heros()

elif mode==65:
        mobmovies()	

elif mode==66:
        fightmovies()

elif mode==67:
        soupe()

elif mode==68:
        cooking()

elif mode==69:
        exitkodi()	

elif mode==70:
        liveshows()

elif mode==71:
        ilmusic()

elif mode==72:
        musicaddons()

elif mode==73:
        radiom()

elif mode==74:
        worldmusic()

elif mode==75:
        videomange()
		
elif mode==76:
        exodustrakt()

elif mode==77:
        docuaddons()

elif mode==78:
        docuheb()

elif mode==79:
        doculive()

elif mode==80:
        docuanimales()

elif mode==81:
        maintnence()

elif mode==82:
        standup()	

elif mode==83:
        israeltv()

elif mode==84:
        chone()	

elif mode==85:
        chonea()

elif mode==86:
        choneb()

elif mode==87:
        chonec()

elif mode==88:
        choned()

elif mode==89:
        chtowa()

elif mode==90:
        chtowb()

elif mode==91:
        chtowc()

elif mode==92:
        chtowd()

elif mode==93:
        chtow()

elif mode==94:
        chten()		

elif mode==95:
        chtena()

elif mode==96:
        chtenb()

elif mode==97:
        chtenc()

elif mode==98:
        chtend()

elif mode==99:
        chtene()

elif mode==100:
        chtowe()

elif mode==101:
        chtowa()

elif mode==102:
        kidslive()

elif mode==103:
        kidsa()

elif mode==104:
        kidsb()		

elif mode==105:
        kidsc()

elif mode==106:
        kidsd()

elif mode==107:
        kidse()

elif mode==108:
        kidsf()

elif mode==109:
        kidsg()

elif mode==110:
        kidsh()

elif mode==111:
        kidsi()

elif mode==112:
        kidsj()	

elif mode==113:
        premium()

elif mode==114:
        premiuma()

elif mode==115:
        kidsh()

elif mode==116:
        netgeow()

elif mode==117:
        nationag()	

elif mode==118:
        dturbo()

elif mode==119:
        dScience()

elif mode==120:
        bigb()

elif mode==121:
        addonssettings()

elif mode==122:
        subceterset()

elif mode==123:
        ktuvitset()

elif mode==124:
        opensubsset()

elif mode==125:
        torecset()		

elif mode==126:
       metaset()
	   
elif mode==127:
       Audiomanage()	   

xbmcplugin.endOfDirectory(int(sys.argv[1]))

