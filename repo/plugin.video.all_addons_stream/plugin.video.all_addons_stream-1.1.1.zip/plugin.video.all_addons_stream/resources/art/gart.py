# -*- coding: utf-8 -*-

import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys
import urllib
import orphAddon

USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON=xbmcaddon.Addon(id='plugin.video.all_addons_stream')
addon_id='plugin.video.all_addons_stream'
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
VERSION = "1.1.0"
PATH = "Super Addon"            
Progress = xbmcgui.DialogProgress()
showed = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.all_addons_stream', 'showed'))
Config = xbmcaddon.Addon()
Config.setSetting(id='auto-view', value='true')




def repoinstall():

   if os.path.isfile(showed) == False:
    f = open(showed,"w+")
    f.write("")
    f.close()
    
    repoinstall() 
    Progress.create("מתקין מאגרי רפו...", "נא להמתין", "רץ רק בפתיחה ראשונה של ההרחבה")
    Progress.update(0)
    orphAddon.senyorepo()
    Progress.update(5)
    orphAddon.Exodusrepo()
    Progress.update(10)
    orphAddon.filmkodi()
    Progress.update(15)	
    orphAddon.TheWiz()
    Progress.update(20)
    orphAddon.kodisrael()
    Progress.update(25)
    orphAddon.ToMeRepo()
    Progress.update(30)
    orphAddon.featherence()
    Progress.update(35)
    orphAddon.merlin()
    Progress.update(50)
    orphAddon.xbmcisrael()	
    Progress.update(90)
    orphAddon.youtube()
    Progress.update(100)   
 
 
def main():
    addDir2('חיפוש','חיפוש',3,ART+'Search-icon.png',ART+'search.jpg')
    addDir2('סרטים','סרטים',9,ART+'Movies-Oscar-icon.png',ART+'movies.jpg')
    addDir2('סדרות','סדרות',10,ART+'television-08-icon.png',ART+'tvshows.jpg')
    addDir2('טלוויזיה', 'טלוויזיה',11,ART+'television-07-icon.png',ART+'livetv.jpg')
    addDir2('מוזיקה ורדיו','מוזיקה',15,ART+'Music-icon.png',ART+'music.jpg')
    addDir2('דוקומנטרי','דוקומנטרי',12,ART+'Documentary-icon.png',ART+'sciencenature.jpg')
    addDir2('ילדים','ילדים',13,ART+'Kids-icon.png',ART+'kids.jpg')
    addDir2('ספרית תוכן','ספרית תוכן',33,ART+'Movies-icon.png',ART+'vod.jpg')
    addDir2('הרחבות','הרחבות',58,ART+'movie-icon.png',ART+'addons.jpg')
    addDir2('מערכת','מערכת',61,ART+'Settings-icon.png',ART+'settings.jpg')
    addDir('מועדפים','מועדפים',8,ART+'Favorites-icon.png',ART+'favorites.jpg')
	
def movies():
    addDir2('ספריית סרטים','ספריית סרטים',56,ART+'wiz.png',ART+'movies.jpg')
    addDir('Exodus','Exodus',17,ART+'exodus.png',ART+'movies.jpg')	
    addDir('Salts','plugin://plugin.video.salts/?mode=browse&amp;section=Movies',1,ART+'salts.png',ART+'movies.jpg')
    addDir('Specto','plugin://plugin.video.specto/?action=movieNavigator',1,ART+'specto.png',ART+'movies.jpg')
    addDir('Phoenix','plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fphoenixtv.offshorepastebin.com%2freleases%2fmain.xml',1,ART+'phoenix.png',ART+'movies.jpg')
    addDir2('סרטים באיכות HD','סרטים באיכות HD',16,ART+'hdmovies.png',ART+'movies.jpg')
    addDir2('סרטי תלת מימד','סרטי תלת מימד',50,ART+'3dmovies.png',ART+'movies.jpg')
    addDir2('סרטים באיכות 4K','סרטים באיכות 4K',51,ART+'fourk.jpg',ART+'movies.jpg')
    addDir2('מארזי סרטים','מארזי סרטים',52,ART+'boxsets.jpg',ART+'movies.jpg')
    addDir2('להיטים קלאסיים','להיטים קלאסיים',53,ART+'classicmovies.png',ART+'movies.jpg')
    addDir2('סרטים לנשים','סרטים לנשים',54,ART+'rose-icon.png',ART+'movies.jpg')
	
def hdmovies():
    addDir('dandymedia HD','plugin://plugin.video.dandymedia/?fanart=https%3a%2f%2fraw.githubusercontent.com%2fdandy0850%2fiStream%2fmaster%2fScreenshot_2.jpg&mode=1&name=%5bB%5d%5bCOLOR%20yellow%5dHD%20Movies%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2fbit.ly%2f1WAh0f5',1,ART+'dandy.png',ART+'movies.jpg')	
    addDir('community allsorts HD','plugin://plugin.video.communityallsorts/?fanart=http%3a%2f%2fwww.whitegadget.com%2fattachments%2fpc-wallpapers%2f68569d1313643199-hd-wallpapers-1080p-hd-wallpapers-1080p-photo-shoot.jpg&mode=1&name=%5bB%5d%5bCOLOR%20blue%5d%2a%2a%2a%2a%2a%2a%2a%2a%5bB%5d%5bCOLOR%20white%5dJUST-1080P-ZONE%5bB%5d%5bCOLOR%20blue%5d%2a%2a%2a%2a%2a%2a%2a%2a%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fallsorts.kodi-pirates.tv%2fALLSORTS-FILES%2fJUST-1080P.XML',1,ART+'allsort.png',ART+'movies.jpg')
    addDir('Evolve Kraken HD','plugin://plugin.video.Evolve/?description&fanart=http%3a%2f%2f2.bp.blogspot.com%2f-yBgAZggXR7M%2fUO7g6pio1-I%2fAAAAAAAAAKY%2f7N4_RWv2wZI%2fs1600%2fInstution%2bMoodboard.png&mode=1&name=%5bB%5d%5bCOLOR%20red%5dHD%5b%2fCOLOR%5d%20%5bCOLOR%20white%5d%20MOVIEZONE%5b%2fCOLOR%5d%5b%2fB%5d%20&url=http%3a%2f%2fmatsbuilds.uk%2frambo%2fEVOLVE%2fMENUS%2fMOVIEZONE.xml',1,ART+'kraken.jpg',ART+'movies.jpg')
    addDir('Evolve Markov HD','plugin://plugin.video.Evolve/?description&fanart=http%3a%2f%2fmedia-passion.fr%2faddons%2fFiles%2fscript.artwork.downloader.mp%2ffanart.jpg&mode=1&name=%5bB%5d%5bCOLOR%20red%5d-%3d-%5b%2fCOLOR%5d%5bCOLOR%20white%5d%20H%20D%20%20%20M%20O%20V%20I%20E%20S%5b%2fCOLOR%5d%5bCOLOR%20red%5d-%3d-%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2fg10.x10host.com%2fevolve%2fhd.xml',1,ART+'markov.jpg',ART+'movies.jpg')	
    addDir('MoviePool','plugin://plugin.video.moviepool',1,ART+'moviepool.png',ART+'movies.jpg')
    addDir('kodi popcorn time HD','plugin://plugin.video.kodipopcorntime/?action=cat_Movies&amp;endpoint=folders&amp;mediaType=movies',1,ART+'popcorn.png',ART+'movies.jpg')
	
def dmovies():
    addDir('Evolve Trapper 3D','plugin://plugin.video.Evolve/?description&fanart=http%3a%2f%2fi.imgur.com%2fo7pN9z0.png&mode=1&name=3D%20Movies&url=http%3a%2f%2fpastebin.com%2fraw%2fWtrwpFv2',1,ART+'trapper.jpg',ART+'movies.jpg')
    addDir('Titan 3D','plugin://plugin.video.titan/?description&iconimage=http%3a%2f%2fi67.tinypic.com%2f14uq6o.jpg&mode=6&name=%5bCOLOR%20aqua%5d%203D%20%5b%2fCOLOR%5d&url=https%3a%2f%2farchive.org%2fdownload%2fNaviXPlaylist%2f3D.xml',1,ART+'titan.png',ART+'movies.jpg')
    addDir('Ak-47 3D','plugin://plugin.video.AK-47/?fanart=http%3a%2f%2fs9.postimg.org%2fqzvorcwz3%2ffan.jpg&mode=1&name=%5bCOLOR%20lime%5d%5bB%5d%20%20%e2%80%a2%20%20%20%5b%2fB%5d%5b%2fCOLOR%5d%5bCOLOR%20turquoise%5d%5bB%5d3D%20MOVIES%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fhitflix.tv%2faddon%2fmov%2fcf%2ffor%2f3d.xml',1,ART+'ak.png',ART+'movies.jpg')	
    addDir('community allsorts 3D','plugin://plugin.video.communityallsorts/?fanart=http%3a%2f%2fscience-all.com%2fimages%2f3d-wallpaper%2f3d-wallpaper-08.jpg&mode=1&name=%5bB%5d%5bCOLOR%20blue%5d%2a%2a%2a%2a%2a%2a%2a%2a%5bB%5d%5bCOLOR%20white%5d3D-TENT%5bB%5d%5bCOLOR%20blue%5d%2a%2a%2a%2a%2a%2a%2a%2a%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fallsorts.kodi-pirates.tv%2fALLSORTS-FILES%2f3D-MOVIES.XML',1,ART+'allsort.png',ART+'movies.jpg')
    addDir('Uk Turk','plugin://plugin.video.ukturk/?description&iconimage=http%3a%2f%2fmetalkettle.co%2fUKTurk18022016%2fmovies%2fthumbs%2fUk%2520turk%2520thumbnails%25203d%2520movies.jpg&mode=1&name=3D%20Movies&url=http%3a%2f%2fmetalkettle.co%2fUKTurk18022016%2fmovies%2f3D.txt',1,ART+'turk.png',ART+'movies.jpg')	

def boxsets():
    addDir('community allsorts BoxSets','plugin://plugin.video.communityallsorts/?fanart=http%3a%2f%2fcreative.bauermedia.co.uk%2fskyboxsets%2fimages%2fboxsets.jpg&mode=1&name=%5bB%5d%5bCOLOR%20blue%5d%2a%2a%2a%2a%2a%2a%2a%2a%5bB%5d%5bCOLOR%20white%5dBOX-SETS-GALORE%5bB%5d%5bCOLOR%20blue%5d%2a%2a%2a%2a%2a%2a%2a%2a%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fallsorts.kodi-pirates.tv%2fALLSORTS-FILES%2fBOX%7eSETS.XML',1,ART+'allsort.png',ART+'movies.jpg')
    addDir('The Alpha BoxSets','plugin://plugin.video.AlphaMovies/?fanart&mode=1&name=%5bCOLOR%20lawngreen%5d%5bB%5dBoxsets%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2falphaaddon.co.uk%2fthealpha%2falphaboxsets-v2%2fboxsetsbackup.txt',1,ART+'alpha.png',ART+'movies.jpg')
    addDir('Dandymedia BoxSets','plugin://plugin.video.dandyboxset',1,ART+'boxd.png',ART+'movies.jpg')
	
def fourk():
    addDir('community allsorts 4k','plugin://plugin.video.communityallsorts/?fanart=http%3a%2f%2fblogs-images.forbes.com%2fjohnarcher%2ffiles%2f2014%2f10%2f4kultrahdlogos.jpg&mode=1&name=%5bB%5d%5bCOLOR%20blue%5d%2a%2a%2a%2a%2a%2a%2a%2a%5bB%5d%5bCOLOR%20white%5d4K-MOVIES-HANGER%5bB%5d%5bCOLOR%20blue%5d%2a%2a%2a%2a%2a%2a%2a%2a%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fallsorts.kodi-pirates.tv%2fALLSORTS-FILES%2fMAIN-4K-STUFF.XML',1,ART+'allsort.png',ART+'movies.jpg')
    addDir('Titan 4k','plugin://plugin.video.titan/?description&iconimage=http%3a%2f%2fi65.tinypic.com%2foiwxoy.jpg&mode=6&name=%5bCOLOR%20aqua%5d%204K%20%5b%2fCOLOR%5d&url=https%3a%2f%2farchive.org%2fdownload%2fNaviXPlaylist%2f4k.xml',1,ART+'titan.png',ART+'movies.jpg')
    addDir('Release hub','plugin://plugin.video.theyidrh/?mode=GetTitles56&section=ALL&url=http%3a%2f%2fback2back2back.weebly.com%2flayout%2fcategory%2f4k',1,ART+'theyidrh.png',ART+'movies.jpg')
	
def chits():
    addDir('Dandymedia old gold','plugin://plugin.video.dandymedia/?fanart=https%3a%2f%2fraw.githubusercontent.com%2fdandy0850%2fiStream%2fmaster%2fScreenshot_2.jpg&mode=1&name=%5bB%5d%5bCOLOR%20yellow%5dOld%20Gold%20(-2000)%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2fbit.ly%2f1scZxx8',1,ART+'dandy.png',ART+'movies.jpg')
    addDir('community allsorts classic','plugin://plugin.video.communityallsorts/?fanart=http%3a%2f%2fgretchenrubin.com%2fwp-content%2fuploads%2f2016%2f04%2fmoviesseats.jpg&mode=1&name=%5bB%5d%5bCOLOR%20blue%5d%2a%2a%2a%2a%2a%2a%2a%2a%5bB%5d%5bCOLOR%20white%5dJUST-GREAT-MOVIES%5bB%5d%5bCOLOR%20blue%5d%2a%2a%2a%2a%2a%2a%2a%2a%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fallsorts.kodi-pirates.tv%2fALLSORTS-FILES%2fJUSTGREATMOVIES.XML',1,ART+'allsort.png',ART+'movies.jpg')
    addDir('Ak-47 90','plugin://plugin.video.AK-47/?fanart=http%3a%2f%2fs9.postimg.org%2fqzvorcwz3%2ffan.jpg&mode=1&name=%5bCOLOR%20lime%5d%5bB%5d%20%20%e2%80%a2%20%20%20%5b%2fB%5d%5b%2fCOLOR%5d%5bCOLOR%20turquoise%5d%5bB%5d90%27s%20MOVIES%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fhitflix.tv%2faddon%2fmov%2fcf%2ffor%2f90s.xml',1,ART+'ak.png',ART+'movies.jpg')
    addDir('Imdb Top Movies','plugin://plugin.video.dandymedia/?fanart=https%3a%2f%2fraw.githubusercontent.com%2fdandy0850%2fiStream%2fmaster%2fScreenshot_2.jpg&mode=1&name=%5bB%5d%5bCOLOR%20hotpink%5dIMDB%20Top%20Movies%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2fbit.ly%2f1XrafLL',1,ART+'imdbd.jpg',ART+'movies.jpg')
	
def womenmovies():
    addDir('Her Alpha','plugin://plugin.video.AlphaMovies/?fanart&mode=1&name=%5bCOLOR%20lawngreen%5d%5bB%5dHer%20Alpha%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2falphaaddon.co.uk%2fthealpha%2fheralpha-v2%2fheralpha.txt',1,ART+'her.jpg',ART+'movies.jpg')
    addDir('Her Place Phoenix','plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fherplace.offshorepastebin.com%2fmaindir%2fmain.xml',1,ART+'herplace.jpg',ART+'movies.jpg')
	
def vodall():
    addDir('Vod il','plugin://plugin.video.Vodil',1,ART+'vodil.png',ART+'vod.jpg')
    addDir('רשת','plugin://plugin.video.reshet.video/?category=14830',1,ART+'reshet.png',ART+'vod.jpg')	
    addDir('מאקו','plugin://plugin.video.MakoTV',1,ART+'mako.png',ART+'vodjpg') 
    addDir('הוט','plugin://plugin.video.hotVOD.video',1,ART+'hot.png',ART+'vod.jpg')
    addDir('ערוץ 10','plugin://plugin.video.tenil',1,ART+'tenil.png',ART+'vod.jpg')
    addDir('ערוץ 1','plugin://plugin.video.IBA',1,ART+'iba.png',ART+'vod.jpg')
    addDir('ערוץ 20','plugin://plugin.video.iltwenty',1,ART+'tewnty.png',ART+'vod.jpg')
    addDir('וואלה','plugin://plugin.video.wallaNew.video',1,ART+'walla.png',ART+'vod.jpg')
    addDir('חינוכית נוסטלגיה','plugin://plugin.video.nostalgia',1,ART+'nostal.png',ART+'vod.jpg')

def kids():
    addDir('Vod il kids','plugin://plugin.video.Vodil/?mode=12&name=%d7%99%d7%9c%d7%93%d7%99%d7%9d&url=url',1,ART+'vkids.jpg',ART+'kids.jpg')
    addDir('Kidsil','plugin://plugin.video.KIDSIL',1,ART+'kidsil.png',ART+'kids.jpg')	 
    addDir('Featherence Kids','plugin://plugin.video.featherence.kids',1,ART+'fdkids.png',ART+'kids.jpg')
    addDir('ילדודס','plugin://plugin.video.kodisraelkids',1,ART+'yeladudes.png',ART+'kids.jpg')
    addDir('סרטי אנימציה','סרטי אנימציה',39,ART+'animation-icon.png',ART+'kids.jpg')
    addDir('וואלה ילדים','plugin://plugin.video.wallaNew.video/?mode=1&module=wallavod&name=%d7%99%d7%9c%d7%93%d7%99%d7%9d&url=englishName%3dkids',1,ART+'walla.png',ART+'kids.jpg')
    addDir('הוט ילדים','plugin://plugin.video.hotVOD.video/?mode=5&name=%20HOT%20VOD%20YOUNG&url=http%3a%2f%2fhot.ynet.co.il%2fhome%2f0%2c7340%2cL-7449%2c00.html',1,ART+'hot.png',ART+'kids.jpg')
    addDir('מאקו קלטות ילדים','plugin://plugin.video.MakoTV/?iconimage=http%3a%2f%2fimg.agora.co.il%2fdeals_images%2f2013-08%2f936426.jpg&mode=0&name=%d7%a7%d7%9c%d7%98%d7%95%d7%aa%20%d7%99%d7%9c%d7%93%d7%99%d7%9d&url=http%3a%2f%2fwww.mako.co.il%2fmako-vod-kids',1,ART+'mako.png',ART+'kids.jpg')
    addDir('מאקו תכניות ילדים','plugin://plugin.video.MakoTV/?iconimage=http%3a%2f%2fnow.tufts.edu%2fsites%2fdefault%2ffiles%2f111116_kids_TV_illo_L.JPG&mode=0&name=%d7%aa%d7%9b%d7%a0%d7%99%d7%95%d7%aa%20%d7%99%d7%9c%d7%93%d7%99%d7%9d&url=http%3a%2f%2fwww.mako.co.il%2fmako-vod-kids',1,ART+'mako.png',ART+'kids.jpg')	

def tv():
    addDir2('ספריית סדרות','ספריית סדרות',57,ART+'wiz.png',ART+'tvshows.jpg')
    addDir('Exodus','plugin://plugin.video.exodus/?action=tvNavigator',55,ART+'exodus.png',ART+'tvshows.jpg')
    addDir('Specto','plugin://plugin.video.specto/?action=tvNavigator',1,ART+'specto.png',ART+'tvshows.jpg')
    addDir('Salts','plugin://plugin.video.salts/?mode=browse&section=TV',1,ART+'salts.png',ART+'tvshows.jpg')
	
def movieslb():
    addDir('סרטים שנוספו לאחרונה','videodb://recentlyaddedmovies',1,ART+'wiz.png',ART+'movies.jpg')
    addDir('סרטים לפי כותרת','videodb://movies/titles',1,ART+'wiz.png',ART+'movies.jpg')
    addDir('סרטים לפי שנה','videodb://movies/years',1,ART+'wiz.png',ART+'movies.jpg')
    addDir('סגנונות','videodb://movies/genres',1,ART+'wiz.png',ART+'movies.jpg')
    addDir('הגדרת קיר סרטים וסדרות','plugin://plugin.video.thewiz.wall',1,ART+'wiz.png',ART+'movies.jpg')

def tvlb():
    addDir('פרקים שנוספו לאחרונה','videodb://recentlyaddedepisodes/306',1,ART+'wiz.png',ART+'tvshows.jpg')
    addDir('כל הסדרות','videodb://tvshows/titles',1,ART+'wiz.png',ART+'tvshows.jpg')
    addDir('סדרות לפי שנה','videodb://tvshows/years',1,ART+'wiz.png',ART+'tvshows.jpg')
    addDir('סגנונות','videodb://tvshows/genres',1,ART+'wiz.png',ART+'tvshows.jpg')
    addDir('הגדרת קיר סרטים וסדרות','plugin://plugin.video.thewiz.wall',1,ART+'wiz.png',ART+'tvshows.jpg')	

def addons():
    addDir('הרחבות וידאו','library://video/addons.xml',1,ART+'movie-icon.png',ART+'video.jpg')
    addDir('הרחבות תוכנות','addons://sources/executable',1,ART+'Settings-icon.png',ART+'software.jpg')
    addDir('הרחבות מוזיקה','addons://sources/audio',1,ART+'Music-icon.png',ART+'music.jpg')
    addDir('מאגרי רפו','addons://repos',1,ART+'Movies-icon.png',ART+'addons.jpg')
    addDir('הרחבות','הרחבות',59,ART+'Movies-icon.png',ART+'addons.jpg')
    addDir('הוספת מקור מכתובת','הוספת מקור מכתובת',60,ART+'Movies-icon.png',ART+'filesmanager.jpg')
    addDir('עדכון הרחבות','plugin://plugin.program.senyortools/?url=url&mode=92',1,ART+'updates.jpg',ART+'filesmanager.jpg')

def system():
    addDir('הגדרות מערכת','הגדרות מערכת',62,ART+'Settings-icon.png',ART+'settings.jpg')
    addDir('סניור טולס','plugin://plugin.program.senyortools',1,ART+'tools.png',ART+'settings.jpg')	
	
def livetvs():
    addDir('טלוויזיה חיה','טלוויזיה חיה',63,ART+'televiz.png',ART+'livetv.jpg')
    addDir('ערוצים חיים Televiz','plugin://plugin.video.anarchitv',1,ART+'televiz.png',ART+'livetv.jpg')
    addDir('ערוצים חיים Israelive','plugin://plugin.video.israelive',1,ART+'ilive.png',ART+'livetv.jpg')	
    addDir('ערוצים מישראל','plugin://plugin.video.israelive/?categoryid=9999&description&displayname=10065&iconimage=http%3a%2f%2fftp5.bizportal.co.il%2fweb%2fgiflib%2fnews%2fidan_plus_gay.jpg&mode=2&name=%5bCOLOR%20blue%5d%5bB%5d%5bIsrael%5d%5b%2fB%5d%5b%2fCOLOR%5d&url',1,ART+'ilive.png',ART+'livetv.jpg')
    addDir('ערוצים לפי ארצות','plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fcrusader88.offshorepastebin.com%2fCrusaderStreams%2fCountries%2fmain2.xml',1,ART+'cruseder.jpg',ART+'livetv.jpg')	
    addDir('Phoenix Tv','plugin://plugin.video.phstreams/?action=directory&content=0&url=http%3a%2f%2fphoenixtv.offshorepastebin.com%2ftv%2fmain.xml',1,ART+'fontv.jpg',ART+'livetv.jpg')
    addDir('Ccloud Tv','plugin://plugin.video.ccloudtv',1,ART+'ccloud.png',ART+'livetv.jpg')
    addDir('Evolve Golaith Tv','plugin://plugin.video.Evolve/?description&fanart=http%3a%2f%2fwww.matsbuilds.uk%2fpics%2fevolve%2ffanart.jpg&mode=1&name=%5bB%5d%5bCOLOR%20red%5dL%5b%2fCOLOR%5d%5bCOLOR%20white%5dive%5b%2fCOLOR%5d%20%5bCOLOR%20red%5dT%5b%2fCOLOR%5d%5bCOLOR%20white%5dV%5b%2fCOLOR%5d%20%20%20%20%20%20%20%5bCOLOR%20red%5dUpdated%20-%2027%2f08%2f16%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2fwww.matsbuilds.uk%2fGoliathLists%2flivetv1.xml',1,ART+'golyat.jpg',ART+'livetv.jpg')	
    addDir('Filmon.tv','plugin://plugin.video.F.T.V',1,ART+'filmon.jpg',ART+'livetv.jpg')	

def docu():
    addDir('Decado Documentary','plugin://plugin.video.DecadoDocs',1,ART+'decado.png',ART+'sciencenature.jpg')
    addDir('Brettus Documentary','plugin://plugin.video.Brettus.Documentaries',1,ART+'brettus.png',ART+'sciencenature.jpg')	 
    addDir('documentarytube','plugin://plugin.video.documentarytube',1,ART+'documentarytube.png',ART+'sciencenature.jpg')
    addDir('featherence docu','plugin://plugin.video.featherence.docu',1,ART+'featherencedocu.png',ART+'sciencenature.jpg')
    addDir('ערוצים חיים ישראלייב','plugin://plugin.video.israelive/?categoryid=9999&description&displayname=10451&iconimage=http%3a%2f%2fwallpapers.free-review.net%2fwallpapers%2f23%2fNature_-_Wallpaper_for_Windows_7.jpg&mode=2&name=%5bCOLOR%20blue%5d%5bB%5d%5bScience%20%26%20nature%20-%20%d7%9e%d7%93%d7%a2%20%d7%95%d7%98%d7%91%d7%a2%5d%5b%2fB%5d%5b%2fCOLOR%5d&url',1,ART+'ilive.png',ART+'sciencenature.jpg')
    addDir('ערוצים חיים Ccloud','plugin://plugin.video.ccloudtv/?iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.ccloudtv%5cresources%2ficons%2f%2fdocumentary.png&mode=54&name=%5bCOLOR%20white%5dDocumentary%5b%2fCOLOR%5d&url=documentary',1,ART+'ccloud.png',ART+'sciencenature.jpg')	
    addDir('Evolve Goliath Doku','plugin://plugin.video.Evolve/?description&fanart=http%3a%2f%2fwww.matsbuilds.uk%2fpics%2fevolve%2ffanart.jpg&mode=1&name=%5bB%5d%5bCOLOR%20red%5dD%5b%2fCOLOR%5d%5bCOLOR%20white%5documentaries%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2fpastebin.com%2fraw%2fbAd5cCRm',1,ART+'golyat.jpg',ART+'sciencenature.jpg')	

def music():
    addDir('מוזיקה Vod il','plugin://plugin.video.Vodil/?mode=13&name=%d7%9e%d7%95%d7%96%d7%99%d7%a7%d7%94&url=url',1,ART+'vodilmusic.jpg',ART+'music.jpg')
    addDir('99fm playlists','plugin://plugin.audio.99fm-playlists',1,ART+'nine.png',ART+'music.jpg')
    addDir('featherence music','plugin://plugin.video.featherence.music',1,ART+'fdkids.png',ART+'music.jpg')		
    addDir('jango','plugin://plugin.audio.jango',1,ART+'jango.png',ART+'music.jpg')
    addDir('kmusictube','plugin://plugin.video.kmusictube/?content_type=audio',1,ART+'kmusictube.png',ART+'music.jpg')
    addDir('The Music Source','plugin://plugin.video.The-Music-Source',1,ART+'tmso.png',ART+'music.jpg')	
    addDir('wildhitz','plugin://plugin.video.wildhitz',1,ART+'wildhitz.png',ART+'music.jpg')
    addDir('The Jukbox','plugin://plugin.video.TheJukeBox',1,ART+'tjbox.png',ART+'music.jpg')
    addDir('הופעות חיות alive hd','plugin://plugin.video.alive.hd',1,ART+'alivehd.png',ART+'music.jpg')	
    addDir('הופעות חיות Vod il','plugin://plugin.video.Vodil/?mode=16&name=%d7%94%d7%95%d7%a4%d7%a2%d7%95%d7%aa%20%d7%97%d7%99%d7%95%d7%aa&url=url',1,ART+'liveshow.jpg',ART+'music.jpg')
    addDir('קריוקי','plugin://plugin.video.Karaokeil',1,ART+'Karaokeil.png',ART+'music.jpg')
    addDir('merlin radio','plugin://plugin.audio.merlinradio',1,ART+'merlinr.png',ART+'music.jpg')	
    addDir('רדיו ישראלייב','plugin://plugin.video.israelive/?categoryid=9999&description&displayname=10000&iconimage=http%3a%2f%2fmdmorrope.gob.pe%2fportalweb%2fimagenes%2fradioss.png&mode=2&name=%5bCOLOR%20blue%5d%5bB%5d%5bRadio%20From%20Israel%20-%20%d7%a8%d7%93%d7%99%d7%95%5d%5b%2fB%5d%5b%2fCOLOR%5d&url',1,ART+'ilive.png',ART+'music.jpg')	
	
def meta():
    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.program.meta_search/?content_type=video)")
	
def browaddons():
    xbmc.executebuiltin("ActivateWindow(AddonBrowser)")
	
def addsource():
    xbmc.executebuiltin("ActivateWindow(FileManager)")

def setti():
    xbmc.executebuiltin("ActivateWindow(Settings)")	
	
def exodus():
    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.exodus/?action=searchNavigator)")
	
def exodustv():
    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.exodus/?action=tvNavigator)")		
	
def exodusmovies():
    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.exodus/?action=movieNavigator)")	

def exoduskids():
    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.exodus/?action=movies&amp;url=http%3a%2f%2fwww.imdb.com%2fsearch%2ftitle%3ftitle_type%3dfeature%2ctv_movie%26languages%3den%26num_votes%3d100%2c%26release_date%3ddate%5b730%5d%2cdate%5b30%5d%26genres%3danimation%26sort%3dmoviemeter%2casc%26count%3d40%26start%3d1&quot)")	

def Favourites():
    xbmc.executebuiltin("ActivateWindow(Favourites)")	
	
def livepvr():
    xbmc.executebuiltin("ActivateWindow(MyPVR)")		
	
def metasearch(url):
    ok=True        
    xbmc.executebuiltin('XBMC.Container.Update(%s)' % url )
    return ok  		

def addDir(name,url,mode,iconimage,fanart):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        

def addDir2(name, url, mode, iconimage, fanart):
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		u = 'plugin://plugin.video.youtube/%s/%s/' % (url.split( '/' )[-2], url.split( '/' )[-1])
		ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
		return ok		
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok		

	
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None



try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:     
		repoinstall()
		main()
       
elif mode==1:
        metasearch(url)
        
elif mode==2:
        globalsearch(url)
		
elif mode==3:
        meta()	

elif mode==4:
        salts()

elif mode==5:
        exodus()

elif mode==8:
        Favourites()

elif mode==9:
        movies()	

elif mode==10:
        tv()			

elif mode==11:
        livetvs()	
		
elif mode==12:
        docu()	

elif mode==13:
        kids()	

elif mode==14:
        vod()

elif mode==15:
        music()

elif mode==16:
        hdmovies()

elif mode==17:
        exodusmovies()

elif mode==20:
        multyaddons()

elif mode==26:
        Vodil()

elif mode==33:
        vodall()		
		
elif mode==39:
        exoduskids()

elif mode==50:
        dmovies()

elif mode==51:
        fourk()

elif mode==52:
        boxsets()

elif mode==53:
        chits()

elif mode==54:
        womenmovies()

elif mode==55:
        exodustv()

elif mode==56:
        movieslb()	

elif mode==57:
        tvlb()

elif mode==58:
        addons()

elif mode==59:
        browaddons()		

elif mode==60:
        addsource()
		
elif mode==61:
        system()

elif mode==62:
        setti()

elif mode==63:
        livepvr()		
		
xbmcplugin.endOfDirectory(int(sys.argv[1]))

