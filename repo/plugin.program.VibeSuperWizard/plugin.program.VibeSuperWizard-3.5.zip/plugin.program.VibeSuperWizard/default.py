# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import requests
import os
import sys
import shutil
import urllib2
import urllib
import re
import time
import zipfile
import ntpath
import plugintools
import socket
import sqlite3
import json
import constants as const
import webhelpers as wh
import servicemanager as sm
import base64
import vibeutils
import extentions as ext

def get_params():
        param = []
        paramstring = sys.argv[2]
        if len(paramstring) >= 2:
                params = sys.argv[2]
                cleanedparams = params.replace('?','')
                if (params[len(params) - 1] == '/'):
                        params = params[0:len(params) - 2]
                pairsofparams = cleanedparams.split('&')
                param = {}
                for i in range(len(pairsofparams)):
                        splitparams = {}
                        splitparams = pairsofparams[i].split('=')
                        if (len(splitparams)) == 2:
                                param[splitparams[0]] = splitparams[1]
                                
        return param
                      
params = get_params()
url = None
name = None
mode = None
iconimage = None
fanart = None
description = None


try:
        url = urllib.unquote_plus(params["url"])
except:
        pass
try:
        name = urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage = urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode = int(params["mode"])
except:
        pass
try:        
        fanart = urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description = urllib.unquote_plus(params["description"])
except:
        pass

if mode == None or url == None or len(url) < 1:
    vibeutils.init()

if mode == 10:
       vibeutils.BUILDMENU('advancedsettings')

if mode == 11:
       vibeutils.BUILDMENU('rss')
        
if mode == 12:
       vibeutils.BUILDMENU('addonsettings')

if mode == 13:
       vibeutils.BUILDMENU('builds')

if mode == 80:
    ext.Deploy_Package(name,url,description)

if mode==83:
    ext.Deploy_RSS(name,url,description)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

if mode == 100:
    vibeutils.buildMaintenanceMenue()

if mode==101:
    vibeutils.ThemesMenu()
 
if mode==114:
    ext.Clear_Thumbnails()

if mode==113:
    ext.Clear_Packages_Cache_With_Confitm()

if mode==112:
    ext.Clear_Cache()     

if mode == 17:
       ext.Send_LOG()

if mode == 20:
       ext.WhatIsMyIp()

if mode == 21:
       ext.AdvacnedSetting()

if mode == 111:
    ext.Fresh_Start(True)

if mode == 80:
    ext.Deploy_Addon_Settings(name,url,description)

if mode == 82:
    ext.wizard(name,url,description)

if mode==84:
    ext.Install_Addon(url)

#Service Manager
#get list of service adddons
if mode == 110:
    sm.listAddons()

#enable or disable autorun
if mode == 1:
    sm.changeState(name,url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))