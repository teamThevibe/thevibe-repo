import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui

def log(message): xbmc.log(message) # Write something on XBMC log
