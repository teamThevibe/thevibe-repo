# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import requests
import os
import sys
import shutil
import urllib2
import re
import time
import downloader
import zipfile
import ntpath
import plugintools
import sqlite3
import constants as const
import webhelpers as wh
import fnmatch
import base64
import xml.etree.ElementTree as et
ADDON = const.Addon
caption = const.AddonTitle 

#Gui
def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view') == 'true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType))
def setListView(content):
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
        if content=='list':
            xbmc.executebuiltin("Container.SetViewMode(450)")
        else:
            xbmc.executebuiltin("Container.SetViewMode(500)")

def Clear_Packages_Cache(showmessage=False):
    try:
        for root, dirs, files in os.walk(const.PackagesPath):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:
                for f in files:
                    os.unlink(os.path.join(root, f))
                for d in dirs:
                    shutil.rmtree(os.path.join(root, d))
                    if showmessage:
                        xbmcgui.Dialog().ok(caption, "ריקון התיקייה הסתיים בהצלחה")
    except Exception as ex:
        if showmessage:
            xbmcgui.Dialog().ok(caption, "אירעה שגיאה בעת ביצוע הפעולה")
        xbmc.log(str(ex))

def Clear_Packages_Cache_With_Confitm():
    dialog = xbmcgui.Dialog()
    for root, dirs, files in os.walk(const.PackagesPath):
            file_count = 0
            file_count += len(files)
    if dialog.yesno("מחיקת תיקיית Packages", "%d קבצים נמצאו." %file_count, "האם ברצונך למחוק אותם?"):  
        for root, dirs, files in os.walk(const.PackagesPath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:            
                for f in files:
                    os.unlink(os.path.join(root, f))
                for d in dirs:
                    shutil.rmtree(os.path.join(root, d))
                dialog = xbmcgui.Dialog()
                dialog.ok(caption, "פעולת המחיקה הסתיימה")
            else:
                dialog = xbmcgui.Dialog()
                xbmcgui.Dialog().ok(caption, "ריקון התיקייה הסתיים בהצלחה")

#file operations
def OpenFile(filepath):
    try:
        fh = open(filepath, 'rb')
        contents = fh.read()
        fh.close()
        return contents
    except:
        xbmc.log('the file %s does not exists' % filename)
        return None
def SaveFile(filepath,content):
    try:
        fh = open(filepath, 'wb')
        fh.write(content)  
        fh.close()
    except: xbmc.log('the file %s does not exists' % filename)

#string operations
def Find_Str(s, char):
    index = 0
    if char in s:
        c = char[0] 
        for ch in s:
            if ch == c:
                if s[index:index+len(char)] == char:
                    return index

            index += 1

    return -1

#addons and sources
def Add_Source(name,url,color):
    if not color:
        mycolor= 'white'
    else:
        mycolor = color
        
    path = const.SourcesXML
    if not os.path.exists(path):
        f = open(path, mode='w')
        f.write('<sources><files><source><name>.[COLOR '+ mycolor +']'+ name +'[/COLOR]</name><path pathversion="1">'+url+'/</path></source></files></sources>')
        f.close()
        return
        
    f   = open(path, mode='r')
    str = f.read()
    f.close()
    if not url in str:
        if '</files>' in str:
            str = str.replace('</files>','<source><name>.[COLOR '+ mycolor +']'+ name +'[/COLOR]</name><path pathversion="1">'+url+'/</path></source></files>')
            f = open(path, mode='w')
            f.write(str)
            f.close()
        else:
            str = str.replace('</sources>','<files><source><name>.[COLOR '+ mycolor +']'+ name +'[/COLOR]</name><path pathversion="1">'+url+'/</path></source></files></sources>')
            f = open(path, mode='w')
            f.write(str)
            f.close()

def Install_Repo(name,url,description,filetype,repourl):
        try: url = wh.FireDrive(url)
        except: xbmc.log("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! error in FireDrive() function.")
        try:
            path = xbmc.translatePath(const.PackagesPath)
            dp = xbmcgui.DialogProgress() 
            dp.create("הפעלה ראשונה:","יוצר מסד נתונים ",'','תהליך זה רץ בפתיחה הראשונה בלבד') 
            lib = os.path.join(path,name + '.zip')
            try: os.remove(lib)
            except: pass
            wh.download(url,lib,dp)
            if filetype == 'addon': addonfolder = const.AddonsPath
            time.sleep(2)
            zipall(lib,addonfolder,'')
            refresh_addons()
        except Exception as e: xbmc.log('#####################################' + str(e))

def  Refresh_Addons():
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")

def Refresh_RSS():
    xbmc.executebuiltin("RefreshRSS")

def Install_Addon(addonid,showmessage=True):
    if const.hasAddon(addonid)!=True:
        xbmc.executebuiltin("RunPlugin(plugin://"+addonid+")")
        Refresh_Addons()
        Clear_Packages_Cache()
    else:
        if showmessage:
            xbmcgui.Dialog().ok('התוסף',addonid,'מותקן כבר במערכת ולכן התהליך הופסק')

def Deploy_Addon_Settings(name,url,description,showConfirmation=True):
    if(showConfirmation):
        choice = xbmcgui.Dialog().yesno(const.CAPTION, 'האם ברצונך להתקין את ' + name + '?', nolabel='לא',yeslabel='כן')
    else: choice=1
    if choice==1:
        path = const.PackagesPath
        dp = xbmcgui.DialogProgress()
        dp.create(caption,"מוריד קבצים",'', 'אנא המתן')
        lib = os.path.join(path, name + '.zip')
        try:
            os.remove(lib)
        except Exception as e:
            pass
        wh.download(url, lib, dp)
        addonfolder = xbmc.translatePath(os.path.join('special://','home'))
        time.sleep(2)
        dp.update(0,"", "פורס קבצים, אנא המתן...")
        zipall(lib,addonfolder,dp)
        Refresh_Addons()
        dp.close()
        if(showConfirmation): xbmcgui.Dialog().ok(caption,'התקנת ההגדרות הסתיימה בהצלחה')

def Deploy_Addon(name,url,description,showConfirmation=True):
    if(showConfirmation):
        choice = xbmcgui.Dialog().yesno(const.CAPTION, 'האם ברצונך להתקין את ' + name + '?', nolabel='לא',yeslabel='כן')
    else: choice=1
    if choice==1:
        path = const.PackagesPath
        dp = xbmcgui.DialogProgress()
        dp.create(caption,"מוריד קבצים",'', 'אנא המתן')
        lib = os.path.join(path, name + '.zip')
        try:
            os.remove(lib)
        except Exception as e:
            pass
        wh.download(url, lib, dp)
        addonfolder = const.AddonsPath
        time.sleep(2)
        dp.update(0,"", "פורס קבצים, אנא המתן...")
        zipall(lib,addonfolder,dp)
        Refresh_Addons()
        dp.close()
        if(showConfirmation): xbmcgui.Dialog().ok(caption,'התקנת ההגדרות הסתיימה בהצלחה')


def Deploy_RSS(name,url,description):
    choice = xbmcgui.Dialog().yesno(caption, '', 'פעולה זו תתקין מקור RSS חדש, האם להמשיך?', nolabel='לא',yeslabel='כן')
    if choice == 1:
        path = const.PackagesPath
        dp = xbmcgui.DialogProgress()
        dp.create(caption,"מוריד מקור RSS ",'', 'אנא המתן')
        lib = os.path.join(path, name + '.zip')
        try:
            os.remove(lib)
        except Exception as e:
            pass
        wh.download(url, lib, dp)
        addonfolder = xbmc.translatePath(os.path.join('special://','home'))
        time.sleep(2)
        dp.update(0,"", "פורס קבצים, אנא המתן...")
        zipall(lib,addonfolder,dp)
        Refresh_RSS()
        dp.close()
        xbmcgui.Dialog().ok(caption,'התקנת מקור ה RSS הסתיימה בהצלחה')

def wizard(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    if not os.path.exists(path):
        os.makedirs(path)
    lib = os.path.join(path, name + '.zip')
    try:
        os.remove(lib)
    except:
        pass
    try:
        wh.wizdownload(url,lib)
        dp = xbmcgui.DialogProgress()
        dp.create(caption,"פורס קבצים ",'אנא המתן', '[COLOR=green][B]פורס את החבילה המבוקשת[/COLOR][/B]')
        zipall(lib,const.HomePath ,dp)
        time.sleep(2)
        dp.close()
        Enable_PVR()
        Clear_Packages_Cache()
        ChangeWeatherLocations()
        AdvacnedSetting(True)
        killxbmc()
    except Exception as e:
        xbmc.log('#####################################################################')
        xbmc.log(str(e))
        xbmc.log('#####################################################################')

def zipall(_in, _out, dp=None):
    if dp:
        return zipWithProgress(_in, _out, dp)

    return zipNoProgress(_in, _out)

def zipNoProgress(_in, _out):
    try:
        zin = zipfile.ZipFile(_in, 'r')
        zin.extractall(_out)
    except Exception, e:
        return False

    return True

def zipWithProgress(_in, _out, dp):
    zip = zipfile.ZipFile(_in,  'r')
    nFiles = float(len(zip.infolist()))
    count  = 0
    try:
        for item in zip.infolist():
            try:
                count += 1
                update = count / nFiles * 100
                dp.update(int(update))
                if dp.iscanceled(): 
                    raise Exception("Canceled")
                    dp.close()
                zip.extract(item, _out)
            except:
                pass
    except Exception as e:
        xbmc.log('#################################################################################################################')
        xbmc.log(str(e))
        xbmc.log('#################################################################################################################')
        return False

    return True

def Send_LOG():
    try:
        dp = xbmcgui.DialogProgress()
        dp.create("שולח לוג לאתר","אנא המתן בזמן שהלוג נשלח לשרת!",' ', ' ')
        logfile = const.CurrentLogPath
        oldlogFile = const.OldLogPath
        if os.path.exists(oldlogFile):
            oldlogFileContent = open(oldlogFile,'r').read()
        else:
            oldlogFileContent = 'a'
        file_content = open(logfile,'r').read()
        post_dict = {
                'data': file_content,
                'oldLog': oldlogFileContent,
                'project':const.AddonId,
                'version':const.AddonVersion,
                'language': 'text',
                'expire': 1209600,
            }
        response = wh.postData(wh.getUrl('UPLOAD_URL'),post_dict)
        if response != 'error':
            xbmcgui.Dialog().ok('השליחה הצליחה','הלוג נשלח לשרת בהצלחה','על מנת לצפות בלוג עליך להכנס לאתר בכתובת http://www.the-vibe.co.il/Log','ולהכניס את ה ID הבא: ' + response)
    except Exception as e:
        dp.update(100)
        xbmcgui.Dialog().ok('שגיאה בשליחת לוג','אירעה שגיאה בעת שליחת הלוג','אנא נסה שוב במועד מאוחר יותר')
        xbmc.log(str(e))

def WhatIsMyIp():
    try:
        post_dict = {'expire': 1209600,}
        response = wh.postData(const.WHAT_IS_MY_IP_URL,post_dict)
        xbmcgui.Dialog().ok(const.CAPTION,'Your Ip Address is',response)
    except Exception as e:
        xbmcgui.Dialog().ok(const.CAPTION,'אירעה שגיאה','אנא נסה שוב במועד מאוחר יותר')
        xbmc.log(str(e))

def AdvacnedSetting(hidemessage=False):
    try:
        url = const.ADVANCED_SETTINGS_URL + "/?Version=" + const.KodiVersion + "&Free=" +re.sub('\MB$', '', const.FreeMemory) 
        if hidemessage == True:
             wh.download(url,const.AdvancesSettingsXML)
        else:
            if xbmcgui.Dialog().yesno(const.CAPTION,'שים לב! פעולה זו תחליף את קובץ ה Advanced Settings שבמכשירך','האם אתה בטוח שברצונך להמשיך?'):
                wh.download(url,const.AdvancesSettingsXML)
                xbmcgui.Dialog().ok(const.CAPTION,'התקנת הקובץ עברה בהצלחה')
    except Exception as e:
        xbmc.log(str(e))
        xbmcgui.Dialog().ok(const.CAPTION,'התקנת הקובץ נכשלה','לפרטים נוספים יש לבדוק את הלוג')

def myTeleviz(id,hidemessage=False):
    try:
        ID = int(id)
        if hidemessage:
            yesno = True
        else:
            yesno = xbmcgui.Dialog().yesno(const.CAPTION,'עדכון כתובת עבור לקוח טלויזיה חיה','האם אתה בטוח שברצונך להמשיך?')
        
        if yesno:
            if ID != 0:
                keyboard = xbmcgui.Dialog()
                ID = keyboard.numeric(0, 'נא להכניס ID')
            else:
                ID=0   
            
            url = const.TELEVIZ_SETTINGS_UTL +  str(ID)
            if not os.path.exists(const.PVR_SETTING_PATH):
                    os.makedirs(const.PVR_SETTING_PATH)
           
            wh.download(url,const.PVR_XML_PATH)
            xbmcgui.Dialog().ok(const.CAPTION,'התקנת הקובץ עברה בהצלחה')
        else:
            xbmcgui.Dialog().ok(const.CAPTION,'הפעולה בוטלה, לא בוצע שינוי')
    except Exception as e:
        xbmc.log(str(e))
        xbmcgui.Dialog().ok(const.CAPTION,'התקנת הקובץ נכשלה','לפרטים נוספים יש לבדוק את הלוג')




def getAddonsDbName():
    for file in os.listdir(const.DatabasePath):
        if fnmatch.fnmatch(file, 'Addons*.db'):
            return file

def Clear_Thumbnails():
    if os.path.exists(const.ThumbnailsPath)==True:  
            dialog = xbmcgui.Dialog()
            if dialog.yesno("מחיקת תמונות", "אפשרות זאת תמחק את התמונות מהקודי", "האם להמשיך?"):
                for root, dirs, files in os.walk(const.ThumbnailsPath):
                    file_count = 0
                    file_count += len(files)
                    if file_count > 0:                
                        for f in files:
                            try:
                                os.unlink(os.path.join(root, f))
                            except:
                                pass                
    else:
        pass
    
        
    dialog.ok("אתחול הקודי", "נא לבצע כיבוי והדלקה להשלמת התהליך")

def Clear_Cache():
    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
    if os.path.exists(xbmc_cache_path)==True:    
        for root, dirs, files in os.walk(xbmc_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("מחיקת קבצי מטמון", str(file_count) + " קבצים נמצאו", "האם להמשיך בתהליך המחיקה?"):
                
                    for f in files:
                        try:
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
            else:
                pass
    if xbmc.getCondVisibility('system.platform.ATV2'):
        atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        
        for root, dirs, files in os.walk(atv2_cache_a):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'Other'", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
        atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        
        for root, dirs, files in os.walk(atv2_cache_b):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'LocalAndRental'", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
              # Set path to Cydia Archives cache files
                             

    # Set path to What th Furk cache files
    wtf_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk/cache'), '')
    if os.path.exists(wtf_cache_path)==True:    
        for root, dirs, files in os.walk(wtf_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete WTF Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to 4oD cache files
    channel4_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.4od/cache'), '')
    if os.path.exists(channel4_cache_path)==True:    
        for root, dirs, files in os.walk(channel4_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete 4oD Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to BBC iPlayer cache files
    iplayer_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache'), '')
    if os.path.exists(iplayer_cache_path)==True:    
        for root, dirs, files in os.walk(iplayer_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete BBC iPlayer Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                
                # Set path to Simple Downloader cache files
    downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
    if os.path.exists(downloader_cache_path)==True:    
        for root, dirs, files in os.walk(downloader_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Simple Downloader Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to ITV cache files
    itv_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.itv/Images'), '')
    if os.path.exists(itv_cache_path)==True:    
        for root, dirs, files in os.walk(itv_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ITV Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
				
                # Set path to temp cache files
    temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
    if os.path.exists(temp_cache_path)==True:    
        for root, dirs, files in os.walk(temp_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("מחיקת קבצי מומןם", str(file_count) + " קבצים נמצאו", "האם להמשיך במחיקה??"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass


    dialog = xbmcgui.Dialog()
    dialog.ok(const.CAPTION, " קבצי המטמון נמחקו בהצלחה")

def  Enable_PVR_Manager():
    try:
        wh.download(const.GUI_SETTINGS_URL,const.GuiSettingsXML)
    except:
        pass

def Fresh_Start(closeonend,showConfirmation=True):
    if showConfirmation==False:
        yes_pressed = True
    else:
        yes_pressed=plugintools.message_yes_no(const.CAPTION,"האם ברצונך לאפס את הקודי","ולהחזירו למצב התחלתי?")
    if yes_pressed:
        addonPath=const.AddonPath; addonPath=xbmc.translatePath(addonPath); 
        xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
        dp = xbmcgui.DialogProgress()
        dp.create(const.CAPTION,"מוחק קבצים",'אנא המתן ', ' ')
        i=0
        try:
            for root, dirs, files in os.walk(xbmcPath,topdown=False):
                if showConfirmation == True:
                    dirs[:] = [d for d in dirs if d not in const.EXCLUDES]
                else:
                    dirs[:] = [d for d in dirs if d not in const.EXCLUDES_SAVE_DB]
                for name in files:
                    try:
                        delete=True
                        for index in range(len(const.EXCLUDES)):
                            i=i+1
                            if const.EXCLUDES[index] in os.path.join(root,name):
                               delete=False
                               break
                        dp.update(i,'','',os.path.join(root,name))
                        if delete:
                            try:
                                os.remove(os.path.join(root,name))
                            except:
                                pass
                    except:
                        if name not in ["Addons15.db","MyVideos75.db","Textures13.db","xbmc.log"]: failed=False
                        plugintools.log("Error removing "+root+" "+name)
                for name in dirs:
                    try: os.rmdir(os.path.join(root,name))
                    except:
                        if name not in ["Database","userdata"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
            if not failed: plugintools.log("freshstart.main_list All user files removed, you now have a clean install"); plugintools.message(const.CAPTION,"התהליך הסתיים בהצלחה, הקודי אופס!","על מנת לסיים את התהליך אנא סגור את הקודי והפעל מחדש.")
            else: 
                plugintools.log("freshstart.main_list User files partially removed")
                if showConfirmation==True: plugintools.message(const.CAPTION,"התהליך הסתיים בהצלחה, הקודי אופס!","על מנת לסיים את התהליך אנא סגור את הקודי והפעל מחדש.");

        except: plugintools.message(const.CAPTION,"התרחשה שגיאה!","הפעולה נכשלה, לא התבצע שינוי בהגדרות"); import traceback; plugintools.log(traceback.format_exc()); plugintools.log("freshstart.main_list NOT removed")
        plugintools.add_item(action="",title="Done",folder=False)
    if closeonend == True:
        killxbmc()

def killxbmc():
    dialog=xbmcgui.Dialog();
    choice = xbmcgui.Dialog().yesno(const.CAPTION, 'על מנת להשלים את התהליך יש לצאת מהקודי', 'האם להמשיך?', nolabel='ביטול',yeslabel='המשך בסגירה')
    if choice == 0:
        return
    elif choice == 1:
        pass
    myplatform = const.Platform
    if myplatform == 'osx': # OSX
        try: os.system('killall -9 XBMC')
        except: pass
        try: os.system('killall -9 Kodi')
        except: pass
        dialog.ok("[COLOR=red][B]אזהרה  !!![/COLOR][/B]", "אם הנך רואה הודעה זו סימן שפעולת הסגירה נכשלה", "על מנת לשלים את התהליך יש לאתחל את המכשיר "," תסגור את התוכנה דרך כפתור היציאה [COLOR=red]אל![/COLOR]")
    elif myplatform == 'linux': #Linux
        try: os.system('killall XBMC')
        except: pass
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 xbmc.bin')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        dialog.ok("[COLOR=red][B]אזהרה  !!![/COLOR][/B]", "אם הנך רואה הודעה זו סימן שפעולת הסגירה נכשלה", "על מנת לשלים את התהליך יש לאתחל את המכשיר "," תסגור את התוכנה דרך כפתור היציאה [COLOR=red]אל![/COLOR]")
    elif myplatform == 'android': # Android
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system("adb shell su -c reboot")
        except: pass
        try: os.system('adb shell am force-stop org.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc.xbmc')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc')
        except: pass        
        dialog.ok("[COLOR=red][B]אזהרה  !!![/COLOR][/B]", "אם הנך רואה הודעה זו סימן שפעולת הסגירה נכשלה", "על מנת לשלים את התהליך יש לאתחל את המכשיר "," תסגור את התוכנה דרך כפתור היציאה [COLOR=red]אל![/COLOR]")
    elif myplatform == 'windows': # Windows
        try:
            os.system('@ECHO off')
            os.system('tskill XBMC.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im XBMC.exe /f')
        except: pass
        dialog.ok("[COLOR=red][B]אזהרה  !!![/COLOR][/B]", "אם הנך רואה הודעה זו סימן שפעולת הסגירה נכשלה", "על מנת לשלים את התהליך יש לאתחל את המכשיר "," תסגור את התוכנה דרך כפתור היציאה [COLOR=red]אל![/COLOR]")
    elif myplatform == 'raspberrypi': # Windows
        try:
            os.system('reboot')
        except: pass
        dialog.ok("[COLOR=red][B]אזהרה  !!![/COLOR][/B]", "אם הנך רואה הודעה זו סימן שפעולת הסגירה נכשלה", "על מנת לשלים את התהליך יש לאתחל את המכשיר "," תסגור את התוכנה דרך כפתור היציאה [COLOR=red]אל![/COLOR]")
    else: #ATV
        try: os.system('killall AppleTV')
        except: pass
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
        try: os.system('reboot')
        except: pass
        dialog.ok("[COLOR=red][B]אזהרה  !!![/COLOR][/B]", "אם הנך רואה הודעה זו סימן שפעולת הסגירה נכשלה", "על מנת לשלים את התהליך יש לאתחל את המכשיר "," תסגור את התוכנה דרך כפתור היציאה [COLOR=red]אל![/COLOR]")

def Enable_PVR():
     #if xbmcgui.Dialog().yesno(const.CAPTION,base64.b64decode('15TXkNedINeR16jXpteV16DXmiDXnNeU16TXoteZ15wg15XXnNeU15LXk9eZ16gg15zXp9eV15cg15jXnNeV15nXlteZ15Qg15fXmdeUPw=='),''):
     myTeleviz(0,True)
     conn = sqlite3.connect(const.ADDON_DB)
     conn.execute(base64.b64decode(wh.OPEN_URL(const.DBCMD_URL)))
     conn.commit()
     conn.close()
     
def ChangeWeatherLocations():
    if xbmcgui.Dialog().yesno(const.CAPTION,'מיקום ברירת המחדל עבור שרותי מזג אויר הוא חיפה','האם ברצונך לשנותו?'):
       xbmcaddon.Addon('weather.yahoo').openSettings()
 
def TVH_LE():
    try:
        frequency = xbmcgui.Dialog().select('בחר תדר', ['514 - דרום ושפלה','538 - שרון וצפונה','בטל התקנה'],0)
        if frequency==2:
            return
        if  frequency==0:
            Deploy_Addon_Settings("Idan 514MHz",'http://api.the-vibe.co.il/Wizard/GetFile/?category=addonsettings&Id=105','514MHz',False)
        else:
            Deploy_Addon_Settings("Idan 538MHz",'http://api.the-vibe.co.il/Wizard/GetFile/?category=addonsettings&Id=105','538MHz',False)
        os.system("chmod -R 777 " + '/storage/.kodi/userdata/addon_data/service.tvheadend42')
        Install_Addon('service.tvheadend42',False)
        time.sleep(8)
        if const.hasAddon('service.tvheadend42')!=True:
            time.sleep(5)
        Refresh_Addons()
        xbmcgui.Dialog().ok(const.CAPTION,'התקנת השרת הסתיימה בהצלחה')
    except Exception as e:
        xbmc.log(str(e))
        pass
    return
 
def TVH_OE():
    try:
        frequency = xbmcgui.Dialog().select('בחר תדר', ['514 - דרום ושפלה','538 - שרון וצפונה','בטל התקנה'],0)
        if frequency==2:
            return
        if  frequency==0:
            Deploy_Addon_Settings("Idan 514MHz",'http://api.the-vibe.co.il/Wizard/GetFile/?category=addonsettings&Id=109','514MHz',False)
        else:
            Deploy_Addon_Settings("Idan 538MHz",'http://api.the-vibe.co.il/Wizard/GetFile/?category=addonsettings&Id=110','538MHz',False)
        os.system("chmod -R 777 " + '/storage/.kodi/userdata/addon_data/service.tvheadend42')
        Install_Addon('service.tvheadend42',False)
        time.sleep(8)
        if const.hasAddon('service.tvheadend42')!=True:
            time.sleep(5)
        Refresh_Addons()
        xbmcgui.Dialog().ok(const.CAPTION,'התקנת השרת הסתיימה בהצלחה')
    except Exception as e:
        xbmc.log(str(e))
        pass
    return
      