# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import requests
import os
import sys
import shutil
import urllib2
import urllib
import re
import time
import ntpath
import plugintools
import constants as const
import extentions as ext

def listAddons():
      listServices('[COLOR blue][B]%s[/B][/COLOR]' % ('באפשרותך לנטרל את ההרחבות הבאות'),'no',None,os.path.join(xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('path')).decode('utf-8'),'icon.png'))
      addonspath = const.AddonsPath
      directories = os.listdir(addonspath)
      for adonname in directories:
            addonpath = os.path.join(addonspath, adonname)
            addonxmlfile = os.path.join(addonpath,'addon.xml')
            if os.path.exists(addonxmlfile):
                  content = ext.OpenFile(addonxmlfile)
                  if re.search('point="xbmc.service"',content):
                        listServices('%s (on)' % (adonname),addonpath,1,os.path.join(addonpath,'icon.png'))
                  elif re.search('point="xbmc.pass"',content):
                        listServices('[B][COLOR gold]%s[/B] (off)[/COLOR]' % (adonname),addonpath,1,os.path.join(addonpath,'icon.png'))
      ext.setListView('list')     

def listServices(name,url,mode,iconimage):
        u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
        liz = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)

def changeState(name,url):
      addonxmlfile = os.path.join(url,'addon.xml')
      content = ext.OpenFile(addonxmlfile)
      if re.search('COLOR gold',name): content = content.replace('point="xbmc.pass"','point="xbmc.service"')
      else: content = content.replace('point="xbmc.service"','point="xbmc.pass"')
      ext.SaveFile(addonxmlfile,content)
      xbmc.executebuiltin("Container.Refresh")
