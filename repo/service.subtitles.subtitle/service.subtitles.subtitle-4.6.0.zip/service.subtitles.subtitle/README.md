service.subtitles.subtitle
==================

Ktuvit.com subtitle service for KODI. 
