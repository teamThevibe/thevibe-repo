def run(ump):
	pass