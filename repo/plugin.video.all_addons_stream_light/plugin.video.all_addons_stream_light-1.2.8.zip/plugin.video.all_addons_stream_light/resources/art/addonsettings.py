# -*- coding: utf-8 -*-
import os, urllib, xbmc, zipfile

def ExtractAll(_in, _out):
	try:
		zin = zipfile.ZipFile(_in, 'r')
		zin.extractall(_out)
	except Exception, e:
		print str(e)
		return False

	return True


def isreliveuser():

	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/wizard/userdata/userdata_general/userdata.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isra.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass	

def metalliqplayers():
    if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.senyor.imdb.watchlists')):	
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/wizardrepo/metalliq.players/userdata/addon_data/plugin.video.metalliq/players.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.metalliq')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isra.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass			
			
