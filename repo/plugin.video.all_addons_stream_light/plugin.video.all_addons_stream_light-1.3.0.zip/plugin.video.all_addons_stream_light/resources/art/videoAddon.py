# -*- coding: utf-8 -*-
import os, urllib, xbmc, zipfile

def ExtractAll(_in, _out):
	try:
		zin = zipfile.ZipFile(_in, 'r')
		zin.extractall(_out)
	except Exception, e:
		print str(e)
		return False

	return True

def six():
	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.six')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.six.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")		
	
def israeliveresolver():
	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.israeliveresolver')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/newwizard/addons/script.module.israeliveresolver.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")		

def metasearch():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.program.meta_search')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/newwizard/addons/plugin.program.meta_search.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass

	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")			
	
def israelive():
	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.israelive')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/newwizard/addons/plugin.video.israelive.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")			
	
def Exodus():
	
	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.exodus')):
		return
	
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/exodus/plugin.video.exodus.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/exodus/script.exodus.artwork-1.0.1.zip"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		

	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")		
		
def exodusenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.exodus')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'plugin.video.exodus')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'plugin.video.exodus')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'plugin.video.exodus')	

def exodusartenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.exodus.artwork')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.exodus.artwork')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.exodus.artwork')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.exodus.artwork')	
	
		

def salts():
	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.salts')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/salts/plugin.video.salts.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass

	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")		

def saltenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.salts')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'plugin.video.salts')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'plugin.video.salts')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'plugin.video.salts')	
	
	
def tknorrisshared():
	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.tknorris.shared')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/salts/script.module.tknorris.shared.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass

	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")		

def tknorrissharedenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.tknorris.shared')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.tknorris.shared')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.tknorris.shared')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.tknorris.shared')	

def tknrepo():
	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.tknorris.beta')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/repos/repository.tknorris.beta-1.0.5.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass			

	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")		
	
def tknrepoenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.tknorris.shared')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.tknorris.shared')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.tknorris.shared')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.tknorris.shared')	

	
	
def Phoenix():
	
	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.phstreams')):
		return
	
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/phoenix/plugin.video.phstreams.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
		
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")

def Phoenixenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.phstreams')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'plugin.video.phstreams')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'plugin.video.phstreams')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'plugin.video.phstreams')	

	
def specto():
	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.specto')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/specto/plugin.video.specto.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass

	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")		

def spectoenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.specto')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'plugin.video.specto')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'plugin.video.specto')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'plugin.video.specto')	
	
	
def mrknowurlresolver():
	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.mrknow.urlresolver')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.mrknow.urlresolver.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass

	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")		

def mrknowurlresolverenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.mrknow.urlresolver')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.mrknow.urlresolver')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.mrknow.urlresolver')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.mrknow.urlresolver')	
	
	
def Evolve():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.Evolve')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/evolve/plugin.video.Evolve.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass	

	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")

def Evolveenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.Evolve')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'plugin.video.Evolve')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'plugin.video.Evolve')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'plugin.video.Evolve')	
	
	
def ccloudtv():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.ccloudtv')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/ccloud/plugin.video.ccloudtv.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")

def ccloudtvenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.ccloudtv')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'plugin.video.ccloudtv')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'plugin.video.ccloudtv')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'plugin.video.ccloudtv')	
		
		
def meta():
	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.meta')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/meta/plugin.video.meta.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/repos/repository.meta-1.0.0.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass			
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")	

def metaenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.meta')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'plugin.video.meta')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'plugin.video.meta')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'plugin.video.meta')	
		
def metaenablerepoenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.meta')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'repository.meta')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'repository.meta')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'repository.meta')	
				
	
def DandyMedia():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.dandymedia')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dandymedia/plugin.video.dandymedia.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")	

def DandyMediaenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.dandymedia')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'plugin.video.dandymedia')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'plugin.video.dandymedia')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'plugin.video.dandymedia')	
			
	
def AlphaMovies():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.AlphaMovies')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/thealpha/plugin.video.AlphaMovies.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")	

def AlphaMoviesenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.AlphaMovies')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'plugin.video.AlphaMovies')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'plugin.video.AlphaMovies')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'plugin.video.AlphaMovies')	
		
	
def futures():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.futures')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.futures.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")

def futuresenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.futures')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.future')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.future')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.future')	
			
	
def youtube():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.youtube')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/plugin.video.youtube.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")

def youtubeenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.youtube')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'plugin.video.youtube')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'plugin.video.youtube')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'plugin.video.youtube')	
		
	
def beautifulsoup():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.beautifulsoup')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.beautifulsoup.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")

def beautifulsoupenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.beautifulsoup')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.beautifulsoup')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.beautifulsoup')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.beautifulsoup')	
			
	
def beautifulsoup4():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.beautifulsoup4')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.beautifulsoup4.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")

def beautifulsoup4enable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.beautifulsoup4')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.beautifulsoup4')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.beautifulsoup4')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.beautifulsoup4')	
			
	
def httplib2():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.httplib2')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.httplib2.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")

def httplib2enable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.httplib2')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.httplib2')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.httplib2')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.httplib2')	
			
	
def xbmcswift():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.xbmcswift2')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.xbmcswift2.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")

def xbmcswiftenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.xbmcswift2')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.xbmcswift2')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.xbmcswift2')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.xbmcswift2')	
				
	
def html5lib():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.html5lib')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.html5lib.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")	

def html5libenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.html5lib')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.html5lib')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.html5lib')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.html5lib')	
		
	
def routing():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.routing')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.routing.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")		

def routingenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.routing')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.routing')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.routing')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.routing')	
			
	
def liveresolver():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.liveresolver')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.liveresolver.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")

def liveresolverenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.liveresolver')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.liveresolver')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.liveresolver')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.liveresolver')	
			
	
def metahandler():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.metahandler')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.metahandler.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")

def metahandlerenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.metahandler')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.metahandler')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.metahandler')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.metahandler')	
		
	
def myconnpy():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.myconnpy')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.myconnpy.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")

def myconnpyenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.myconnpy')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.myconnpy')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.myconnpy')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.myconnpy')	
			
	
def pyxbmct():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.pyxbmct')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.pyxbmct.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")

def pyxbmctenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.pyxbmct')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.pyxbmct')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.pyxbmct')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.pyxbmct')	
			
	
def requests():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.requests')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.requests.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")

def requestsenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.requests')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.requests')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.requests')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.requests')	
				
	
def simpledownloader():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.simple.downloader')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.simple.downloader.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")	

def simpledownloaderenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.simple.downloader')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.simple.downloader')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.simple.downloader')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.simple.downloader')	
				
	
def simplejson():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.simplejson')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.simplejson.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")	

def simplejsonenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.simplejson')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.simplejson')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.simplejson')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.simplejson')	
		
	
def t0mm0():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.t0mm0.common')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.t0mm0.common.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")	

def t0mm0enable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.t0mm0.common')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.t0mm0.common')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.t0mm0.common')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.t0mm0.common')	
			
	
def urlresolver():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.urlresolver')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.urlresolver.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")	

def urlresolverenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.urlresolver')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.urlresolver')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.urlresolver')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.urlresolver')	
			
	
def f4mTester():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.f4mTester')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/plugin.video.f4mTester.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")		

def f4mTesterenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.f4mTester')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'plugin.video.f4mTester')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'plugin.video.f4mTester')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'plugin.video.f4mTester')	
		
	
def youtubedl():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.youtube.dl')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.youtube.dl.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")	

def youtubedlenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.youtube.dl')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.youtube.dl')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.youtube.dl')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.youtube.dl')	
			
	
def signals():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.addon.signals')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.addon.signals.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")		

def signalsenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.addon.signals')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.addon.signals')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.addon.signals')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.addon.signals')	
			
	
def commonplugincache():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.common.plugin.cache')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.common.plugin.cache-2.5.6.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")			

def commonplugincacheenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.common.plugin.cache')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.common.plugin.cache')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.common.plugin.cache')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.common.plugin.cache')	
		
	
def parsedom():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.parsedom')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.parsedom.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")	

def parsedomenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.parsedom')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.parsedom')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.parsedom')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.parsedom')	
		
	
def featherenceservice():
	
	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.featherence.service')):
		return
	
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.featherence.service.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")	

def featherenceserviceenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.featherence.service')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.featherence.service')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.featherence.service')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.featherence.service')	
	
	
def spectomedia():
	
	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.specto.media')):
		return
	
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/specto/script.specto.media.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")		

def spectomediaenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.specto.media')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.specto.media')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.specto.media')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.specto.media')	
	
	
def xbmcisrael():
	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.xbmc-israel')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/repos/repository.xbmc-israel-1.0.4.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")

def xbmcisraelenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.xbmc-israel')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'repository.xbmc-israel')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'repository.xbmc-israel')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'repository.xbmc-israel')	
		
	
def Exodusrepo():
	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.exodus')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/exodus/repository.exodus-1.0.1.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")

def Exodusrepoenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.exodus')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'repository.exodus')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'repository.exodus')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'repository.exodus')	
			
	
def frenchdj():
	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'frenchdj.repository')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/repos/frenchdj.repository-0.0.1.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")	

def frenchdjenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'frenchdj.repository')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'frenchdj.repository')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'frenchdj.repository')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'frenchdj.repository')	
		
	
def filmkodi():
	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.filmkodi.com')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/repos/repository.filmkodi.com-2.1.0.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")	

def filmkodienable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.filmkodi.com')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'repository.filmkodi.com')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'repository.filmkodi.com')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'repository.filmkodi.com')	


def Brettusenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.Brettus.Documentaries')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'plugin.video.Brettus.Documentaries')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'plugin.video.Brettus.Documentaries')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'plugin.video.Brettus.Documentaries')	
		 
def Decadoenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.DecadoDocs')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'plugin.video.DecadoDocs')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'plugin.video.DecadoDocs')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'plugin.video.DecadoDocs')	

def Featherencedocuenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.featherence.docu')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'plugin.video.featherence.docu')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'plugin.video.featherence.docu')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'plugin.video.featherence.docu')	
	
def Documentarytubeenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.documentarytube')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'plugin.video.documentarytube')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'plugin.video.documentarytube')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'plugin.video.documentarytube')	
	

def iconspireenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.iconspire')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'plugin.video.iconspire')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'plugin.video.iconspire')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'plugin.video.iconspire')	
		
	
def subcenterenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'service.subtitles.subscenter')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'service.subtitles.subscenter')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'service.subtitles.subscenter')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'service.subtitles.subscenter')	
		

def torecenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'service.subtitles.torec')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'service.subtitles.torec')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'service.subtitles.torec')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'service.subtitles.torec')	
		
	
def subcenteroldenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'service.subtitles.subscenter.3.3.7')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'service.subtitles.subscenter.3.3.7')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'service.subtitles.subscenter.3.3.7')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'service.subtitles.subscenter.3.3.7')	
		
	
def ktuvitenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'service.subtitles.subtitle')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'service.subtitles.subtitle')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'service.subtitles.subtitle')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'service.subtitles.subtitle')	
			

def opensubtitlesenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'service.subtitles.opensubtitles')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'service.subtitles.opensubtitles')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'service.subtitles.opensubtitles')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'service.subtitles.opensubtitles')	
			
def subsenable():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'service.subtitles.subscenter')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'service.subtitles.subscenter')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'service.subtitles.subscenter')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'service.subtitles.subscenter')			