# -*- coding: utf-8 -*-
import sys
import os
import time
import routing
import requests
import json
import urllib
from bs4 import BeautifulSoup
from xbmc import Player, sleep, log, executebuiltin, translatePath
from xbmcaddon import Addon
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem, endOfDirectory, setContent, setResolvedUrl


ADDON = Addon()
ADDON_HANDLE = int(sys.argv[1])
PLUGIN = routing.Plugin()


def get_json():
    playlists_file_path = translatePath('special://userdata/addon_data/plugin.audio.99fm-playlists/playlists.json')
    data = None

    if os.path.isfile(playlists_file_path) and time.time() - os.path.getmtime(playlists_file_path) < 86400:
        file = open(playlists_file_path, 'r')
        data = file.read()
        file.close()
    else:
        log('Fetching playlists...')
        req = requests.get('http://nirelbaz.com/kodi/data/playlists.json')
        data = req.text
        file = open(playlists_file_path, 'w+')
        file.write(data)
        file.close()

    return json.loads(data)


@PLUGIN.route('/')
def index():
    """
    Shows channels list
    :return:
    """
    for index, category in enumerate(get_json()):
        try:
            bg_image = urllib.quote(category['bgImage'], safe=':/?=')
        except:
            bg_image = PLUGIN.addon.getAddonInfo('fanart')
            pass

        # list item:
        li = ListItem(u'{0} - {1}'.format(category['title'].upper(), category['slogan']),
                      iconImage=bg_image,
                      thumbnailImage=bg_image)
        li.setArt({
            'fanart': bg_image
        })
        # directory item:
        addDirectoryItem(
                PLUGIN.handle,
                PLUGIN.url_for(show_playlists, index=index),
                li,
                True
        )
    # end of directory:
    endOfDirectory(PLUGIN.handle)


@PLUGIN.route('/channels/<index>/playlists')
def show_playlists(index):
    """
    Shows playlists in a channel
    :param index: Channel index
    :return:
    """
    for idx, playlist in enumerate(get_json()[int(index)]['playlists']):
        try:
            bg_image = urllib.quote(playlist['bgImage'], safe=':/?=')
        except:
            bg_image = PLUGIN.addon.getAddonInfo('fanart')
            pass

        # list item:
        li = ListItem(u'{0} - {1}'.format(playlist['title'].upper(), playlist['slogan']),
                      iconImage=bg_image,
                      thumbnailImage=bg_image)
        li.setArt({
            'fanart': bg_image
        })
        li.setProperty('IsPlayable', 'true')
        li.setInfo('music', {
            'Title': u'{0} - {1}'.format(playlist['title'].upper(), playlist['slogan']),
        })
        # set the content of the directory
        setContent(ADDON_HANDLE, 'songs')
        # directory item:
        addDirectoryItem(
                PLUGIN.handle,
                PLUGIN.url_for(play_song, channel_index=index, playlist_index=idx),
                li,
                False
        )
    # end of directory:
    endOfDirectory(PLUGIN.handle)


@PLUGIN.route('/channels/<channel_index>/playlists/<playlist_index>')
def play_song(channel_index, playlist_index):
    playlist = get_json()[int(channel_index)]['playlists'][int(playlist_index)]
    try:
        bg_image = urllib.quote(playlist['bgImage'], safe=':/?=')
    except:
        bg_image = ADDON.getAddonInfo('fanart')
        pass

    li = ListItem( playlist['title'],
                  playlist['slogan'], bg_image, bg_image,
                  urllib.quote(playlist['songs'][0]['url'], safe=':/?='))
    li.setArt({'thumb': bg_image, 'fanart': bg_image})
    li.setInfo('music', {'Title': playlist['title'], 'Artist': playlist['slogan']})
    li.setProperty('mimetype', 'audio/mpeg')
    li.setProperty('IsPlayable', 'true')
    li.setInfo('music', {
        'Title': playlist['title'].upper(),
        'Artist': playlist['slogan'],
        'Artist_Description': playlist['slogan']
    })

    setResolvedUrl(ADDON_HANDLE, True, listitem=li)
    # update_now_playing(playlist)


def update_now_playing(playlist):
    last_item = None
    song = None
    artist = None
    thumb = None

    r = requests.get(playlist['url'])
    if r.status_code == 200:
        soup = BeautifulSoup(r.content, 'html5lib')

        while Player().isPlaying() and Player().getPlayingFile()\
                .find(urllib.quote(playlist['songs'][0]['url'], safe=':/?=')) >= 0:
            current_time = Player().getTime()

            for item in soup.find_all("td", attrs={"class": "SetsPlaylistDesc", "valign": "center"}):
                if current_time < calc_fractional_seconds(item.get_text()):
                    break
                last_item = item

            if last_item:
                log('last item')
                content = last_item.parent.find_all('td')
                if song != content[1].get_text().encode('utf-8'):
                    log('different song')
                    song = content[1].get_text().encode('utf-8')
                    artist = content[2].get_text().encode('utf-8')
                    thumb = content[3].find('img').get('src').encode('utf-8')

                    bg_image = thumb[thumb.find('http'):]
                    li = ListItem(playlist['title'], song, bg_image, bg_image)
                    li.setArt({'thumb': bg_image, 'fanart': bg_image})
                    li.setInfo('music', {
                        'Title': song,
                        'Artist': artist
                    })
                    li.setInfo('music', {
                        'Title': song,
                        'Artist': artist,
                        'Artist_Description': playlist['slogan']
                    })
                    log(song)
                    executebuiltin('SetProperty(MusicPlayer.Title, "This is a test")')
                    executebuiltin('SetProperty(MusicPlayer.Artist, "This is another test")')
                    Player().play(listitem=li)

            sleep(10000)


def calc_fractional_seconds(time_label):
    time = time_label.split(':')
    return int(time[0]) * 3600 + int(time[1]) * 60 + int(time[2])


if __name__ == '__main__':
    PLUGIN.run()
    setContent(PLUGIN.handle, 'audio')
