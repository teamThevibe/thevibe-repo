from api import API

api = API()

print str(len(api.get_channels()))