# -*- coding: utf-8 -*-
from cache import Cache
from xbmc import log
from bs4 import BeautifulSoup
import requests
import re


BASE_URL = 'http://eco99fm.maariv.co.il'
CHANNEL = 'http://eco99fm.maariv.co.il/music_channels/channel.aspx?SCid={0}'
data = []


class API(object):
    def __init__(self):
        pass

    def get_channels(self):
        """
        Gets all music sets channels
        :return: Array of channels dictionaries
        """
        jar = requests.cookies.RequestsCookieJar()
        headers = {
            'Accept-Encoding': 'gzip, deflate, sdch',
            'Accept-Language': 'en-US,en;q=0.8,he;q=0.6',
            'Upgrade-Insecure-Requests': 1,
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.95 Safari/537.36'
        }
        r = requests.get('http://eco99fm.maariv.co.il/', cookies=jar, allow_redirects=False)

        if r.status_code == 200:
            r = requests.get('http://eco99fm.maariv.co.il/', cookies=jar)
            soup = BeautifulSoup(r.content, 'html5lib')
            return [{
                'url': BASE_URL + i.parent.get('href'),
                'bgImage': re.search("url\('(.+)'\)", str(i)).group(1),
                'title': i.p.get_text(),
                'slogan': i.p.find_next_sibling('p').get_text(),
            } for i in soup.select('a[href*=/music_channels/] > div')]

    def get_playlists(self, url):
        """
        Gets all playlists in channel
        :param url: Channel url
        :return: Array of playlists dictionaries
        """
        playlists = []
        r = requests.get(url)

        if r.status_code == 200:
            soup = BeautifulSoup(r.content, 'html5lib')
            return [{
                'url': BASE_URL + i.parent.get('href'),
                'bgImage': re.search("url\('(.+)'\)", str(i)).group(1),
                'title': i.find('span', class_='newOldSetsTitles').get_text(),
                'slogan': '',
                'title_top': soup.find('td', class_='musicChannelTitle').get_text()
            } for i in soup.select('a[href*=/music_channel/] > div')]

    def get_playlist(self, url):
        """
        Get specific playlist
        :param url: Playlist url
        :return: Playlist dictionaries
        """
        r = requests.get(url)
        log(r.content)

        if r.status_code == 200:
            soup = BeautifulSoup(r.content, 'html5lib')
            return {
                # 'bgImage': soup.select_one('div[poster]').get('poster'),
                'bgImage': '',
                'title': soup.find('span', class_='newtopSetTitle').get_text(),
                'slogan': soup.find('span', class_='newtopSetDesc').get_text(),
                'mp3': soup.find('input', {'id': 'FileUrl'}).get('value')
            }

    def get_timing(self, url):
        """
        Gets timing of all songs in specific playlist
        :param url: Playlist url
        :return: Array of timing dictionaries
        """
        songs = []
        r = requests.get('http://eco99fm.maariv.co.il/Sets/playlist.aspx',
                          data='<?xml version="1.0" encoding="UTF-8"?><request><Sid>{0}</Sid></request>'
                          .format(url
                                  .replace('http://eco99fm.maariv.co.il/music_channel/', '')
                                  .replace('.aspx', '')))

        if r.status_code == 200:
            soup = BeautifulSoup(r.content, 'html.parser')
            # get songs:
            songsTitles = soup.select('td.SetsPlaylistTitle')
            songsTimes = soup.select('td.SetsPlaylistDesc')
            songsIcons = soup.select('img.top-cropped_Set_Playlist')

            for idx, elem in enumerate(songsTitles):
                icon = songsIcons[idx]['src']
                songs.append({
                    'title': elem.get_text() + ' - ' + songsTimes[idx * 2].get_text(),
                    'time': songsTimes[idx * 2 + 1].get_text(),
                    'seconds': self.calc_seconds(songsTimes[idx * 2 + 1].get_text()),
                    'icon': icon[icon.find('http'):]
                })

        return songs

    def calc_seconds(self, time):
        """
        Calculates seconds in timestamp
        :param time: Timestamp
        :return: Seconds
        """
        seconds = 0
        multiplier = { 0: 3600, 1: 60, 2: 1 }
        for index, fragmant in enumerate(time.split(':')):
            seconds += int(fragmant) * multiplier[index]

        return seconds